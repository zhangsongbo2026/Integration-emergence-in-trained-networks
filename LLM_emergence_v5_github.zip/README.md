# Topological consolidation, not loop crystallisation

Code, results and figures for "Topological consolidation, not loop crystallisation:
a preregistered operational test of emergence as a phase transition in a grokking
network" (V2 of the LLM-emergence framework paper).

The paper tests a preregistered framework for emergence on a grokking
modular-arithmetic network. Central finding: the registered loop-persistence
order parameter does not jump at the generalisation transition, it collapses
(topological consolidation), and three other registered predictions are
falsified, all logged as outputs.

## Layout

```
paper/Llm_emergence_v2.md/.tex/.pdf/.docx   manuscript (PLOS CompBio style)
paper/PROTOCOLS.md                          preregistered protocol family + execution status
paper/expert_response_map.md                expert-review response map (Chinese)
figures/fig1..fig11                         publication figures (PNG, 300 dpi)
scratch/grok_core.py                        model + data + training utilities
scratch/mlp_core.py                         measurement suite (Psi1, r, ID, spectral gap)
scratch/run_E1.py .. run_E8E10E11.py        protocol runners (E1..E11)
scratch/analysis.py                         consolidated statistics -> results/analysis_summary.json
scratch/verify_numbers.py                   51/51 number-consistency checks
scratch/figures.py                          figure generation
results/E1_seed*.json .. E11_*              per-run records (trajectories, metrics)
results/analysis_summary.json               all adjudication numbers
results/verify_numbers_report.json          check report
```

## Reproduce

```bash
pip install -r requirements.txt
python scratch/run_E1.py 0 1        # E1 main grid (repeat for seeds 2..7)
python scratch/run_E2.py            # E2 learning-rate sweep
python scratch/run_E3E4E5.py E3 0   # E3/E4/E5 protocols (per seed / arm)
python scratch/run_E6E9.py all      # E6/E7/E9 audits and calibration
python scratch/run_E8E10E11.py E8   # E8/E10/E11
python scratch/analysis.py && python scratch/verify_numbers.py
python scratch/figures.py
```

Single training run: ~2 min CPU. Full grid: ~2 h CPU.

## Key results

| Prediction | Verdict | Numbers |
|---|---|---|
| P-Phi (Psi1 jump) | direction-reversed | Psi1 collapses; rho(psi, acc) = -0.994 (8 seeds) |
| P-ID (density audit) | supported | naive b = 1.43 vs conditioned b = 0.997 |
| P-Arr (delay scaling) | supported | R2 = 0.978, slope 0.96 (power-law caveat) |
| P-Stat (edit threshold) | supported | rebound-collapse window eps in [0.5, 2.0] |
| P-Rev (hysteresis) | partial | sub-critical recovery yes; inversion rewrites |
| P-Kim (birth times) | partial | staggered, CV = 0.40; exponential rejected |
| P-E1 (budget truncation) | falsified | 7,767 vs 8,067 steps, p = 0.84 |
| P-E2/E3 (ratio theta*) | falsified | no interior optimum at 0.20 |
| surrogate calibration | approved | spectral gap rho = 0.965 with Psi1, 13x faster |

## License

MIT
