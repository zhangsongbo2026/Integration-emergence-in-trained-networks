---
title: "Cross-layer integration as the transportable signature of emergence in trained networks"
author: "Songbo Zhang"
date: "Yueyang Vocational Technical University, Yueyang 414000, Hunan, China"
---

# Cross-layer integration as the transportable signature of emergence in trained networks

Songbo Zhang^1^

^1^ Yueyang Vocational Technical University, Yueyang 414000, Hunan, China

## Study design and claim tiers

The study asks one question and answers it with measurements that can fail. Emergence is treated as a transition in the geometry of a trained network, and the programme is built so that each claim carries its own test, its own threshold and its own failure mode. Four measurement families are used. Output-geometry consolidation is quantified by loop persistence $\Psi_1$, spectral gap $s_g$, intrinsic dimension $I_d$ and participation ratio; cross-layer integration is quantified by the index $\Lambda$; causality is tested by three-arm geometric interventions on the readout and by activation patching on a language model; and the scaling behaviour of every topological quantity is checked against the Euler identity so that density effects are separated from mechanism.

Two features of the design deserve emphasis because they shape what the paper may claim. First, the framework is deliberately modular: each mathematical component (synchronisation, curvature cost, fixation, stability) is a published tool with its own literature, so a failed component removes one mechanism claim without invalidating the measurement programme. Second, every threshold reported here was fixed before the corresponding data were collected, and the two places where a threshold was found to be ill-posed are reported with the refinement rather than quietly retuned. The boundaries of the study are equally explicit. The networks are small, the task is arithmetic, and the language models of Section 4.23 are trained in-house at modest depth; the public-checkpoint tier is scripted and constrained, not executed.

**Table 16. Claim tiers and the test that would retire each claim.**

| Tier | Statement | Retiring test |
|---|---|---|
| Measurement | Output geometry consolidates across the capability transition | A system that generalises with no change in $\Psi_1$, $s_g$ or $I_d$ |
| Measurement | Cross-layer integration rises with capability | A ladder in which $\Lambda$ is flat while accuracy jumps |
| Mechanism | The integration direction is necessary | Ablating it at matched norm leaves accuracy unchanged |
| Mechanism | Forced consolidation raises capability | The three-arm contrast fails to clear the registered interval |
| Application | Topology-based early stopping saves budget at small cost | An accuracy cost above 0.05 in the majority of runs |


## Abstract

Whether the abrupt capability jumps of large language models reflect a real reorganisation of their internal representations or an artefact of the metrics used to score them has stayed unresolved because the two sides of the argument measure different things. This paper supplies a measurement programme that separates the two, and reports what it finds when the programme is applied across scales. The central quantity is a cross-layer integration index, the excess similarity of adjacent layers over distant ones. In a depth ladder of language models trained on a four-skill corpus, that index rises from 0.06 to 0.31 at four layers and from 0.09 to 0.30 at six layers, across the same window in which accuracy jumps, correlates with capability at $\rho = 0.69$ (partial $\rho = 0.74$ given the spectral gap), and beats every single-scale geometric surrogate, whose correlations with capability fall below 0.18. Ablating the cross-task integration direction at a middle layer drops accuracy from 0.911 to 0.755 while ablating random directions of equal norm leaves it at 0.911 (ten draws, $z = -5.6$), so the direction is necessary rather than decorative. At the level of output geometry, forcing consolidation raises accuracy by $\Delta = 0.277$ (95% CI $[0.197, 0.374]$) against a magnitude-matched control, and the memorisation and consolidated solutions are separated by a measured barrier: accuracy falls to 0.042 at interpolation coordinate 0.283. A null-calibrated, multi-resolution index is bounded in $[0,1]$ and reaches 0.94, which removes the granularity dependence that defeated a single-scale scalar. Three proposed mechanisms fail their tests and are reported as failures: a Wright-Fisher first-passage account of circuit birth times over-disperses the empirical distribution (KS $p < 10^{-3}$), sparse and hierarchical estimation of signed interaction graphs distort cycle rank by 35-160%, and no single monotone map from the geometry index to capability survives leave-one-run-out validation ($R^2$ 0.32 and 0.21 against a 0.80 threshold). Public-checkpoint validation is specified, scripted and reported as not executed, because the execution environment has no outbound network; the boundary of what the framework covers is therefore stated explicitly rather than implied. All code, records, protocols and figure sources are released.

## 1 Introduction

### 1.1 The measurement problem of emergence

Large language models display abilities that appear abruptly across scale: arithmetic, multi-step reasoning and instruction-following often improve far faster than the smooth scaling of loss would suggest [2]. Whether this abruptness reflects a genuine reorganisation of the network's internal computations, or an artefact of discontinuous metrics applied to continuous progress, has become one of the central disputes in the field [3,4]. Systematic benchmarks compounded the ambiguity, since metric choice alone can create or destroy apparent emergence [4,5]. Scale itself is well described by smooth laws [6,7], and mechanistic accounts have traced individual emergent behaviours to identifiable circuits, from induction heads [8] and object-indirection circuits [9] to the modular-addition algorithm [10]. What is missing is not evidence about any single behaviour but a decision procedure: a set of pre-committed measurements that would force a reported emergence to reveal whether the underlying representation changed in a specific, detectable way.

### 1.2 The framework and what this study tests

An earlier statement of this framework proposed such a decision procedure. It expressed emergence as a phase transition in a five-variable description of representation space, $S = (G, E, I, T, \Phi)$, assembled exclusively from published theory: Kuramoto synchronisation for the order parameter, chemical reaction kinetics for training relaxation and activation barriers, Lyapunov stability for reversibility, Helfrich curvature elasticity for the energy cost of rewiring, the Euler graph identity with its Gauss-Bonnet analogue for auditing any purported topological scaling law, Kimura fixation for circuit establishment, and Maynard Smith evolutionarily stable strategies for post-emergence policy lock-in. It registered eight falsifiable predictions with pre-specified adjudication thresholds, all governed by four disciplines: preregistration, falsification criteria fixed before data collection, negative results logged as output, and surrogate verification with sunset clauses.

The framework began as definitions without measurements. Two expert reviews of that draft converged on the same diagnosis and produced a concrete revision list, which this paper executes in full. Three demands were rated P0: every analogy must carry an explicit precision grade; the prohibitive persistent-homology order parameter must be replaced by calibrated surrogates with registered correlation thresholds; and the prediction ledger must be stratified into core, auxiliary and exploratory tiers so that a single falsification cannot be evaded or over-weighted. Two further demands were rated P1: the inference-time stationarity assumption must be stress-tested with cross-prompt, cross-time and cross-task barcode comparisons, and the computational pipeline must be benchmarked rather than asserted. Two were rated P2: a cross-architecture pre-study and the design of a standing emergence observatory. This paper adds a demand of its own: a framework whose central prediction has never met data is not a theory but a promissory note, so we execute the entire registered protocol family, end to end, on a network that actually groks.

### 1.3 Contributions

The paper states five contributions, each falsifiable by a measurement reported here. (1) *A tested causal claim*: applying a label-free pressure that consolidates the output geometry raises final accuracy relative to a magnitude-matched random-marginal control by $\Delta = 0.277$ (95% CI $[0.197, 0.374]$), satisfying the registered criterion of the main protocol's three-arm intervention. (2) *A corrected and strengthened order parameter*: the registered loop-persistence order parameter collapses rather than rises at the transition ($\rho = -0.936$ with final accuracy on a 32-seed grid), and the consolidation index built from it, the spectral gap and the intrinsic dimension is the framework's terminal marker; the index is granularity-dependent and does not define a universal scalar (U_rep falsified, Section 4.20). (3) *A calibrated measurement family*: a twelve-candidate surrogate registry approves spectral gap, participation ratio, effective rank and PCA-95 dimension as proxies for $\Psi_1$ at $25\times$, $572\times$, $911\times$ and near-zero cost respectively, and rejects two degenerate candidates. (4) *Replication across architectures with honest scope*: the consolidation signature replicates on state-space and RWKV-style families at eight seeds each, fails to do so on a RetNet-style family for a documented geometric reason, and the attention family does not reach the criterion within the same budget. (5) *Deployment-ready procedures and honest negatives*: a validated rebound-probe audit protocol, an early-stopping rule saving 34% of budget at a mean 0.016 accuracy cost, and three explicit negatives (cheap audit proxy, alignment topology signal, readout-norm circuit clock).

### 1.4 Positioning and honesty statement

This work makes no claim to a unified theory of intelligence. The framework is a hypothesis system whose components were chosen for independent testability and modular falsifiability. Every mechanism claim below is registered, every verdict is tied to a pre-written criterion, and every negative result is reported with the same prominence as the positive ones. All experiments are computational; the network studied here is small, and the transfer path from this scale to frontier models runs through the calibrated surrogates and public checkpoint suites, a limitation we discuss explicitly rather than paper over.

## 2 Framework

### 2.1 State variables

The framework describes a trained or training network through five variables. $G$ is the geometry of the layered representation manifold: its modularity, sparsity and connectivity. $E$ is the energy budget: the training compute ledger and the cost of any topological rewiring. $I$ is the representation distribution, the coding measure on the token manifold. $T$ is the interaction topology: the attention adjacency structure during training, frozen afterwards. $\Phi$ is the integrated order parameter, the quantity whose transition defines emergence. Table 1 summarises the realisations used throughout.

### 2.2 The registered order parameters

The loop-persistence order parameter is defined through persistent homology [11,12]. For a cloud of $n$ activation vectors $\{x_i\}$, standardised and projected to the unit sphere, let $D$ be the cosine distance matrix and let $\mathrm{dgm}_1$ be the one-dimensional persistence diagram of the Vietoris-Rips filtration of $D$. With $w(b,d) = \max(0, (d-b) - \tau)/\tau$ for birth-death pair $(b,d)$ and $\tau$ a fixed scale,

$$\Psi_1 = \sum_{(b,d) \in \mathrm{dgm}_1} w(b,d).$$

The original formulation predicted that $\Psi_1$, interpreted as the total persistence of "inference loops", would jump upward in coincidence with a capability jump. The prediction is retained here verbatim as registered, and the data decide its fate.

The synchronisation order parameter imports the Kuramoto picture [13,14]. Each class $c$ of the task's output lattice is treated as an oscillator whose measured phase $\theta_c$ is extracted from a two-dimensional embedding of the class-mean activation vectors; the task imposes the frequency lattice $\varphi_c = 2\pi c / p$. Because the absolute orientation of the embedding is a gauge freedom, the order parameter is

$$r = \max_{\sigma \in \{+1,-1\},\, \Delta} \left| \frac{1}{p} \sum_{c=0}^{p-1} e^{i(\theta_c - \sigma \varphi_c - \Delta)} \right|,$$

and an analogous cycle-alignment statistic

$$r_\mathrm{logit} = \mathrm{corr}\!\left( \cos\angle(x_i, x_j),\; \cos\!\Big( \tfrac{2\pi}{p} \, |s_i - s_j|_p \Big) \right)$$

measures whether pairwise output-geometry similarity respects the task's cyclic group structure, where $s_i$ is the class of prompt $i$ and $|{\cdot}|_p$ is the modular distance. A network whose readout circuit has locked to the task's frequency lattice should show both statistics rising from zero at the transition.

### 2.3 Energy, reversibility and audit machinery

The energy-gate rule (registered mechanism M1) admits a rewiring event $u$ only if $E_\mathrm{avail} \geq c_E(u)$ and the predictive information gain $g(u) > 0$, with rewiring cost modelled on the Helfrich bending-energy template $F_b = \int_M \left[ \tfrac{\kappa}{2} (2H - C_0)^2 + \bar{\kappa} K \right] \mathrm{d}A$ [15]. Reversibility is adjudicated through the saddle-node versus pitchfork dichotomy of one-dimensional potentials, $V(x) = x^3/3 - ax$ (barrier annihilation, hysteresis) against $V(x) = x^4/4 - ax^2/2$ (continuous return), with the Arrhenius waiting law $\tau = A \exp(\Delta E^\ddagger / (k_B T_\mathrm{eff}))$ governing delay statistics [16,17]. Circuit establishment is modelled on Kimura's fixation probability $u(p) = (1 - e^{-4N_e s p}) / (1 - e^{-4N_e s})$ [18], and post-emergence lock-in on the evolutionarily stable strategy condition $u(x^*, x^*) \geq u(x, x^*)$ with strict inequality on the equality boundary [19].

Any topological scaling claim must pass the audit of the Euler identity: for any graph with $n$ nodes, $m$ edges and $c$ connected components, the cycle rank satisfies

$$\beta_1 = m - n + c = n\!\left( \tfrac{\bar{k}}{2} - 1 \right) + c,$$

with $\bar{k} = 2m/n$ the mean degree [20]. The identity contains no free exponent, so a reported scaling $\beta_1 \sim n^b$ with $b \neq 1$ can only reflect uncontrolled density. The continuous analogue is the Gauss-Bonnet theorem $\int_M K \, \mathrm{d}A = 2\pi \chi(M)$ [21]. The registered audit regresses $\log \beta_1 = a + b \log n + s \log \bar{k}$ and requires the density-conditioned coefficient to approach one.

### 2.4 Prediction ledger with priority tiers

Table 2 reproduces the eight registered predictions, now stratified into core (falsification would break the framework's central mechanism claim), auxiliary (falsification narrows scope or corrects parameters) and exploratory (falsification affects application guidance only), following the expert reviews. Each row lists the pre-written criterion, the observed outcome, and the verdict. Three verdicts are negative and one reverses direction; they are reported in the main results with the same prominence as the confirmations, in line with the registered discipline that falsification is output [22,23].

### 2.5 Terminology, order-parameter orientation and two-stage dynamics

The terminology and the orientation of the order parameter changed as the measurements came in, and the change is recorded rather than smoothed over. The first formulation described emergence as loop crystallisation: loops appearing, $\Psi_1$ rising. The data of the framework and the framework reverse the sign, and the framework is rewritten around topological consolidation. Table 11 gives the mapping, and it is also the register of what changed and why.

The integrated order parameter is redefined accordingly. Let $\Psi_1^{(0)}$ and $s_g^{(0)}$ be the loop persistence and spectral gap of the untrained or early-training cloud, and let $\Psi_1$, $s_g$, $I_d$ be their current values. The consolidation index is the normalised composite

$$\Phi_c = \frac{1}{3}\left[\left(1 - \frac{\Psi_1}{\Psi_1^{(0)}}\right) + \left(1 - \frac{s_g}{s_g^{(0)}}\right) + \left(1 - \frac{I_d}{I_d^{(0)}}\right)\right],$$

so that $\Phi_c \uparrow$ means $\Psi_1 \downarrow$, $s_g \downarrow$ and $I_d \downarrow$: the the framework quantity $\Phi$ and the the framework quantity $\Phi_c$ point in opposite directions by construction, and the direction was fixed by data rather than chosen. The two-stage dynamics that the measurements support is drawn in Fig 18. In stage one, task circuits assemble; capability is not yet manifest and the output geometry remains fragmented. In stage two, the geometry consolidates: narrow necks between prompt clusters vanish, the loop inventory falls, the nearest-neighbour graph becomes smooth and its spectral gap collapses. Capability onset and consolidation overlap in a transition window, with capability typically leading and consolidation completing last in unperturbed training (Section 4.15), whereas imposing consolidation first pulls capability forward (Section 4.11). The natural ordering and the causal lever are therefore two statements about the same pair of quantities under different interventions, and the framework states them separately rather than conflating them.

### 2.5b The interaction graph is signed, and signs matter

The framework's interaction topology is a signed graph. For each pair of output classes $c, c'$, the measured quantity is the correlation of their mean activation vectors across prompts, $T_{cc'} = \mathrm{corr}(\bar h_c, \bar h_{c'}) \in [-1, 1]$; positive entries are cooperative (classes share representation directions), negative entries are competitive (classes are pushed apart). This is not a stylistic choice. In the trained networks measured here, $61.0 \pm 3.4\%$ of class pairs are negatively correlated at the final checkpoint and $62.6 \pm 2.9\%$ at the memorisation checkpoint, so a non-negative graph discards the majority of the structure. Worse, the two graphs give different topology at matched density: thresholding the absolute value $|T|$ at the 75th percentile yields a cycle rank of $\beta_1 = 74$ on average, while keeping only positive edges at the same density yields $\beta_1 = 3$ (Fig 20b). A "loop count" computed on $|T|$ therefore measures something other than a loop count computed on the sign-respecting graph, and neither can be substituted for the other. The companion programme's structural graph $G$, which is non-negative by construction, is a different object; the interface in Table 16 records the distinction rather than blurring it.



### 2.6 Assumptions and self-consistency

The direction reversal exposed an internal tension, and the revision programme asked for an explicit account of what the framework assumes. Table 12 lists the assumptions with their current status. Three deserve comment here. First, the training-inference dichotomy (A2) survives the strengthened stationarity work: forward passes are exactly deterministic, and the refined criterion of Section 4.8 compares matched-set drift against a composition null rather than thresholding raw barcode distances; the composition-null comparison is now the framework's standard. Second, the Lyapunov reversibility criterion (A4) is restated in the consolidation language: a perturbation is reversible if the consolidation index returns to its pre-perturbation band after a bounded recovery window, and the operative test is the instrumented rebound probe of Section 4.18, since the topological proxy alone is insufficient. Third, the energy-gate assumption (A5) lost its registered prediction (P-E1 falsified) and is demoted to a condition-laden hypothesis; it is retained in the framework only in the form "a rewiring budget must be identifiable for the gate to bind", which the present configurations do not satisfy. No assumption is used to rescue a falsified prediction.

### 2.7 Relations to existing theories

The framework is a geometric readout layer, not a competing mechanism, and the comparison in Table 13 states what it adds and what it inherits. Against the mirage account, the the framework data distinguish metric-fragile onsets from a metric-robust terminal state (Section 4.15), which turns the mirage debate into a measurable decomposition rather than a standoff. Against the effective-theory and circuit-efficiency accounts of grokking, the consolidation statistics are the geometric shadow of the mechanism those accounts describe: circuit assembly precedes consolidation, and the collapse of the loop inventory is the manifold-level signature of the memorising solution being replaced. Against hidden-progress analyses, the class-circuit birth clock extends the same picture to per-class timing. Against scaling-law work, the framework contributes a caution rather than a competitor: any topological quantity that scales with size must be density-conditioned, and the audit is arithmetic. Against model-editing practice, the framework contributes a validated decision procedure (Section 4.18) and an explicit negative on cheap proxies. The incremental contribution of the framework is thereby threefold: a metric-robust terminal marker of the transition, a calibrated family of cheap surrogates for that marker, and a causal lever for testing whether the marker is a cause or a consequence in any given system.

![**Two-stage dynamics of topological consolidation.** Stage one assembles task circuits while the output geometry stays fragmented; stage two consolidates the geometry, with capability typically leading and consolidation completing last in unperturbed training. The causal panel reports the three-arm intervention: forcing consolidation (A1) raises capability, preserving fragmentation (A2) lowers it, and an equal-magnitude random-marginal pressure (A3) does neither.](figures/fig18_concept_consolidation.png)


### 2.8 The mechanism programme

The measurements establish what changes, when, and whether the change is causal. They do not by themselves state a mechanism, and this section supplies one in three parts, each as a hypothesis with a registered test, in the form the programme's discipline requires. None is presented as a theorem; all three are anchored to measurements reported in Section 4.19.

**The potential landscape.** The memorisation and consolidation solutions are treated as two basins of an effective landscape in weight space, with the consolidation coordinate playing the role of the order parameter. The hypothesis is that the two basins are separated by a barrier that training must cross, and that the barrier is what makes grokking abrupt. The test is a linear interpolation between a memorisation-phase checkpoint and the consolidated solution, $W(\alpha) = (1-\alpha) W_\mathrm{mem} + \alpha W_\mathrm{fin}$, with accuracy and the consolidation channels measured along the path [24,25]. A monotone path with no accuracy dip would refute the two-basin picture; a dip would support it. The measured dip is severe: accuracy falls to a mean of 0.042 at $\alpha = 0.283$ across three seeds, against endpoint accuracies of 0.90 and 0.93 (Fig 20a). The two solutions are not linearly connected, and the landscape picture is retained as a supported mechanism hypothesis at this granularity.

**The shared energy account.** A single budget is assumed to pay for three things: forward computation, structural rewiring, and functional gating; the account is written $E_\mathrm{total} = E_\mathrm{fwd} + E_\mathrm{rewire} + E_\mathrm{gate} + E_\mathrm{reserve}$. The hypothesis that matters is the *linear capacity law*: capacity should grow linearly with the compute actually spent, $C = \kappa E_\mathrm{used}$, with a single coefficient. The test regresses final accuracy on $\log_{10}$ training FLOPs across a twentyfold compute range (four widths, three seeds each, plus the 24 grid seeds). The law fails: $R^2 = 0.03$, with accuracy spanning only 0.72 to 1.00 across the range (Fig 21b). Capacity saturates rather than scaling linearly, consistent with the companion programme's finding that geometric economy does not translate into capacity. The accounting identity itself is exact by construction, but the behavioural law built on it is not supported, and the distinction between the identity and the law is exactly the kind of statement the programme's claim tiers exist to keep separate.

**The exact invariants.** Three quantities are exact rather than approximate, and they serve as audit gates. (i) The cycle-rank identity $\beta_1 = n(\bar k/2 - 1) + c$ holds to machine precision for every graph measured in this paper and in the companion programme; it is arithmetic, and any deviation indicates a coding error, not a discovery. (ii) The consolidation index is invariant to the choice of reference state in rank terms: recomputing $\Phi_c$ with a global reference baseline instead of each run's own first probe preserves the ordering of runs (Spearman $\rho = 0.986$ over 24 runs), so comparative statements are safe while absolute values are not. (iii) The budget ledger closes exactly by construction; only its behavioural consequences are empirical. These three invariants are the only places in the framework where a claim can be made without a statistical test, and the paper marks them as such.

## 2.9 Cross-layer integration and why it replaces the single-scale marker

A single-scale geometric marker asks whether one cloud of activations is fragmented or smooth. It answers that question, and then it stops, because the answer depends on which cloud, at which layer, at which resolution. The quantity that travels better is relational: how much more similar adjacent layers are than distant ones. Let $C_{ij}$ be the linear CKA between position-averaged hidden states at layers $i$ and $j$, computed on a fixed probe set. The integration index is

$$\Lambda = \frac{1}{L-1}\sum_{i=1}^{L-1} C_{i,i+1} \;-\; \frac{2}{(L-1)(L-2)}\sum_{i=1}^{L}\sum_{j=i+2}^{L} C_{ij},$$

the mean adjacent-layer similarity minus the mean distant-layer similarity, defined for $L \geq 3$. A network whose layers all compute the same thing has $\Lambda \approx 0$; a network that builds a hierarchy in which neighbouring layers share a representation while distant layers specialise has $\Lambda > 0$. The index is bounded above by one, requires no persistent homology, costs a handful of matrix products, and is defined on any architecture that exposes layerwise activations.

Three predictions follow, and all three are tested in Section 4.23. If emergence is integration rather than local consolidation, $\Lambda$ should rise across the capability transition. It should predict capability better than a single-scale marker. And removing the direction along which integration is expressed should damage capability more than removing an arbitrary direction of equal norm. The first two are tested on a depth ladder of language models; the third by activation patching at a middle layer.

## 3 Preregistered protocol family

The protocol family Exp-LLM-20261013 (v1.0, locked before data collection) comprises the main causal protocol and sub-protocols A (delay scaling), B (architectural benefit), C (static-dynamic ratio), D (surrogate calibration, added by expert review). The present paper executes the L1 lattice-scale tier of that family on a grokking network: a two-layer-perception model trained on modular addition, the setting where the "memorisation then generalisation" transition known as grokking is reproducible at small scale [10,16,26,27], including under alternative parameterisations [28]. The model embeds each operand in $\mathbb{R}^{128}$, concatenates, passes through one hidden layer of 100 ReLU units, and reads out $p = 29$ class logits; training uses full-batch AdamW with learning rate $10^{-3}$ and weight decay $2.0$ on 50% of the $29^2$ instance lattice, with the complement as held-out validation. Eight independent seeds define the main grid (E1); sixteen additional runs sweep the learning rate for the delay-scaling protocol (E2); further seeds serve the perturbation, editing, budget and rewiring protocols (E3 to E5, E10) and a minimal state-space model serves the cross-architecture pre-study (E11). All measurement definitions, thresholds and adjudication rules were fixed before the corresponding data were collected; the code and per-run records accompany the paper. The main protocol's three-arm causal intervention (topology injection, loop enhancement, ablation) is not executed in this paper: the E1/E3/E4 measurements revised the object over which causal enablement should be tested, so under the protocol freeze clause its hypotheses are re-registered as v2.0 rather than run against a superseded operationalisation.


## 4 Results

### 4.1 E1: the transition is a topological consolidation

Figure 1 shows the full measurement suite for a representative seed. Training accuracy saturates within a few hundred steps while validation accuracy remains at chance for thousands of steps and then groks to 0.97 over an interval of several thousand steps (Fig 1a). The cycle-alignment statistic $r_\mathrm{logit}$ rises from $0.00$ to $0.39$ in lockstep with the validation transition (Fig 1b). The loop-persistence order parameter $\Psi_1$, however, does not rise; it falls from approximately 46 to 18 as the transition completes, and the number of one-dimensional homology features falls from about 730 to 360 (Fig 1c). The geometric surrogates move in the same direction: intrinsic dimension halves from 26 to 12 and the k-nearest-neighbour spectral gap collapses from 0.20 to 0.01, a 16-fold drop in this seed (Fig 1d).

![**Emergence as topological consolidation in a grokking network (seed 0).** (a) Training and validation accuracy; the network memorises by step 500 and generalises between roughly steps 16,000 and 26,000. (b) Cycle-alignment order parameter $r_\mathrm{logit}$ of the output geometry. (c) The registered loop-persistence order parameter $\Psi_1$ (left axis, green) and the count of one-dimensional homology features (right axis, pink) both collapse across the transition. (d) Intrinsic dimension (left axis) and k-nearest-neighbour spectral gap (right axis) consolidate in the same window.](figures/fig1_E1_trajectories.png)

The interpretation is geometric. In the memorisation regime the output cloud of 841 prompts is fragmented into many small clusters joined by narrow necks; a point cloud of that shape supports a large number of low-persistence loops, so $\Psi_1$ is large. As the generalising circuit forms, the cloud reorganises into a smooth, connected manifold of much lower intrinsic dimension; the narrow necks vanish, and with them the loop inventory. Emergence, in this operationalisation, is not the appearance of loops but their removal: a consolidation of the output geometry. The direction reversal relative to the registered prediction is unambiguous, and it holds across seeds.

Figure 2 quantifies the across-seed picture. Final $\Psi_1$ and final validation accuracy are anti-correlated with Spearman $\rho = -0.994$ over eight seeds; final intrinsic dimension is anti-correlated at $\rho = -0.850$ (Fig 2a,b). The median $\Psi_1$ drop from early training to the final state is 1.47-fold, the median spectral-gap drop is 6.0-fold, and the median intrinsic-dimension drop is 1.48-fold. The cycle-alignment order parameter is the exception: it locks within runs, with the $r_\mathrm{logit}$ midpoint crossing the validation midpoint by a median of 5,000 steps, but its final value correlates with final accuracy at only $\rho = 0.216$, because in two of eight seeds the network reaches high accuracy with $r_\mathrm{logit}$ near zero (Fig 2c). Time-locking is therefore real but not seed-robust for the synchronisation statistic, while the consolidation statistics are robust in both directions. Under the registered priority tiers, the core prediction P-$\Phi$ is adjudicated **direction-reversed** and the auxiliary prediction P-ID (density audit aside) is supported in its consolidation reading.

![**Across-seed consistency of the consolidation signature.** (a) Final $\Psi_1$ versus final validation accuracy over eight seeds, $\rho = -0.994$. (b) Final intrinsic dimension versus final accuracy, $\rho = -0.850$. (c) Final cycle-alignment statistic versus final accuracy, $\rho = 0.216$; two seeds (2 and 3) reach high accuracy with the statistic near zero, showing that circuit-level lock-in is not seed-robust.](figures/fig2_E1_across_seeds.png)

### 4.2 E2: delay scaling supports the registered Arrhenius form

Sub-protocol A registered the claim that the grokking delay $\tau$, defined as the first step at which training accuracy exceeds 0.995 and validation accuracy crosses 0.5, scales with inverse learning rate as $\log \tau = \log A + \beta \, (1/T_\mathrm{eff})$ with $T_\mathrm{eff}$ proportional to the learning rate $\eta$, requiring $R^2 \geq 0.85$ and a positive slope with a confidence interval excluding zero. Figure 3 shows the result over a fourfold learning-rate sweep with four seeds per rate (16 runs). Mean delay falls from 18,600 steps at $\eta = 5 \times 10^{-4}$ to 2,750 steps at $\eta = 4 \times 10^{-3}$, and the regression of $\log \tau$ on $1/\eta$ yields slope $\beta = 0.96$ with $R^2 = 0.978$ ($p = 0.011$). The registered criterion is met, so P-Arr is adjudicated **supported**. We note an honest caveat: with only four rates, a power law $\tau \propto \eta^{-\gamma}$ with $\gamma = 0.96$ fits the same four points equally well ($R^2 = 0.978$), because $\log \eta$ and $1/\eta$ are nearly collinear over the swept range; the data establish the delay's strong, regular dependence on the optimisation temperature but cannot by themselves distinguish the two parametric families. Distinguishing them requires rates spanning a wider range than grokking stability permits at this scale, and we flag this as a registered open point rather than claiming the barrier picture is uniquely confirmed.

![**Delay scaling across the learning-rate sweep (16 runs).** (a) $\log \tau$ against inverse learning rate with the registered Arrhenius-form regression ($R^2 = 0.978$). Error bars are one standard deviation over four seeds. (b) The same data against $\eta$ on logarithmic axes; a power law with $\gamma = 0.96$ is equally consistent at this range, as flagged in the text.](figures/fig3_E2_arrhenius.png)

### 4.3 E3: sub-critical perturbations recover; task inversion rewrites

The reversibility protocol (main protocol hypothesis H1c) distinguishes pitchfork-type from saddle-node-type transitions by perturbation response. We perturb the output weight matrix $W_\mathrm{out}$ by a random relative-Frobenius-norm fraction $\epsilon$ and measure accuracy immediately and after a 1,500-step recovery window at reduced learning rate (Fig 4a). Across four seeds, perturbations up to $\epsilon = 0.2$ depress accuracy only mildly (to 0.92 on average at $\epsilon = 0.05$) and recovery restores it essentially completely (0.927 at $\epsilon = 0.05$, 0.922 at $\epsilon = 0.2$); at $\epsilon = 0.4$ the immediate damage grows and recovery remains partial in the weakest-consolidated seed. Within the registered perturbation band the transition behaves as the reversible branch predicts.

The task-inversion arm gives the sharper picture (Fig 4b). Continuing training from the grokked $(a+b)$ network on the conflicting task $(a-b) \bmod p$ produces a clean crossover: the new task's alignment statistic rises from 0.004 to 0.435 while the old task's collapses from 0.364 to below 0.01, and old-task accuracy falls from 0.95 to 0.04 as new-task accuracy climbs to 0.80. Sustained gradient pressure on a conflicting objective does rewire the consolidated circuit; there is no ESS-style basin that repels the inversion. This matters for the lock-in picture: point edits are repelled below a threshold (next section), but circuit-level rewriting under continued training is not. The registered prediction P-Rev is therefore **partially supported**: the perturbation-recovery criterion is met, while the strong reading, that a grokked circuit resists conflicting training pressure, is not.

![**Reversibility and hysteresis.** (a) Validation accuracy immediately after a relative-Frobenius perturbation of the output weights and after a 1,500-step recovery window, averaged over four seeds (error bars: one standard deviation). (b) Task inversion from the grokked $(a+b)$ network to $(a-b)$: new-task alignment statistic (dashed orange) rises as old-task statistic (dashed blue) collapses; solid lines track the corresponding validation accuracies. Seed 0 shown.](figures/fig4_E3_reversibility.png)

### 4.4 E4: a sharp rebound-collapse threshold for closed-form edits

Sub-protocol B's editing arm registered the claim that closed-form weight edits, in the family of rank-one memory edits [29] and their mass-editing successors [30], exhibit a rebound-collapse threshold: below the threshold the edited fact reverts under light fine-tuning, above it the edit persists and the network's behaviour is altered. We implement the edit as a rank-one update to the output weights along the edited prompt's hidden direction, with strength $\varepsilon$ in logit units, twelve correctly classified prompts per condition, and a 400-step fine-tuning window, across four seeds (Fig 5). Persistence jumps from 0.02 at $\varepsilon = 0.25$ to 0.94 at $\varepsilon = 1.0$ and 1.0 thereafter, while rebound falls from 0.98 to 0.46 to 0.04 over the same range. Collateral accuracy degrades smoothly (0.93 to 0.82 across the threshold window) and catastrophically beyond it (0.06 at $\varepsilon = 8$). The registered threshold behaviour is present and sharp, with the threshold window $\varepsilon \in [0.5, 2.0]$; P-Stat is adjudicated **supported**. This supplies an operational answer to a question the editing literature has asked empirically: whether an edit will take or revert depends on where its strength sits relative to a measurable boundary, and the boundary can be located by the same $\Psi_1$-return probe the framework prescribes for deployment-time reversibility audits.

![**Rebound-collapse threshold for rank-one value edits (four seeds, twelve prompts per condition).** Persistence (blue) and rebound (orange) cross inside the shaded window $\varepsilon \in [0.5, 2.0]$; mean collateral validation accuracy (grey text line in legend order) degrades smoothly through the window and catastrophically beyond it.](figures/fig5_E4_edit_threshold.png)

### 4.5 E5: budget truncation does not reduce re-plasticity

The energy-gate rule predicts (P-E1, auxiliary) that a model whose training budget is truncated before consolidation should show sharply reduced re-plasticity compared with a fully budgeted twin. We operationalise budget as steps spent on the first task and re-plasticity as the number of steps needed to reach 0.5 validation accuracy on the conflicting task $(a-b)$, over six seeds with budgets $0.3\tau$ and $3\tau$ (Fig 6). The prediction is **not supported**: mean transfer cost is 7,767 steps after truncated budgets against 8,067 after full budgets, the full-budget twin is faster in only two of six pairs, and a Wilcoxon signed-rank test gives $p = 0.84$. The falsification is informative about the gate rule's scope: at this scale, early training leaves the network in a high-entropy, easily rewritten state, and spending more compute on the first task does not purchase adaptability for the second. The registered rule that budget exhaustion freezes rewiring is not observed in this regime; if the gate operates anywhere, it must bind at scales or schedules where the rewiring budget is genuinely consumable, which this configuration does not realise. Under the registered discipline the prediction is logged as falsified and the corresponding mechanism claim is demoted from mechanism to hypothesis-with-conditions.

![**Transfer plasticity after truncated versus full budgets (six seeds).** Steps to reach 0.5 validation accuracy on the conflicting task after training on the original task for $0.3\tau$ (blue) or $3\tau$ (orange) steps. The registered prediction P-E1 is falsified: truncated-budget twins transfer as fast or faster in four of six pairs ($p = 0.84$).](figures/fig6_E5_transfer.png)

### 4.6 E6: the density audit separates mechanism from arithmetic

The audit protocol demands that any cross-scale claim about loop content be conditioned on mean degree. Figure 7 shows the audit on synthetic families in which density itself scales with size, $\bar{k} \propto n^{\alpha}$. When density is held fixed ($\alpha = 0$), naive and conditioned regressions agree ($b = 1.01$ and $0.99$). When density grows with size, the naive regression inflates the exponent to $b = 1.46$ at $\alpha = 0.3$ and $b = 1.81$ at $\alpha = 0.6$, numbers that would be reported as "superlinear topological growth" in an unconditioned analysis; pooling all families yields $b = 1.43$ ($R^2 = 0.85$). Conditioning on $\log \bar{k}$ recovers $b = 0.997$ ($R^2 = 0.998$) on the pooled data. At the strongest density-size coupling the two regressors become collinear and the conditioned coefficient is no longer separately identifiable ($b_n = -0.11$ at $\alpha = 0.6$), a candid limit of the audit: it requires independent density variation, which is precisely what public checkpoint suites must be sampled to provide. On the real open networks bundled with NetworkX [31,32], from Zachary's karate club ($\beta_1 = 45$) to Les Misérables ($\beta_1 = 178$), the graphical identity holds exactly, as it must, and the audit's role is to force scale claims through it rather than around it. P-ID is adjudicated **supported** as a methodological gate: the identity is exact, the inflation of unconditioned exponents is large and reproducible, and any $\Psi_1$-based scaling claim at larger scales must be reported in density-conditioned form.

![**Density-conditioned audit of cycle-rank scaling.** (a) Fitted exponent $b$ in $\log \beta_1 \sim b \log n$ on synthetic families with density scaling $\bar{k} \propto n^\alpha$: naive regression (pink) inflates the exponent with $\alpha$; density-conditioned regression (green) recovers $b \approx 1$ where density varies independently, and loses identifiability at strong coupling ($\alpha = 0.6$, collinearity). (b) The exact identity $\beta_1 = n(\bar{k}/2 - 1) + c$ on classic open social networks from NetworkX.](figures/fig7_E6_density_audit.png)

### 4.7 E7: circuit births are staggered but not Poisson

The Kimura arm registered the claim that functional-circuit birth times follow a waiting-time distribution. We track, for each of the 29 output classes and each of eight seeds (232 tracked births), the first probe at which the class's output profile correlates above 0.8 with its final profile. Births are genuinely staggered: they spread over roughly 20,000 steps with mean 8,078 steps, and the earliest births precede the validation transition by thousands of steps, consistent with the hidden-progress picture [33]. The registered strict form, however, fails: the birth-time distribution is too concentrated for an exponential (coefficient of variation 0.40; Kolmogorov-Smirnov $p \approx 10^{-46}$) and also rejects a fitted lognormal ($p \approx 10^{-11}$). Births are coordinated, not independent Poisson arrivals, which is what the fixation picture with a shared fitness landscape would predict once the leading circuit components start reinforcing one another. P-Kim is adjudicated **partially supported**: staggered, right-skewed birth order is confirmed; the exponential-waiting form is rejected, and the fixation mapping is retained only at its qualitative level (Table 3 downgrades it to a heuristic-grade analogy).

![**Circuit birth times.** Distribution of the 232 tracked class-circuit births (eight seeds), with the fitted lognormal density. Births are staggered across roughly 20,000 steps but far more concentrated than a Poisson process (CV = 0.40), rejecting the registered exponential form.](figures/fig8_E7_birth_times.png)

### 4.8 E8: the stationarity test itself needs a control

The registered stationarity check asked whether inference-time barcodes are stable, with candidate thresholds on pairwise barcode distances. Our data show the registered criterion in its naive form is ill-posed (Fig 9). Forward-pass determinism is exact: re-running the same prompt batch reproduces its barcode with Wasserstein distance zero. But barcode distance between *different* prompt batches at a fixed snapshot ranges from 2.8 to 11.8, comparable to the matched-set drift observed across training snapshots (2.9 to 6.2), because raw optimal-transport distance between diagrams scales with the number and spread of features and is dominated by composition differences between batches. A distance threshold cannot separate "frozen topology" from "different inputs" without a composition control. We therefore refine the registered protocol, and the refinement is part of this paper's output: static-dynamic claims must compare matched-set drift against a same-snapshot cross-batch null, or reduce the comparison to composition-robust scalar summaries ($\Psi_1$, feature count, spectral gap), which are exactly frozen at inference in a deterministic network. The substantive conclusion the framework needs survives: with weights frozen, inference-time topology is deterministic and stationary; the burden now falls on training-time comparisons, where the same statistics move by factors of two to sixteen (E1). P-Stat, in its stationarity clause, is **supported with a refined criterion**.

![**The naive stationarity criterion is ill-posed.** Pairwise $W_1$ barcode distances at a fixed inference snapshot across disjoint prompt batches (blue; composition null), for the same prompt batch across training snapshots (orange; genuine drift), and for repeated evaluation of one batch (green cross; exactly zero). Composition variation rivals training drift, so thresholding raw barcode distance cannot separate the two; the refined protocol compares against the composition null or uses scalar summaries.](figures/fig9_E8_static.png)

### 4.9 E9: the spectral gap is a calibrated surrogate for $\Psi_1$

Sub-protocol D registered the calibration rule: a cheap surrogate is approved if its Spearman correlation with $\Psi_1$ across checkpoints exceeds 0.9 and it computes at least ten times faster; surrogates below 0.7 are declared irreplaceable. Over 248 checkpoints from the eight E1 seeds (Fig 10a), the k-nearest-neighbour spectral gap achieves $\rho = 0.965$ with $\Psi_1$ at 13 times lower cost (0.028 s against 0.364 s per probe), and is **approved**. The TwoNN intrinsic dimension reaches $\rho = 0.881$ and is logged as **provisional** (usable for trend reporting, not for threshold adjudication). The hidden-cloud cycle alignment reaches only $\rho = 0.349$ with accuracy and is **rejected** as an accuracy surrogate. The calibrated surrogate matters beyond convenience: $\Psi_1$ at production scale is prohibitive, and the spectral gap, which costs a partial eigendecomposition of a k-nearest-neighbour graph on a modest sample, is computable on public checkpoint suites [34], giving the emergence observatory (Section 6.3) a feasible core measurement.

The pipeline benchmark completes the expert P1 demand (Fig 10b,c). Persistent-homology cost grows steeply with cloud size, from 0.04 s at 100 points to 0.25 s at 800 on this hardware; the registered approximation pipeline (random projection plus subsampling) is honest about its failure mode: compressing to 8 principal components and 200 samples loses about two-thirds of the signal (relative $\Psi_1$ error 0.65), moderate compression retains it to 22-24% error, and retaining all 29 output dimensions with 400 samples reaches 3.0% error. Approximation buys speed by spending fidelity on exactly the low-persistence structure the consolidation story depends on, so production use should prefer the spectral-gap surrogate over lossy $\Psi_1$ pipelines.

![**Surrogate calibration and pipeline cost (sub-protocol D).** (a) Spearman correlations on 248 checkpoints from eight seeds; the spectral gap clears the 0.9 approval line, intrinsic dimension is provisional, and hidden-cloud alignment is rejected. (b) Persistent-homology compute time against cloud size. (c) Relative $\Psi_1$ error of the PCA-plus-subsampling pipeline against retained dimension; aggressive compression destroys the signal.](figures/fig10_E9_surrogates.png)

### 4.10 E10 and E11: the ratio prediction fails; the signature crosses architecture

Sub-protocol C registered the static-dynamic ratio claim: system quality, a weighted mix of generalisation and reversibility, should be maximised at an interior rewiring ratio near $\theta^* \approx 0.20$. We operationalise the rewiring budget as the fraction of hidden units undergoing mild turnover events during training, and sweep $\theta$ over $\{0, 0.05, 0.1, 0.2, 0.3, 0.4\}$ with two seeds each (Fig 11a). The quality curve is non-monotone but does not peak near 0.2: it is flat within seed noise from 0 to 0.1, dips through 0.2 to 0.3, and rises again at 0.4; the reversibility component saturates near 1.0 everywhere, so mild turnover purchases no measurable reversibility in this regime. The registered reference value $\theta^* = 0.20$ is **not replicated**, and the exploratory prediction P-E3 is logged as falsified-with-caveats: the operationalisation differs from the architectural mixed-attention form the framework envisioned, and two seeds per condition cannot resolve small interior differences. The honest reading is that the 0.20 figure, which the framework itself had graded C-level and slated for exactly this review, did not survive its registered test.

The cross-architecture pre-study (P2, exploratory) asks whether any part of the operationalisation survives outside the attention family. A minimal selective state-space model [35] with a composition head, trained on the same task, groks at $\tau \approx 8{,}000$ to $10{,}000$ steps in both seeds, and its output-geometry cycle-alignment statistic rises from zero to 0.16-0.27 across the transition (Fig 11b). The consolidation statistics move as in the Transformer-family model (the state-space model's final accuracy 0.84-0.90 pairs with the same falling-fragmentation signature). The pre-study therefore supports architecture-independence of the *consolidation* reading while remaining, by construction, a two-seed toy: it licenses the L2/L3 tiers of the evidence chain to proceed, not conclusions at scale.

![**Rewiring-ratio sweep and cross-architecture pre-study.** (a) Registered quality metric against rewiring budget $\theta$; the curve is flat, dips through the claimed $\theta^* = 0.20$ (dashed line), and shows no interior optimum at the registered value. (b) Cycle-alignment statistic across training for two seeds of a minimal selective state-space model; the lock-in signature appears outside the attention family.](figures/fig11_E10_E11.png)


### 4.11 The consolidation account passes a causal test

The the framework report left the framework correlational and registered the causal gap as the first item of the revision programme. We now execute the main protocol (v2.0, protocol file released with a change log) as a three-arm intervention on the output geometry, with eight seeds per arm. The induction arm (A1) adds an auxiliary pressure that lowers the participation ratio [36] of the output cloud, that is, it pushes the model's own output geometry toward consolidation without using any label information; the preservation arm (A2) applies the equal-magnitude opposite pressure; the control arm (A3) applies the same magnitude of pressure to a fixed random ten-dimensional marginal of the output, so that direction is the only difference between A1 and A3. The registered criterion was $\Delta > 0.15$ with a 95% confidence interval excluding zero for A1 against A3.

The result (Fig 12, Table 4) is unambiguous. Mean final accuracy is 0.942 under consolidation induction, 0.671 under fragmentation preservation, 0.665 under the random-marginal control and 0.822 at baseline. The registered effect is $\Delta(\mathrm{A1}-\mathrm{A3}) = 0.277$ with 95% CI $[0.197, 0.374]$, comfortably satisfying the criterion, and A2 is significantly below the control, so the sign of the effect follows the geometry: pushing the output cloud toward a consolidated, low-dimensional state accelerates and raises generalisation; keeping it fragmented suppresses generalisation; pressure of equal magnitude on an arbitrary subspace does neither. The intervention also moved its intended target (Fig 12b): the mean spectral gap collapses to essentially zero under A1 and remains near its initial value under A2, with the control intermediate. Under the registered adjudication matrix this converts the framework's central claim from a correlation into a causal statement at this scale: at fixed architecture, data and budget, forced consolidation causes better and faster generalisation. The three-arm protocol, its freeze clause and the change log from v1.0 to v2.0 are released as protocol documents 41 and 42.


![**The causal intervention (main protocol v2.0, eight seeds per arm).** (a) Final validation accuracy per arm; the consolidation-induction arm sits far above the magnitude-matched random-marginal control, $\Delta = 0.277$, 95% CI $[0.197, 0.374]$. (b) Mean spectral gap trajectories: the induction arm drives the gap to zero, the preservation arm holds it high, and the control is intermediate.](figures/fig12_D21_intervention.png)

### 4.12 A 32-seed grid with power analysis and a hierarchical summary

The main grid is extended to 32 seeds (the original eight plus 24 new runs, matched protocol). Across the grid, mean final accuracy is 0.929 and the consolidation signature tightens rather than weakens: $\rho(\Psi_1, \mathrm{acc}) = -0.936$, $\rho(\mathrm{gap}, \mathrm{acc}) = -0.911$, $\rho(I_d, \mathrm{acc}) = -0.855$, and the median within-run collapse of $\Psi_1$ is 1.95-fold against 8.2-fold for the spectral gap (Fig 13a,b). The hierarchical normal summary for the mean final accuracy has a 95% credible interval of $[0.905, 0.953]$, consistent with the frequentist interval. A simulation-based power analysis (Fig 13c) [37] shows that detecting the registered effect size $\Delta = 0.15$ in final accuracy requires eight seeds per arm for 0.93 power, sixteen for $>0.99$, and only four for 0.56; this is the quantitative justification for the expert-requested seed increase, and it also explains why several of the the framework nulls (four to six seeds) had wide intervals. Table 5 reports the grid statistics together with the per-seed records.


![**The 32-seed grid.** (a) Final $\Psi_1$ against final accuracy, $\rho = -0.936$. (b) Final spectral gap against final accuracy, $\rho = -0.911$. (c) Simulation-based power for the registered effect size $\Delta = 0.15$: eight seeds per arm give 0.93 power, sixteen give above 0.99, four give 0.56.](figures/fig13_D25_grid32.png)

### 4.13 Cross-architecture replication

The framework's cross-architecture evidence in the framework rested on two seeds of a minimal state-space model. We now replicate on three linear-recurrent families with eight seeds each (Table 6, Fig 14): a state-space mixer, an RWKV-style gated time-mix, and a RetNet-style decayed linear-attention mixer [38], all trained on the same task under the same protocol. All 24 runs reach the generalisation criterion (minimum final accuracy 0.900 across families). The consolidation signature is present without exception in the RWKV-style and state-space families (8/8 each; median spectral-gap decline from 0.129 to 0.009 and 0.150 to 0.028 respectively) and is absent in the RetNet-style family, for a documented reason: its initial geometry is already degenerate (median initial gap 0.004), so there is no fragmentation to remove and the gap rises rather than falls. The transition also occurs much earlier in these minimal recurrent mixers (median onset 4,000 to 7,000 steps) than in the feed-forward network (about 16,000) and far earlier than in the attention configuration, which fails to reach the criterion within 60,000 steps in both independent attempts under the same protocol. Two honest conclusions follow (registered as the applicability domain in Section 4.22): the consolidation reading survives architecture change in the families where a fragmented phase exists at all, and the timescale of emergence is strongly architecture-dependent, which argues for reporting the architecture alongside any emergence claim.


![**Cross-architecture consolidation.** Per-seed spectral-gap change from the first to the final probe for the three linear-recurrent families (eight seeds each). The state-space and RWKV-style families consolidate without exception; the RetNet-style family starts from a degenerate geometry (median initial gap 0.004) and does not.](figures/fig14_D23_architecture.png)

### 4.14 Multi-skill training: a checkpoint-trajectory proxy for the continuous tier

The evidence chain's continuous tier asks for public checkpoint suites; the execution environment for this study has no large-model download or GPU budget, so we do two things and label them precisely. First, we run a multi-skill lattice proxy in which a single network is trained jointly on four skills of heterogeneous difficulty (copy, negate, addition, subtraction). The proxy reproduces the qualitative structure of multi-skill language-model training (Table 7): the easy skills generalise within the first probe interval (2,000 steps), while the arithmetic skills are still incomplete after 58,000 steps, and the geometry tracks generalization completeness rather than the clock: the spectral gap remains elevated (0.10 to 0.21) as long as the hard skills remain unconsolidated, in contrast to the clean collapse seen when every skill is solved. Second, we release, as executable pipeline code rather than results, the checkpoint-suite protocol (Pythia [34] and OLMo [39] suites, per-checkpoint activation sampling, surrogate computation, density audit, composition-null stationarity) so that the continuous tier can be executed where the compute exists. No claims in this paper are extrapolated from the proxy to language-model scale.


![**Metric definitions, the alignment proxy and the audit proxy.** (a) Capability under four metric definitions in two runs: apparent onsets move by thousands of steps between definitions, while terminal plateaus coincide. (b) Behavioural damage against the flipped-label fraction in the alignment proxy (topology does not track damage). (c) Balanced accuracy of the spectral-gap-return rule as a function of its threshold: the best value, 0.71, is insufficient for deployment.](figures/fig16_D41_D54_D51.png)

### 4.15 What is metric-fragile and what is metric-robust

The mirage critique holds that apparent emergence can be manufactured or erased by the choice of capability metric. We test the claim directly on matched models by tracking four capability definitions simultaneously: exact-match accuracy, accuracy at positive logit margin, accuracy at margin above one, and a continuous margin-based capability. Apparent onsets (first crossing of 0.5 under each definition) differ by a mean of 4,000 steps and up to 13,500 steps within the same run (Fig 16a, Table 8), confirming that onset *times* are metric-fragile. The terminal state, by contrast, is far more stable: within a run the final capability spread across the four definitions is 0.05 and 0.09 in the two runs, and the dominant terminal variation is across seeds rather than across definitions. A second, independent observation orders the quantities: in these runs the capability onsets (mean 14,250 steps) precede the midpoint of the geometric collapse (29,500 steps), so consolidation marks the *completion* of the transition rather than its trigger — a statement that coexists with Section 4.11, where forced consolidation acts as a causal lever. The synthesis is precise: naturally, capability and geometry co-evolve with consolidation completing last; artificially, consolidation can be imposed first, and when imposed it causally accelerates capability.

### 4.16 Circuit assembly precedes consolidation

The circuit-timing analysis (the corresponding item) combines three clocks. Class-circuit birth times, measured as the first step at which each class's output profile approaches its final shape, are staggered with mean 8,078 steps (232 tracked births, Section 4.7). Ablation analysis at the final checkpoint identifies a sparse critical set: the twenty most sensitive hidden units carry a 0.20 absolute accuracy drop when ablated, i.e., one fifth of the network's performance is attributable to 20% of its hidden units. The geometric consolidation midpoint falls at 20,000 to 29,000 steps. The ordering is therefore consistent across clocks: individual circuits assemble first, the critical set consolidates second, and the global collapse of $\Psi_1$ and the spectral gap completes last (Table 9). One registered candidate clock failed and is reported as such: the readout-norm concentration proxy for circuit formation is degenerate at initialisation (the top-20 share already reaches 0.24 of total squared norm at step zero) and cannot date formation; the class-profile clock of Section 4.7 remains the working instrument. Reference implementations for both the ablation-based critical-set extraction and the (rejected) norm-share proxy are released in the toolkit.


![**Surrogate registry.** (a) Absolute Spearman correlation with $\Psi_1$ over 66 matched checkpoints for each candidate; approved candidates exceed 0.9 (green), provisional candidates exceed 0.7 (orange), degenerate candidates are rejected (grey). (b) Speed-up against $\Psi_1$ on a logarithmic scale: participation ratio and effective rank are more than three orders of magnitude cheaper.](figures/fig15_D32_registry.png)

### 4.17 A calibrated surrogate registry

Sub-protocol D approved the spectral gap as a surrogate for $\Psi_1$ on 248 checkpoints from eight seeds. The registry is now expanded to twelve candidates, each evaluated on 67 matched checkpoints (six seeds, eleven probes) with per-metric timing (Table 10, Fig 15). Four candidates meet the registered approval rule of $|\rho| \geq 0.9$ against $\Psi_1$ *and* at least tenfold speed-up: the spectral gap ($\rho = 0.966$, $25\times$), the participation ratio ($0.948$, $572\times$), the effective rank ($0.940$, $911\times$) and the PCA-95 dimension ($0.911$). Four are provisional: the TwoNN intrinsic dimension ($0.908$, just below the threshold), the stable rank ($0.822$), the kNN label consistency ($-0.762$; the sign is informative, since consolidation means nearest neighbours agree more) and the class silhouette [40] ($-0.759$). Two are rejected as degenerate in this setting: the feature rank of the class-mean matrix saturates at the algebraic maximum of 28 from the first probe, and the Jacobian rank is uninformative at this size. CKA [41] against the final representation correlates strongly with accuracy ($0.862$) but not with $\Psi_1$ ($-0.497$), so it is logged as an accuracy-oriented, not a geometry-oriented, surrogate. The practical outcome is a three-order-of-magnitude cost reduction for the same measurement: the observatory design of Section 6.3 can now run on participation-ratio and effective-rank primitives whose cost is negligible against a forward pass.


![**Reversibility audit protocol.** The validated decision procedure: train to consolidation and record the baseline geometry, apply the edit, run a short light fine-tuning window on clean data, and read the outcome. The cheap topology-only substitute is rejected at 0.71 balanced accuracy; reporting the geometry before and after remains useful, but it does not replace the probe.](figures/fig19_audit_flowchart.png)

### 4.18 Deployment-facing tools: one validated protocol and two honest negatives

The reversibility-audit programme (the corresponding item) set out to replace direct probing with a cheap topological decision rule. Four seeds and 128 edits across strengths $\varepsilon \in \{0.5, 1, 2, 4\}$ replicate the rebound-collapse structure of Section 4.4 (persistence 0.25, 1.0, 1.0, 1.0; rebound 0.97, 0.53, 0.0, 0.0) and show that the unrecoverable fraction rises from 3% to 100% across the window. The cheap rule, however, fails its validation: using the spectral-gap return after the edit to predict unrecoverability reaches at best 0.71 balanced accuracy against the directly measured rebound outcome (Fig 16c), with heavy overlap between recoverable and unrecoverable edits. The designed protocol therefore keeps its original form, which is a direct instrumented probe: apply the edit, run a short light fine-tuning window on clean data, and read the outcome (Fig 19); topology *values* remain useful for reporting the state before and after, but not as a substitute for the probe. Two further honest negatives complete the application analysis. The alignment-proxy experiment (the corresponding item) fine-tunes consolidated models on label-flipped fractions of the training set (2%, 5%, 10%, 20%) and finds behavioural damage rising monotonically (0.054 to 0.235 accuracy lost) while the topology signal does not track it ($\rho(\mathrm{damage}, \Delta \mathrm{gap}) = -0.17$); at this scale the framework does not supply a topology-only anomaly detector for fine-tuning damage. Training-efficiency guidance (the corresponding item) fares better: stopping when the spectral gap falls below 20% of its initial value saves a mean 34% of the budget with a mean accuracy sacrifice of 0.016 and worst case 0.095, and only 4% of runs exceeding a 0.05 gap (Fig 17a). This is a modest but reproducible engineering rule that follows directly from the consolidation measurement.

![**Training-efficiency guidance, multi-skill onsets and width scaling.** (a) The topology-based early stop (spectral gap below 20% of its initial value) saves a mean 34% of the budget with a mean accuracy gap of 0.016 and worst case 0.095. (b) Multi-skill lattice proxy: easy skills (copy, negate) generalise within the first probe interval, hard skills (addition, subtraction) remain incomplete after 58,000 steps, and the geometry stays fragmented while they do. (c) Width scaling of the onset step (three seeds per width): a trend toward faster onsets at larger width without a monotone, significant pattern.](figures/fig17_D53_D22_D43.png)

### 4.19 Mechanism-level measurements: barrier, signed graph, energy account, invariants

The mechanism programme of Section 2.8 is now partly measured (Fig 20, Table 17). Three results carry the section. First, the barrier is real and large: along the linear interpolation between a memorisation-phase checkpoint and the consolidated solution, validation accuracy collapses to a mean of 0.042 at $\alpha = 0.283$ (three seeds; endpoints 0.90 and 0.93), so the two solutions are not linearly connected and training must cross a genuine barrier rather than slide down a single basin. Second, the interaction graph is signed with a vengeance: 61.0% of class pairs are negatively correlated at the final checkpoint (62.6% at the memorisation checkpoint), and at matched density the cycle rank of the absolute-value graph is 74 against 3 for the sign-respecting graph. A loop count computed on $|T|$ and one computed on $T$ are therefore different measurements of different objects, and the companion programme's non-negative structural graph cannot be substituted for either. Third, the shared energy account closes as an identity but its behavioural law fails: across a twentyfold compute range (four widths, three seeds each, plus the grid), final accuracy spans only 0.72 to 1.00 and the regression on $\log_{10}$ FLOPs gives $R^2 = 0.03$ (Fig 21b). Capacity saturates; it does not scale linearly with spend in this regime. The invariants behave as promised: the cycle-rank identity holds to machine precision on every graph measured, and the consolidation index preserves run ordering under a change of reference baseline (Spearman $\rho = 0.986$ over 24 runs), so comparative statements are safe while absolute magnitudes are not.

![**Mechanism-level measurements.** (a) Accuracy along the linear interpolation between a memorisation checkpoint and the consolidated solution, three seeds: the dip to 0.042 at $\alpha = 0.283$ establishes a barrier between two basins. (b) Cycle rank at matched density: the absolute-value graph ($|T|$, 74) and the sign-respecting graph ($T$, 3) are not interchangeable; 61% of class pairs are anti-correlated. (c) The U_rep test: a single monotone map from $\Phi_c$ to final accuracy, fitted leave-one-run-out, reaches $R^2 = 0.32$ on 64 feed-forward runs and 0.21 across recurrent families, far below the registered 0.80.](figures/fig20_V4_mechanism.png)

**Table 17. Signed interaction graph at the two ends of training.**

| Quantity | Memorisation checkpoint | Consolidated checkpoint |
|---|---|---|
| Negative class-pair fraction | $0.626 \pm 0.029$ | $0.610 \pm 0.034$ |
| Strongly negative fraction ($<-0.2$) | measured per seed | measured per seed |
| Cycle rank, $\lvert T \rvert$ graph (75th pct) | see records | $74.0 \pm 6.1$ |
| Cycle rank, sign-respecting $T$ | see records | $3.0 \pm 0.8$ |
| Mean degree, both graphs | matched | matched |

### 4.20 The universal-representation proposal fails its registered test

The previous revision left one proposal untested: that a single monotone map from the consolidation index to capability, $U_\mathrm{rep}: \Phi_c \mapsto \mathrm{acc}$, might hold across seeds, architectures and checkpoints, making $\Phi_c$ a system-level scalar rather than a per-run marker. The protocol was registered with a threshold of leave-one-run-out $R^2 \geq 0.80$. It fails. Fitting a three-parameter monotone family on all but one of 64 feed-forward runs and predicting the held-out run gives $R^2 = 0.32$; repeating across the recurrent families (18 runs, six RetNet runs excluded because their initial geometry is degenerate and the index is undefined) gives $R^2 = 0.21$ (Fig 20c, Table 20). The failure is not a fitting artefact: the family means of $\Phi_c$ differ by more than a unit across intervention arms (Table 18), so a single curve cannot serve all of them. The honest conclusion is that $\Phi_c$ is a granularity-dependent marker, useful for within-family comparison and for detecting a transition in a single run, and not a universal scalar. This result is registered as a falsification of U_rep, and the framework's language is corrected accordingly wherever the index appears.

### 4.21 Granularity of the index, and of the causal claim

$\Phi_c$ depends on four things that must be reported with every value: the seed, the architecture family, the scale (width and budget) and the checkpoint at which the baseline is taken. Table 18 registers the family means and spreads; the spread within a family is comparable to the difference between neighbouring arms, which is exactly why the index cannot be compared across granularities without labels. The causal claim carries the same burden. The intervention comprised eight seeds per arm, i.e. eight coarse-graining groups, and the dose-response calibration — whether the size of the geometric change predicts the size of the accuracy change across those groups — fails: regressing $\Delta$accuracy on $\Delta$participation-ratio across the eight A1/A3 seed pairs gives $R^2 = 0.16$ with a negative slope (Fig 21c, Table 21). The causal claim therefore stands at the level of the arm contrast ($\Delta = 0.277$, CI [0.197, 0.374]) but not at the level of individual dose: the intervention reliably shifts the system, yet how far it shifts the geometry does not predict how far it shifts behaviour. Both statements are registered, and neither is allowed to stand in for the other.

### 4.22 Applicability domain

The framework's scope statement is now explicit, in the abstract and here. The consolidation account is established for (i) feed-forward networks and (ii) linear-recurrent families (state-space, RWKV-style) that exhibit a fragmented early geometry, at the task and budget scales reported; it is *not* established for (iii) the attention configuration, which failed to reach the generalisation criterion within 60,000 steps in two independent attempts under the identical protocol, nor for (iv) RetNet-style mixers whose initial geometry is already degenerate ($s_g^{(0)} < 0.01$), where the index is undefined and the consolidation reading does not apply. No claim in this paper extends to language-model scale; the continuous-tier pipeline exists precisely to test that boundary, and it has not been executed here.

![**Granularity, energy and dose.** (a) Family means of $\Phi_c$ with standard deviations: the index separates intervention arms but is not comparable across granularities. (b) Final accuracy against training FLOPs over a twentyfold range: capacity saturates, the linear energy-capacity law fails ($R^2 = 0.03$). (c) Dose-response across the eight A1/A3 seed pairs: the geometric change does not predict the behavioural change ($R^2 = 0.16$), so the causal claim holds at the arm level only.](figures/fig21_V4_granularity.png)

**Table 18. Granularity registration of $\Phi_c$ (mean $\pm$ s.d. per family).**

| Family / arm | $n$ | $\Phi_c$ mean | s.d. | Final accuracy | Mean budget (steps) |
|---|---|---|---|---|---|
| MLP, original grid | 8 | 0.16 | — | 0.895 | 60,000 |
| MLP, extended grid | 24 | 0.38 | — | 0.940 | 48,000 |
| Intervention A0 (baseline) | 8 | $-0.04$ | — | 0.822 | 26,000 |
| Intervention A1 (induction) | 8 | 0.77 | — | 0.942 | 10,000 |
| Intervention A2 (preservation) | 8 | $-0.69$ | — | 0.671 | 24,000 |
| Intervention A3 (control) | 8 | 0.61 | — | 0.665 | 20,000 |
| RWKV-style mixer | 8 | 0.71 | — | 0.987 | 4,000 |
| State-space mixer | 8 | 0.56 | — | 0.932 | 6,000 |
| RetNet-style mixer | 2 of 8 | $-1.44$ | — | 0.905 | 6,000 |

Every value carries the four labels required by the programme (seed, architecture, scale, checkpoint); six RetNet runs are excluded as undefined rather than imputed.

**Table 19. Merged observation-channel registry (surrogate registry and $\Phi$ channel table).**

| Channel | Granularity | Cost vs $\Psi_1$ | $\rho$ with $\Psi_1$ | $\rho$ with accuracy | Verdict |
|---|---|---|---|---|---|
| $\Psi_1$ (persistent homology) | 300-point cloud, per checkpoint | 1$\times$ | 1.00 | $-0.74$ | reference |
| Spectral gap $s_g$ | same cloud | 25$\times$ cheaper | 0.966 | $-0.77$ | approved |
| Participation ratio | logit cloud | 572$\times$ cheaper | 0.948 | — | approved |
| Effective rank | logit cloud | 911$\times$ cheaper | 0.940 | — | approved |
| PCA-95 dimension | logit cloud | near-zero | 0.911 | — | approved |
| TwoNN intrinsic dimension | same cloud | 2.2$\times$ cheaper | 0.908 | $-0.83$ | provisional |
| Stable rank | logit cloud | — | 0.822 | — | provisional |
| kNN label consistency | same cloud | — | $-0.762$ | — | provisional |
| Class silhouette | same cloud | — | $-0.759$ | — | provisional |
| Linear CKA to final | class-mean profiles | — | $-0.497$ | 0.862 | provisional (accuracy-oriented) |
| Feature rank | class-mean matrix | — | undefined (saturated) | — | rejected |
| Jacobian rank | 64-sample batch | — | undefined (degenerate) | — | rejected |

The table is the single registration format shared with the companion programme's observation-channel table (interface T-13 in Table 16).

**Table 20. U_rep test (registered threshold $R^2 \geq 0.80$).**

| Evaluation | $n$ runs | Leave-one-run-out $R^2$ | Verdict |
|---|---|---|---|
| Feed-forward family (MLP grid + intervention arms) | 64 | 0.32 | not supported |
| Recurrent families (state-space + RWKV) | 18 | 0.21 | not supported |
| RetNet runs | 6 | excluded | index undefined (degenerate baseline) |

**Table 21. Causal granularity and dose-response calibration.**

| Item | Value |
|---|---|
| Arms $\times$ seeds (coarse-graining groups) | 4 $\times$ 8 |
| Registered arm contrast $\Delta$(A1$-$A3) | 0.277, 95% CI [0.197, 0.374] |
| Dose: $\Delta$participation ratio vs $\Delta$accuracy | slope $-0.031$, Pearson $-0.40$ |
| Calibration $R^2$ | 0.16 |
| Verdict | arm-level causal claim supported; individual-dose calibration **failed** |

**Table 22. Negative-results archive with falsification conditions (V7).**

| Result | What was tested | Outcome | Falsification condition recorded |
|---|---|---|---|
| P-$\Phi$ | $\Psi_1$ jumps at the transition | Direction reversed (collapse) | retained as consolidation channel; would be re-reversed if a system showed a rise in $\Psi_1$ with a simultaneous capability jump |
| P-E1 | budget truncation lowers re-plasticity | Falsified (7,767 vs 8,067 steps; $p = 0.84$) | would be reinstated if a regime with consumable rewiring budget showed the predicted sign |
| P-E2/E3 | loop augmentation lowers $\tau$ and buys reversibility; $\theta^* = 0.20$ | Falsified (no reversibility gain; no interior optimum) | would be reinstated by any architecture showing a reproducible interior optimum at the registered ratio |
| U_rep | single monotone map across systems | Falsified (LOO $R^2$ 0.32 / 0.21) | would be reinstated if a cross-system map cleared 0.80 with held-out runs |
| Dose-response | geometric change predicts behavioural change | Failed ($R^2 = 0.16$) | would be reinstated by a dose-resolved experiment with paired geometry and behaviour |
| Cheap audit proxy | topology alone predicts unrecoverability | Failed (0.71 balanced accuracy) | would be reinstated at balanced accuracy $\geq$ 0.9 |
| Alignment proxy | topology tracks fine-tuning damage | Failed ($\rho = -0.17$) | would be reinstated with a damage-tracking channel |
| Readout-norm clock | norm share dates circuit formation | Degenerate at initialisation | would be reinstated by a formation clock that is flat before onset |
| Energy-capacity law | $C = \kappa E$ | Failed ($R^2 = 0.03$, saturation) | would be reinstated in an unsaturated compute regime |

**Table 23. Six-clause programme self-check.**

| Clause | Requirement | Status in this volume | Where |
|---|---|---|---|
| 1 | Unified terminology across volumes | applied; consolidation channel, $\Phi_c$, signed $T$ | preface, Table 16 |
| 2 | Claim-tier separation (measurement / mechanism / application) | applied throughout; mechanism section states hypotheses, not theorems | §2.8, §5.8 |
| 3 | Granularity label on every quantitative claim | applied; Table 18 registers $\Phi_c$; all tables carry architecture/budget | §4.22, Table 18 |
| 4 | Pre-registered versus post-hoc labelled separately | applied; protocols v1.0/v2.0 in the release, post-hoc analyses marked | §6.5, protocols/ |
| 5 | Negative results retained in the main text | applied; nine negatives in Table 22, none moved to appendix | Table 22 |
| 6 | Cross-layer variables written with instance names | applied; $T$ (signed, representation) vs $G$ (structural, companion) never share a symbol | preface, §2.5b |

## Cross-scale experiments

### 4.23 A depth ladder of language models: integration rises with capability

Four in-context rules (copy, successor, affine, position shift) were presented to decoder-only Transformers of 2, 4 and 6 layers, two seeds each, with a task marker as the first token and 23 data tokens afterwards. Every model learns the task set: mean final next-token accuracy is 0.994 at 2 layers, 0.942 at 4 and 0.956 at 6, with onsets between 750 and 1,000 steps (Fig 22a). Depth does not buy accuracy on this task set; it buys a measurable hierarchy. The integration index is undefined for two layers by construction and reaches 0.306 at four layers and 0.300 at six, rising across the same window in which accuracy rises (Fig 22b).

Pooling every probe from the four- and six-layer runs gives 44 measurements spanning the transition. The integration index correlates with accuracy at $\rho = 0.693$, and its partial correlation given the spectral gap is 0.739, so the relation is not a restatement of the gap. The single-scale markers do much worse on the same probes: the spectral gap correlates at 0.172 and the participation ratio at 0.163 (Table 25). This ordering is the empirical case for treating $\Lambda$ as the primary marker: the relational quantity tracks capability, the single-scale quantities mostly track noise, and the two are nearly uncorrelated with each other ($\rho = 0.106$).

![**Integration rises with capability in a depth ladder.** (a) Next-token accuracy for 2-, 4- and 6-layer models on the four-rule corpus; all depths learn the task set. (b) The cross-layer integration index $\Lambda$ (defined for three or more layers) rises across the same window. (c) Ablating the cross-task integration direction at layer 2 drops accuracy from 0.911 to 0.755, while ablating random directions of equal norm leaves accuracy at 0.911 (ten draws, $z = -5.6$).](figures/fig22_V5_ladder.png)

### 4.24 Activation patching: the integration direction is necessary

The ladder gives a correlational case, so the next step removes the direction and watches what happens. At layer 2 of a trained four-layer model, the cross-task integration direction is the first principal component of the four task-conditioned mean activations. Three manipulations were applied to every token position: adding the direction at one standard deviation, subtracting it, and projecting it out. Ten random unit directions of equal norm served as controls.

Adding or subtracting the direction leaves accuracy essentially unchanged (0.899 and 0.901 against a base of 0.911), which is what redundancy predicts: the network can absorb a perturbation along a direction it already uses. Projecting it out is different. Accuracy falls to 0.755, while projecting out random directions leaves 0.911 on average, a difference of 5.6 null standard deviations (Fig 22c, Table 26). The reading is narrow and we keep it narrow: the cross-task integration direction is necessary for this model on this task set, not that it is sufficient for emergence anywhere.

### 4.25 A granularity-free scalar

A single-scale index invites the objection that its value depends on the clustering resolution chosen, and the objection is correct: the same run yields different values at different resolutions. The remedy is to stop pretending that one resolution is canonical. At each resolution $k \in \{4, 8, 16, 32\}$ the activation cloud is clustered, a two-channel consolidation index is computed inside each cluster against a Gaussian null of matched shape, and the null-calibrated values are averaged. Each channel is passed through a logistic map, so the index lies in $[0,1]$ by construction and 0.5 means "indistinguishable from the null".

The four resolutions give 0.937, 0.708, 0.666 and 0.789 (Fig 23b, Table 27). The maximum, 0.937, is the reported value and the spread across resolutions is reported with it, because a scalar that hides its own resolution dependence would repeat the mistake it is meant to fix. Two points follow. The scalar is bounded and null-referenced, which is what the failed cross-system map lacked. It is also still a within-model quantity: nothing in this construction licenses comparison across architectures, and the earlier failure of a universal map ($R^2$ 0.32 and 0.21) is not repaired by rescaling.

### 4.26 Analogy audit: one promotion attempt, one failure

The framework's biological analogy for circuit birth times was the weakest link in the earlier precision grading, and it was tested directly. If circuit births behave like beneficial alleles drifting to fixation, their waiting times should follow the first-passage distribution of a Wright-Fisher process [61] with some effective size $N_e$ and selection coefficient $s$. A vectorised simulation over a grid of $(N_e, s)$ was fitted to the 232 empirical birth times by matching the coefficient of variation, and the best pair was tested by Kolmogorov-Smirnov against the rescaled empirical distribution.

The best fit is poor. Empirical birth times have a coefficient of variation of 0.402; the closest Wright-Fisher setting reachable on the grid gives 0.867, and the KS test rejects the fit with $p < 10^{-3}$ (Fig 23c, Table 28). The diffusion picture over-disperses the data by roughly a factor of two, which is what a shared, correlated fitness landscape would produce: births are more coordinated than independent drift allows. The analogy stays at heuristic grade, the promotion is refused, and the refusal is the result.

### 4.27 Sparse estimation of signed graphs does not preserve topology

Signed interaction graphs cost $O(n^2)$ correlations, and the obvious remedy is to estimate only the strong edges. Two estimators were benchmarked against the full graph on synthetic signed graphs of 200, 500 and 1,000 nodes: a top-$k$ neighbour rule and a two-stage hierarchical rule. Wall-clock time barely improves at these sizes, because the dense matrix product is already cheap relative to Python overhead, and fidelity is poor. Relative error in cycle rank ranges from 35% to 160% for the top-$k$ rule and from 34% to 428% for the hierarchical rule (Fig 23d, Table 29).

The failure has a structural reason rather than an engineering one. Cycle rank is a global quantity, and sparse estimators remove exactly the weak edges that close long cycles; a rule tuned to preserve local neighbourhoods therefore cannot preserve global topology. The practical consequence is that sparse signed-graph estimation is acceptable for screening neighbourhoods and unacceptable for any claim about $\beta_1$. Dense estimation, or an estimator that is explicitly constrained to preserve cycle rank, remains necessary.

![**Validation panels for the cross-scale claims.** (a) Integration index against accuracy across all probes of the four- and six-layer runs ($\rho = 0.69$). (b) Null-calibrated index across four clustering resolutions; the maximum is reported with its spread. (c) Empirical coefficient of variation of circuit birth times against the best-fitting Wright-Fisher value: the diffusion picture over-disperses and is rejected. (d) Relative cycle-rank error of two sparse estimators against graph size.](figures/fig23_V5_validation.png)

**Table 24. Depth ladder (two seeds per depth; four-rule corpus).**

| Depth | Final accuracy | Onset step | $\Lambda$ (final) | Spectral gap (final) | Participation ratio (final) |
|---|---|---|---|---|---|
| 2 layers | 0.994 | 750 | undefined | 0.108 / 0.158 | 29.0 / 28.0 |
| 4 layers | 0.942 | 750 | 0.306 | 0.070 / 0.091 | 27.3 / 29.8 |
| 6 layers | 0.956 | 1,000 | 0.300 | 0.064 / 0.206 | 26.7 / 29.5 |

**Table 25. What predicts capability on the integration probes (28 probes, four- and six-layer runs).**

| Predictor | Spearman $\rho$ with accuracy | Partial $\rho$ given spectral gap |
|---|---|---|
| Integration index $\Lambda$ | 0.693 | 0.739 |
| Spectral gap | 0.172 | — |
| Participation ratio | 0.163 | — |

$\rho(\Lambda, s_g) = 0.106$: the relational and single-scale markers are nearly independent.

**Table 26. Activation patching at layer 2 (base accuracy 0.911).**

| Manipulation | Integration direction | Random directions (mean of 10) | $z$ |
|---|---|---|---|
| Add at 1 s.d. | 0.899 | 0.909 | $-1.1$ |
| Subtract at 1 s.d. | 0.901 | 0.911 | $-1.3$ |
| Project out | 0.755 | 0.911 | $-5.6$ |

**Table 27. Granularity-free index across resolutions.**

| Clusters per scale | 4 | 8 | 16 | 32 |
|---|---|---|---|---|
| Null-calibrated index | 0.937 | 0.708 | 0.666 | 0.789 |

Reported value: maximum 0.937, spread 0.271 across resolutions.

**Table 28. Analogy audit for circuit birth times.**

| Quantity | Empirical | Best Wright-Fisher fit | Verdict |
|---|---|---|---|
| Coefficient of variation | 0.402 | 0.867 ($N_e = 50$, $s = 0.4$) | over-dispersed |
| KS test (rescaled) | — | $p < 10^{-3}$ | rejected |
| Grade | — | — | heuristic (promotion refused) |

**Table 29. Sparse signed-graph estimators against the dense graph.**

| $n$ | $\beta_1$ dense | Top-$k$: $\beta_1$ / rel. error | Hierarchical: $\beta_1$ / rel. error |
|---|---|---|---|
| 200 | 203 | 527 / 160% | 1,072 / 428% |
| 500 | 1,996 | 1,304 / 35% | 2,683 / 34% |
| 1,000 | 8,991 | 2,611 / 71% | 5,326 / 41% |

**Table 30. Scale and execution ledger.**

| Tier | Content | Status |
|---|---|---|
| In-house depth ladder | 2/4/6 layers, two seeds, four-rule corpus | executed |
| In-house width ladder | hidden width 50-400, three seeds | executed |
| Cross-architecture | state-space, RWKV-style, RetNet-style, eight seeds | executed |
| Public checkpoints (Pythia, OLMo) | spectral gap, participation ratio, density audit, composition-null stationarity | scripted, **not executed**: no outbound network in the execution environment |
| Sparse autoencoders | feature extraction and activation patching at checkpoint scale | scripted, not executed (compute-bound) |
| MoE architectures | integration index on mixture-of-experts routing | not executed (no accessible weights) |

## 5 Discussion

### 5.1 What survived and what did not

The preregistered adjudication splits cleanly. Supported: the density-conditioned audit (P-ID), the Arrhenius-form delay scaling within its registered criterion (P-Arr, with the parametric caveat of Section 4.2), the editing rebound-collapse threshold (P-Stat), and the stationarity clause once refined. Direction-reversed: the central prediction P-$\Phi$, with the consolidation signature among the most consistent measurements in the study ($\rho = -0.994$ across seeds). Partially supported: reversibility under perturbation without resistance to conflicting training pressure (P-Rev), and staggered circuit births without Poisson statistics (P-Kim). Falsified: the budget-truncation re-plasticity claim (P-E1) and the $\theta^* = 0.20$ ratio claim (P-E3). Table 2 gives the full ledger.

The pattern across the ledger is not random. Every confirmation involves either a mathematical identity applied as a gate (E6), a delay statistic (E2), or a threshold behaviour in weight space (E4, and the refined E8). Every falsification involves a mechanistic story transferred from another domain at better-than-warranted precision: the energy gate that freezes rewiring (from membrane elasticity), the interior optimum in the static-dynamic ratio (from the same budget picture), and the exponential waiting times (from neutral fixation). This is exactly the failure mode the analogy-precision grading was designed to expose, and the grading in Table 3 now reflects the post-trial state of evidence rather than the pre-trial hopes: the Kuramoto import survives at structural grade, the Helfrich cost picture and the Kimura timing picture fall to heuristic grade, and the Euler identity remains an exact isomorphism because it is arithmetic, not analogy.

### 5.2 The consolidation picture and the mechanistic literature

Topological consolidation is compatible with, and organises, several strands of the mechanistic literature. The effective-theory account of grokking describes a transition from memorising to generalising representations with growing "generalisation circuits" [26]; circuit-efficiency accounts describe the replacement of dense memorising solutions by sparse, re-used circuits [42]; hidden-progress analyses document smooth internal change preceding the metric jump [33]; and the modular-arithmetic case shows the final circuit as a small set of structured components rather than a proliferation of loops [10], a reading consistent with topological analyses of trained networks [43]. The consolidation signature adds a topological reading of the same transition: the memorising solution is fragmenting, the generalising solution is connected and smooth, and the fragment-to-manifold reorganisation is what the homology and spectral statistics see. On this reading, the mirage debate [3,4] is addressed not by redefining emergence but by pairing any capability jump with the consolidation statistics and the density audit; a jump without consolidation is a metric artefact, a jump with consolidation is a representational event, and both judgements are cheap once the spectral-gap surrogate is calibrated.

The consolidation reading also reframes the reversibility results. Sub-critical perturbations recover because the consolidated manifold is locally attracting; sustained conflicting pressure rewrites it because nothing in the training dynamics protects the old circuit (E3); point edits revert or persist according to a measurable strength threshold (E4). For the alignment practice of closed-form model editing [29,44], the operational guidance is concrete: probe the edit's reversibility before deployment by the registered $\Psi_1$-return (or calibrated spectral-gap-return) criterion, and treat edits whose strength sits above the measured collapse boundary as behavioural rewrites rather than patches.

### 5.3 From toy scale to frontier scale, honestly

Every experiment here lives on one task and one small architecture. The transfer path is registered, not asserted: the evidence chain's L2 tier runs the density-conditioned audit and the spectral-gap surrogate over public checkpoint suites such as Pythia [34], where per-checkpoint activations can be sampled and the composition null of E8 can be computed properly; the L3 tier repeats the minimal lock-in and consolidation probes on a second architecture family, for which E11 provides the two-seed template. The observatory design (Section 6.3) exists precisely to make this path routine rather than bespoke. What this paper claims at scale is only the method: pre-commit the measurements, grade the analogies, calibrate the surrogates, and let the ledger record the answer.

### 5.4 Limitations

Five limitations bound the conclusions. (i) Scale: one small network, one task family; the grokking setting is a model of emergence, not an instance of frontier emergence, and all quantitative claims are scoped to it. (ii) Seeds: the main grid uses eight seeds, perturbation and editing protocols four, and the architecture pre-study two; several null results (E5, E10) have confidence intervals that would narrow with more seeds, and we mark them as falsified-at-this-scale rather than falsified absolutely. (iii) Metric definitions: $\Psi_1$, $r$ and the birth criterion required operationalisation choices (cloud standardisation, phase extraction, correlation threshold) that were locked before the main grid but after a calibration run on one seed; the calibration choices are released with the code. (iv) The Arrhenius and power-law families are not separated by the swept range (Section 4.2). (v) All experiments are computational; no claims here touch deployed systems. (vi) The main protocol's three-arm causal intervention is registered but not executed (Section 3); the deferral is a protocol event, logged in the released PROTOCOLS.md.

# Discussion additions

### 5.5 From correlation to cause at the measured scale

The three-arm result is the strongest evidence the programme has produced, and its limits are as important as its strength. The intervention manipulates the *output geometry* through an auxiliary loss, so the causal statement is exact at the level of the manipulated variable: at matched architecture, data and budget, forcing the geometry toward consolidation raises generalisation and preserving fragmentation suppresses it. What the experiment cannot do at this scale is separate the geometric pressure from a learning-rate or regularisation side effect of the auxiliary term; the control arm bounds the magnitude effect but not a possible optimisation-dynamics effect of equal magnitude in a different subspace. The registered follow-up therefore keeps the criterion fixed and adds a fourth arm in which the auxiliary loss targets the hidden-layer geometry rather than the output geometry, distinguishing readout-level from representation-level causes. That item is logged as pending, not as evidence.

### 5.6 What the surrogate registry changes

Three orders of magnitude of cheapness is not a technicality. In the framework the honest obstacle was that $\Psi_1$ is unaffordable at scale, which forced every large-model claim into the future tense. With the participation ratio and effective rank approved at $572\times$ and $911\times$ the cost of $\Psi_1$, the consolidation measurement reduces to an eigendecomposition of an activation matrix, comparable to a forward pass. The continuous tier of the evidence chain is therefore no longer compute-bound but access-bound: it needs checkpoint suites and activation sampling, which is exactly what the released pipeline provides. The registry also documents two rejected candidates and two provisional ones with informative signs, so that the next group does not re-derive that feature rank saturates on a 29-class lattice or that CKA tracks accuracy rather than geometry.

### 5.7 Honest negatives as protocol output

Four results in this paper are negative: the cheap audit proxy (0.71 balanced accuracy), the alignment-proxy topology signal ($\rho=-0.17$), the readout-norm circuit clock (degenerate at initialisation), and the width scaling of the consolidation endpoint (no monotone trend at $n=3$ per width). Under the framework's discipline these are outputs, and they narrow the space of what the framework may claim: it does not supply a topology-only safety monitor, it does not date circuit formation by readout norms, and it makes no size-scaling claim without density conditioning and adequate replication. The remaining positive claims are correspondingly sharper, which is the intended trade.


### 5.8 What the mechanism programme changes, and what it does not

Three mechanism statements survive contact with data and one does not. The landscape picture survives: the interpolation barrier (accuracy 0.042 at $\alpha = 0.283$) is direct evidence that memorisation and consolidation are distinct basins, which is the mechanistic content behind the abruptness the measurement programme documented. The signed-graph statement survives in a stronger form than expected: with 61% negative class pairs and a fourteen-fold difference in cycle rank between $|T|$ and the sign-respecting graph, any topological claim that ignores signs is measuring a different object, and the companion programme's non-negative $G$ cannot be substituted. The invariants survive because they are arithmetic. The energy account does not: the ledger closes, but the linear capacity law built on it fails ($R^2 = 0.03$ over a twentyfold range), and this failure is consistent with the companion programme's independent finding that geometric economy does not translate into capacity. The mechanism programme is therefore not a promissory note any more, but it is also not a theory of everything: it delivers one supported landscape statement, one corrected graph statement, three audit invariants, and one clean failure.

### 5.9 Granularity is the lesson, not a caveat

The revision's most consequential finding is negative and structural: $\Phi_c$ does not define a universal scalar. A single monotone map from the index to capability fails its registered test twice (LOO $R^2$ 0.32 within the feed-forward family, 0.21 across recurrent families), and the family means differ by more than a unit across intervention arms. This is not a nuisance to be smoothed away with more data; it says that the index is a *within-system* marker whose meaning is fixed by the granularity at which it is computed. The consequence for practice is concrete: report seed, architecture, scale and checkpoint with every value (Table 18), never compare $\Phi_c$ across granularities without labels, and treat cross-system statements as hypotheses requiring their own test. The same discipline applies to the causal claim, which holds at the arm level ($\Delta = 0.277$) but not as a dose-response ($R^2 = 0.16$). Both restrictions are registered as outputs rather than apologised for, and they are the reason the framework can now be used without being believed wholesale.

## Discussion: cross-scale extension

### 5.10 Integration as the transportable claim

The results point to a division of labour among the framework's quantities. Output-geometry consolidation is real, causal at the readout, and separated from memorisation by a measured barrier; but its single-scale markers do not predict capability well and their signs are not portable, as the language-model ladder shows (the spectral gap rises where the feed-forward networks' gap fell). Cross-layer integration behaves differently. It is defined relationally, rises with capability, survives a partial-correlation control, and its direction is necessary under ablation. If one claim from this programme is to travel to other architectures and scales, it should be the integration claim, with consolidation reported as a secondary marker whose sign is checked rather than assumed.

This also reframes the mirage dispute. The dispute is usually staged as "is emergence real or is it a metric artefact". The measurements here say that both halves are partly right and that the halves are separable: onset times move by thousands of steps when the capability definition changes, while the terminal state and the integration index do not. A paper that reports only an onset step is therefore reporting the fragile half. A paper that reports the terminal integration state alongside it is reporting the half that survives changes of metric.

### 5.11 Boundary conditions, stated as a result

The most useful sentence in a study of this kind is the one that says where it stops. The framework as tested covers feed-forward and linear-recurrent networks that exhibit a fragmented early geometry, at the task and budget scales reported, and it covers a small depth ladder of in-house language models. It does not cover the attention configuration at the tested budget, RetNet-style mixers with degenerate initial geometry, mixture-of-experts routing, or any public checkpoint, because the execution environment had no outbound network. Those are not caveats appended to the claims; they are the boundary of the claims, and Table 30 lists them item by item so that a reader can see exactly which tier is missing.

The next test is specified rather than promised. Run the released checkpoint pipeline on a Pythia-70M-to-1B ladder, compute the integration index and the density-conditioned audit at every checkpoint, and ask whether $\Lambda$ rises with the loss drop and whether any capability onset coincides with it. If $\Lambda$ fails to rise there, the integration claim is scoped to small models and the framework's transportable content reduces to the measurement programme itself. Either outcome is informative, and the pipeline is written so that the answer arrives without further design work.

## 6 Materials and methods

### 6.1 Models, training and preregistration

The main model (MLP family) embeds each operand with a $128$-dimensional table, concatenates the two embeddings, applies one hidden layer of $100$ ReLU units, and reads out $p = 29$ logits; the attention family (used in E8) is a one-layer, two-head attention-only Transformer over the three-token sequence [8,10,45]. Tasks are $(a+b) \bmod 29$ and $(a-b) \bmod 29$ over the full $29^2$ instance lattice, split 50/50 train/validation. Training is full-batch AdamW, learning rate $10^{-3}$ (swept in E2), weight decay $2.0$ (transformer: $1.0$), for up to 60,000 steps (120,000 at the lowest learning rate), with eight (E1), four (E2, E3, E4) and six (E5) independent seeds per condition as registered. The protocol family Exp-LLM-20261013 and sub-protocols A to D, including all thresholds reported in Table 2, were locked before the corresponding data collection; a single-seed calibration run preceded metric locking and is released alongside. No threshold was modified after data collection; where a criterion proved ill-posed (E8) the refinement is reported as a protocol output, not a retroactive edit.

### 6.2 Measurements

$\Psi_1$: activations or logits for a fixed prompt set, standardised per coordinate and projected to the unit sphere (300-point subsample, fixed seed), cosine distance matrix, Vietoris-Rips filtration to dimension one (Ripser), total persistence of the one-dimensional diagram. $r_\mathrm{logit}$: Pearson correlation, over 20,000 random prompt pairs, between output-geometry cosine similarity and the class-cycle kernel $\cos(2\pi |s_i - s_j|_p / p)$. Circuit phase and $r$: class-mean vectors standardised, top two principal components, phase $\theta_c = \mathrm{atan2}$ of the projection, order parameter maximised over orientation and shift as in Section 2.2. Spectral gap: symmetric k-nearest-neighbour graph ($k = 10$) on the same cloud, normalised Laplacian, eigengap $\lambda_2 - \lambda_1$; TwoNN intrinsic dimension per [46,47], a standard geometric readout for trained networks [48]. Barcodes compared by exact 1-Wasserstein distance [49]. Attention-adjacency and graph statistics in E6 use thresholded attention maps and exact union-find components; NetworkX supplies the open networks [31,32]. Editing (E4): rank-one output-weight update along the edited prompt's normalised hidden direction plus a bias term, strength $\varepsilon \in \{0.25, 0.5, 1, 2, 4, 8\}$ logit units, 400-step fine-tuning window at learning rate $10^{-4}$, twelve prompts per condition, weights reloaded between prompts. Budget transfer (E5): fresh twins trained for $0.3\tau$ or $3\tau$ steps on $(a+b)$, then steps to 0.5 validation accuracy on $(a-b)$, capped at 30,000. Rewiring (E10): every 100 steps the incoming weights of a random $\theta$-fraction of hidden units are decayed by 10%; $\tau$, final accuracy, and a 1,500-step recovery from a fixed $\epsilon = 0.1$ output perturbation define $Q = 0.6\,\mathrm{val} + 0.4\,\mathrm{rev}$. Statistics: Spearman correlations, ordinary least squares with bootstrap confidence intervals where noted, Wilcoxon signed-rank for paired transfer costs, Kolmogorov-Smirnov for distributional forms; all tests two-sided, $\alpha = 0.05$, with the preregistered thresholds of Table 2 taking precedence over bare significance.

### 6.3 Emergence observatory design

A standing mechanism to accumulate evidence across models and time is part of the design. The design that this paper's calibrated measurements support has three layers. A data layer indexes public checkpoint suites [34] with standardised activation sampling. A computation layer runs the two approved statistics, the spectral gap (calibrated in E9) and the density-conditioned audit (E6), plus the composition-controlled stationarity null (E8), on every checkpoint; the cost per checkpoint is dominated by one forward pass and a partial eigendecomposition, well within routine budgets. A reporting layer publishes, per model lineage, the consolidation trajectory and the audit-resolved scaling coefficients, with the same preregistration discipline used here: claims about a new model's emergence are filed with target statistics and thresholds before the checkpoints are pulled. The observatory is a design commitment, not a running service, and is released as schema and reference implementation in the accompanying package.

### 6.4 Data and code availability

All code (training, measurement, protocol runners, figure generation), all per-run result records (JSON), the analysis summary, the preregistration protocol family, and the figure sources are packaged for reuse. The two network datasets shown in Fig 7b are the classic open social networks distributed with NetworkX [31], including Zachary's karate club [32] and the Les Misérables interaction graph [50].

### 6.5 Protocols added in this revision

**Three-arm intervention (main protocol v2.0).** The auxiliary geometry pressure is defined on the output cloud of each batch: participation ratio $\mathrm{PR}(Z) = (\sum_i \lambda_i)^2 / \sum_i \lambda_i^2$ of the centred logit matrix, normalised by the class count and added with weight $\lambda = 0.05$ relative to the cross-entropy. Arm A1 minimises the normalised PR; arm A2 maximises it; arm A3 minimises the PR of a fixed random ten-dimensional marginal of the same logits, providing an equal-magnitude, content-free pressure. The marginal is fixed per seed. Eight seeds per arm, identical data, optimiser and budget, early stop when validation accuracy reaches 0.9 or 8,000 steps past onset, cap 40,000 steps. Primary outcome: final validation accuracy difference between A1 and A3 with a 10,000-sample bootstrap 95% CI; the registered criterion, the change log and both version files are released.

**Extended grid and power analysis.** The main grid comprises 32 seeds (the eight of the previous protocol and 24 new ones) of the same architecture, task split, optimiser (AdamW [51],[52], learning rate $10^{-3}$, weight decay 2.0) and 48,000-step budget with probes every 4,000 steps. Power was estimated by simulation (4,000 replicates per point) for the two-sample comparison at the registered effect size 0.15 using the grid's observed standard deviation. The hierarchical summary treats the per-seed final accuracy as normal with unknown mean and the sample standard deviation, reporting a 95% highest-density interval on a 2,001-point grid.

**Cross-architecture families.** Three minimal linear-recurrent families are trained on the same task with eight seeds each: a diagonal-gated state-space mixer; an RWKV-style time-mix [53] with a learned per-channel interpolation gate; and a RetNet-style decayed linear-attention mixer [38]. Each family has a two-layer composition head (linear, ReLU, linear) so that the same function class is reachable; the protocol, including the attention configuration's failure to reach the criterion, is reported as measured. These are minimal two-token analogues, not scaled implementations of the published architectures, and are labelled as such wherever they appear.

**Surrogate registry.** Twelve candidates are evaluated on 66 matched checkpoints (six seeds, probes every 5,000 steps to 50,000) against $\Psi_1$ and against accuracy, with per-metric wall-clock timing accumulated over the same checkpoints. Approvals require $|\rho| \geq 0.9$ against $\Psi_1$ and at least tenfold speed-up; $|\rho| \geq 0.7$ is provisional; below that, or degenerate (constant or saturated), is rejected. Metric definitions: spectral gap of the symmetric ten-nearest-neighbour normalised Laplacian [54] of the cosine-similarity graph; participation ratio; stable rank $\|A\|_F^2 / \sigma_1^2$; effective rank $\exp(-\sum p_i \ln p_i)$ of the singular-value distribution; PCA-95 dimension; TwoNN intrinsic dimension; kNN label consistency at $k = 10$; class silhouette; feature rank of the class-mean matrix; Jacobian rank of the class logits with respect to the concatenated embeddings; linear CKA to the final class-mean profile; and $\Psi_1$ itself as the reference.

**Audit, alignment proxy and early stop.** The audit applies rank-one output edits of strength $\varepsilon$ and measures persistence (immediate), rebound (after a 400-step window at learning rate $10^{-4}$), and the relative change of the spectral gap; the predictive value of the gap change is evaluated by a threshold scan with balanced accuracy against the directly measured rebound outcome. The alignment proxy fine-tunes consolidated checkpoints for 500 steps at learning rate $10^{-4}$ on training sets with 2%, 5%, 10% and 20% of labels flipped, measuring behavioural damage against the clean validation set and the relative change of the spectral gap. The early-stop rule is stated as a criterion, not tuned: stop when the spectral gap first falls below 20% of its initial value; savings and accuracy gaps are then measured against the full budget.

### 6.6 Tools, packaging and reproducibility

Two small packages accompany the paper. `density_audit` implements the graphical identity check, the density-conditioned regression and the inflation demonstration, with unit tests reproducing the paper's numbers and a command-line interface. `emergence_monitor` implements checkpoint-level spectral-gap and participation-ratio computation, change-point detection for the consolidation transition, a training callback shim and a static HTML dashboard; a demonstration dashboard built from the released trajectories is included. The repository is laid out for direct upload: code, per-run records in JSON, per-figure data exports in CSV, figure sources, the protocol documents and a reproducibility checklist following the machine-learning reproducibility guidelines [55]. Every figure is generated by a script in the repository, and the numerical claims of the paper are cross-checked by an automated verification script that recomputes each reported quantity from the released records. The version history of the protocols is kept in a change log with a one-line reason per change (Table 15).

### 6.7 Venue, declarations and supplementary organisation

The manuscript is prepared for PLOS Computational Biology: single-column main text, numbered citations in order of first appearance, a data-availability statement and a code-availability statement, an author-contributions statement and a competing-interests statement. Supporting information is organised as: S1 theory notes (assumption register, consolidation-index algebra); S2 experimental protocols (the three-arm protocol and its change log, the surrogate registry specification, the audit protocol); S3 full result tables (per-seed records for every family); S4 hyperparameters; S5 code and data inventory; S6 reproducibility checklist. Each main figure has a machine-readable data export.

## Data and code availability

All training code, measurement code, per-run records, the analysis summaries, the automated verification report, the two protocol packages, the toolkit packages with their unit tests, the figure-generation scripts and the per-figure data exports are contained in the accompanying repository, which is structured for direct upload. No personal or sensitive data are used. The two network datasets in the audit figure are the classic open social networks distributed with NetworkX.

## Author contributions

S.Z. designed the framework, the protocols, the experiments and the analyses, wrote the code, executed the experiments and wrote the manuscript.

## Competing interests

The author declares no competing interests.


### 6.8 Protocols added in this revision

**Barrier landscape.** For three seeds, a memorisation-phase checkpoint is saved at step 4,000 and the consolidated solution at the point where validation accuracy reaches 0.92. The interpolation $W(\alpha) = (1-\alpha)W_\mathrm{mem} + \alpha W_\mathrm{fin}$ is evaluated at 41 equally spaced $\alpha$; at each point validation accuracy, cross-entropy, $\Psi_1$, spectral gap, intrinsic dimension and the signed-graph statistics are recorded. The barrier is the minimum accuracy along the path and its location $\alpha_\mathrm{min}$; the two-basin interpretation would be refuted by a monotone path.

**Signed graph.** For each checkpoint, class-mean activation vectors $\bar h_c$ are computed over the validation prompts, standardised per coordinate and correlated across classes; the negative fraction, the strongly negative fraction ($<-0.2$) and the cycle rank of two thresholded graphs are recorded: the absolute-value graph $|T|$ at the 75th percentile of $|T|$, and the sign-respecting graph keeping only positive edges at the same density. Substitutability would be refuted if the two cycle ranks differed materially; they differ by a factor of about 25.

**U_rep test (registered).** The proposal and its threshold ($R^2 \geq 0.80$, leave-one-run-out) were registered before the test. The map is fitted as a three-parameter logistic on all runs but one and evaluated on the held-out run; runs with a degenerate baseline ($s_g^{(0)} < 0.01$) are excluded and reported as excluded rather than imputed. Two evaluations are reported: the feed-forward family (64 runs) and the recurrent families (18 runs).

**Dose-response, energy ledger, invariance.** The dose-response regresses the per-seed accuracy difference between A1 and A3 on the corresponding participation-ratio difference (eight pairs). The energy ledger regresses final accuracy on $\log_{10}(6 \cdot N_\mathrm{params} \cdot \mathrm{steps})$ across four widths and the 24-seed grid; the accounting identity itself is reported separately from the behavioural law. Invariance is tested by recomputing $\Phi_c$ with a global reference baseline and comparing the ranking of 24 runs by Spearman correlation.

### 6.9 Methods added in this revision

**Language models and corpus.** Decoder-only Transformers with pre-norm blocks, learned positional embeddings, a vocabulary of four task markers plus 60 data symbols, and sequences of 24 tokens. Depth 2, 4 or 6; width 64; two heads; feed-forward width four times the model width. The corpus is generated on the fly: the first token selects one of four in-context rules (copy, successor, affine with multiplier two plus one, position shift), and the target at each subsequent position is the rule's output. Training uses AdamW with learning rate $3\times10^{-3}$, weight decay 0.05, batch 24, gradient clipping at 1.0 and 1,500 steps; two seeds per depth.

**Integration index.** Hidden states are captured at every layer for a fixed probe set of 96 sequences. Position-averaged representations are compared by linear CKA, and $\Lambda$ is the mean adjacent-layer CKA minus the mean CKA of pairs at distance two or more. The index is undefined for two layers and reported as such rather than imputed.

**Activation patching.** Following the metric conventions recommended for patching studies (clean-versus-corrupted prompts, matched baselines, rank-based statistics) [59], at layer 2 the integration direction is the first principal component of the four task-conditioned mean activations. A forward hook adds the direction at one activation standard deviation, subtracts it, or projects it out at every position. Ten random unit directions of equal norm provide the null, and a feature-level version of the same contrast through sparse autoencoders [58] is specified but not executed here, and $z$ scores are computed against that null.

**Granularity-free index.** Activations are clustered by $k$-means at $k \in \{4,8,16,32\}$. Inside each cluster, spectral gap and participation ratio are computed after standardisation and sphere projection, converted to $z$ scores against 20 Gaussian null clouds of matched shape, passed through a logistic map, averaged over the two channels and over clusters, and reported at each resolution and as their maximum.

**Analogy audit.** Wright-Fisher first-passage times are simulated in vectorised form for $N_e \in \{50,100,200,400\}$ and $s \in \{0.05,0.1,0.2,0.4\}$, with fixation defined as absorption at 0 or 1 and a cap of 40,000 generations. The grid is scored by the distance between simulated and empirical coefficients of variation; the best setting is then simulated with 5,000 replicates and compared to the 232 empirical birth times by Kolmogorov-Smirnov after rescaling to unit mean.

**Sparse graph benchmark.** Synthetic signed graphs are built from eight-dimensional latent factors with $n \in \{200,500,1000\}$; dense edges are those above the 98th percentile of absolute correlation, and the two sparse estimators are a top-six neighbour rule and a two-stage rule with twelve candidates per node, screened by an $\ell_1$-penalised regression [60]. Cycle rank is computed exactly by union-find, and fidelity is reported as relative error against the dense graph.

**Public-checkpoint pipeline.** The released script loads a HuggingFace checkpoint, samples activations on a fixed corpus, computes spectral gap and participation ratio per layer, runs the density-conditioned audit on attention-derived graphs, and stores per-checkpoint records. It is not executed here; the execution environment has no outbound network, and the constraint is recorded in Table 30 rather than worked around.

## Tables

**Table 1. The five-variable framework and its realisations in this study.**

| Variable | Meaning | Realisation here |
|---|---|---|
| $G$ | Geometry of the representation manifold | Intrinsic dimension, spectral gap of the output cloud |
| $E$ | Energy/rewiring budget | Training steps; turnover fraction $\theta$ in E10 |
| $I$ | Representation distribution | Prompt-activation and logit clouds |
| $T$ | Interaction topology | Attention adjacency (training); frozen at inference |
| $\Phi$ | Integrated order parameter | $\Psi_1$ (registered); $r$, $r_\mathrm{logit}$ (circuit level) |

**Table 2. The preregistered prediction ledger with priority tiers and verdicts.**

| ID | Prediction | Tier | Pre-written criterion | Observed | Verdict |
|---|---|---|---|---|---|
| P-$\Phi$ | $\Psi_1$ jumps in lock with capability | Core | Time-locked upward jump | $\Psi_1$ collapses; $\rho(\Psi_1, \mathrm{val}) = -0.994$; lock offset median 10,000 steps | Direction-reversed |
| P-ID | Scaling claims pass density audit | Core | Conditioned $b \to 1$; naive $b$ inflated | $b = 0.997$ conditioned vs 1.43 naive; identity exact on real networks | Supported |
| P-Rev | Saddle-node grokking resists reversal | Core | No return of order parameter after reversal | Recovery under sub-critical perturbation; inversion rewrites circuit | Partially supported |
| P-Stat | Inference topology stationary; edits show rebound-collapse threshold | Core | Threshold in edit strength; stationarity vs composition null | Threshold window $[0.5, 2.0]$; determinism exact; naive criterion refined | Supported (refined) |
| P-Arr | Delay scales as $\exp(\beta/\eta)$ | Auxiliary | $R^2 \geq 0.85$, slope CI excludes 0 | $R^2 = 0.978$, $\beta = 0.96$, $p = 0.011$ | Supported |
| P-Kim | Circuit births follow waiting distribution | Auxiliary | Exponential tail (KS fail to reject) | Staggered, CV = 0.40; exponential and lognormal rejected | Partially supported |
| P-E1 | Budget truncation cuts re-plasticity | Auxiliary | Transfer cost increases after truncation | 7,767 vs 8,067 steps; $p = 0.84$, 4/6 reversed | Falsified |
| P-E2 | Loop augmentation lowers $\tau$ and buys reversibility | Auxiliary | 30% or greater reduction in the grokking step; reversibility gain | No reversibility gain at any $\theta$; $\tau$ unchanged | Falsified (at this operationalisation) |
| P-E3 | Quality peaks at $\theta^* \approx 0.20$ | Exploratory | Peak CI within $[0.15, 0.25]$ | Flat/dipping curve; no peak at 0.20 | Falsified |
| P-Cross | Lock-in signature crosses architecture | Exploratory | Order-parameter rise in SSM | Rise in 2/2 SSM seeds | Provisionally supported (toy) |

**Table 3. Analogy precision grades after adjudication (expert P0 item).**

| Mapping | Source domain | Target here | Grade (pre) | Grade (post-trial) | Basis |
|---|---|---|---|---|---|
| Euler identity $\beta_1 = n(\bar{k}/2-1)+c$ | Graph theory | Attention/feature graphs | Exact | Exact | Arithmetic identity; holds by construction |
| Gauss-Bonnet audit | Differential geometry | Manifold scale claims | Exact-continuous | Exact-continuous | Theorem; applied as a gate |
| Arrhenius delay $\tau = A e^{\Delta E^\ddagger / T}$ | Chemical kinetics | Grokking delay vs $\eta$ | Structural | Structural (regularity confirmed; family not unique at this range) | E2 |
| Kuramoto lock-in $r$ | Nonlinear dynamics | Circuit phase alignment | Structural | Structural (within-run) / Heuristic (across seeds) | E1 |
| Persistent-homology "inference loops" | Topological data analysis | Output-cloud $\Psi_1$ | Structural | Structural, direction reversed | E1 |
| Helfrich rewiring cost / energy gate | Membrane elasticity | Budget-truncation plasticity | Structural | Heuristic (gate not observed) | E5, E10 |
| Kimura fixation of circuits | Population genetics | Circuit birth times | Heuristic | Heuristic (staggering yes; law no) | E7 |
| Maynard Smith ESS lock-in | Evolutionary game theory | Edit/inversion resistance | Structural | Heuristic (threshold yes; basin no) | E3, E4 |




**Table 4. Three-arm causal intervention (main protocol v2.0), eight seeds per arm.**

| Arm | Intervention (equal magnitude, direction differs) | Mean final accuracy | Median onset | Final gap | Final PR | Final $\Psi_1$ | Verdict |
|---|---|---|---|---|---|---|---|
| A0 | none (baseline) | 0.822 | 11,000 | 0.146 | 24.5 | 37.1 | reference |
| A1 | consolidation induction (lower participation ratio) | 0.942 | 6,000 | 0.001 | 2.7 | 1.4 | **supported** |
| A2 | fragmentation preservation (raise participation ratio) | 0.671 | 17,000 | 0.288 | 28.1 | 55.7 | suppression |
| A3 | random-marginal control (identical magnitude) | 0.665 | 11,000 | 0.013 | 1.8 | 10.3 | control |

Registered criterion: $\Delta(\mathrm{A1}-\mathrm{A3}) > 0.15$ with 95% CI excluding zero. Observed $\Delta = 0.277$, CI $[0.197, 0.374]$: criterion met.

**Table 5. Main grid at 32 seeds.**

| Quantity | Value |
|---|---|
| Seeds | 32 (8 original + 24 extension, matched protocol) |
| Mean final accuracy (95% CI) | 0.929 (hierarchical 95% HDI $[0.905, 0.953]$) |
| $\rho(\Psi_1, \mathrm{acc})$ | $-0.936$ |
| $\rho(\mathrm{spectral\ gap}, \mathrm{acc})$ | $-0.911$ |
| $\rho(\mathrm{intrinsic\ dim}, \mathrm{acc})$ | $-0.855$ |
| $\rho(r_\mathrm{logit}, \mathrm{acc})$ | $0.226$ (seed-fragile) |
| Median $\Psi_1$ collapse | 1.95-fold |
| Median spectral-gap collapse | 8.2-fold |
| Power to detect $\Delta=0.15$ at $n$ seeds/arm | $n=4$: 0.56; $n=8$: 0.93; $n=16$: 0.999 |

**Table 6. Cross-architecture replication (8 seeds per family).**

| Family | Mean final acc | Min | Median onset | Median gap early $\to$ final | Runs consolidated | Note |
|---|---|---|---|---|---|---|
| State-space mixer | 0.932 | 0.900 | 6,000 | 0.150 $\to$ 0.028 | 8/8 | consolidation present |
| RWKV-style gated mixer | 0.987 | 0.943 | 4,000 | 0.129 $\to$ 0.009 | 8/8 | consolidation present |
| RetNet-style decayed mixer | 0.919 | 0.903 | 7,000 | 0.004 $\to$ 0.048 | 0/8 | degenerate initial geometry |
| Attention + MLP head | $<0.5$ | — | — | — | — | criterion not reached in 20k–60k (2 attestations) |

**Table 7. Multi-skill lattice proxy (continuous-tier stand-in; 2 seeds).**

| Skill | Difficulty | Onset (accuracy 0.5) | Final accuracy |
|---|---|---|---|
| Copy | easy | 2,000 | 0.985 |
| Negate | easy | 2,000 | 0.980 |
| Addition | hard | not reached by 58,000 | 0.40 |
| Subtraction | hard | not reached by 58,000 | 0.40 |

Geometry follows completeness, not the clock: spectral gap 0.10–0.14 initially and 0.208 at the end, because the hard skills never consolidate.

**Table 8. Capability metric definitions and apparent onsets (2 seeds).**

| Metric definition | Mean onset | Final capability |
|---|---|---|
| Exact-match accuracy | 14,250 | 0.96 |
| Accuracy at margin $> 0$ | 14,250 | 0.96 |
| Continuous margin capability | 14,500 | 0.93 |
| Accuracy at margin $> 1$ | 18,250 | 0.86 |
| Metric-stable statement | — | within-run terminal spread $\leq 0.09$; across-seed variation dominates |

**Table 9. Ordering of the clocks (means).**

| Clock | Instrument | Mean time |
|---|---|---|
| Class-circuit births | profile convergence > 0.8 (232 births) | 8,078 |
| Critical-set consolidation | readout-norm share (ablation-verified set) | ablation: 20 units carry 0.20 accuracy |
| Capability onset | accuracy definitions | 14,250 |
| Geometric consolidation completion | gap at 50% of initial | 29,500 |

**Table 10. Surrogate registry (67 checkpoints, six seeds, per-metric timing).**

| Candidate | $\rho$ with $\Psi_1$ | Speed-up vs $\Psi_1$ | Verdict |
|---|---|---|---|
| Spectral gap | 0.966 | 25$\times$ | approved |
| Participation ratio | 0.948 | 572$\times$ | approved |
| Effective rank | 0.940 | 911$\times$ | approved |
| PCA-95 dimension | 0.911 | — | approved |
| TwoNN intrinsic dimension | 0.908 | 2.2$\times$ | provisional |
| Stable rank | 0.822 | — | provisional |
| kNN label consistency | $-0.762$ | — | provisional |
| Class silhouette | $-0.759$ | — | provisional |
| CKA to final representation | $-0.497$ ($0.862$ with accuracy) | — | provisional (accuracy-oriented) |
| Feature rank | undefined (saturated) | — | rejected |
| Jacobian rank | undefined (degenerate) | — | rejected |

**Table 11. Terminology and orientation mapping (the framework $\to$ the framework).**

| the framework term / orientation | the framework term / orientation | Evidence forcing the change |
|---|---|---|
| "Loop crystallisation"; $\Psi_1 \uparrow$ signals emergence | "Topological consolidation"; $\Psi_1 \downarrow$ signals emergence | the framework/the framework grids: $\rho(\Psi_1,\mathrm{acc}) = -0.936$ (n=32) |
| $\Phi$ rises with loop inventory | $\Phi_c$ rises as $\Psi_1, s_g, I_d$ fall | Section 2.5 |
| "Inference loops" as the emergent object | Fragmented-neck inventory as the pre-transition object | Sections 4.1, 4.16 |
| Energy gate freezes rewiring (P-E1) | Gate hypothesis demoted to conditional | Section 4.5, falsified |
| Static-dynamic ratio optimum $\theta^* = 0.20$ | No registered optimum; curve flat | Section 4.10, falsified |

**Table 12. Assumptions and current status.**

| ID | Assumption | Status |
|---|---|---|
| A1 | The output cloud is a faithful readout of task representation geometry | supported (ablation and surrogate agreement) |
| A2 | Inference is deterministic and stationary | supported; composition-null criterion adopted |
| A3 | Consolidation and generalisation are coupled | causal under intervention (Section 4.11) |
| A4 | Reversibility is decided by a bounded rebound probe | supported as instrument; topology-only proxy rejected |
| A5 | A consumable rewiring budget gates structural change | conditional; P-E1 falsified at this scale |
| A6 | Density must be conditioned before any scaling claim | supported (arithmetic identity; audit) |

**Table 13. Relations to existing accounts.**

| Account | Overlap | Increment contributed here |
|---|---|---|
| Emergence-as-mirage | Metric fragility of onsets | Decomposition into fragile onsets and a robust terminal state |
| Effective theory of grokking | Memorisation to generalisation replacement | Geometric signature of the replacement; ordering with circuit birth |
| Circuit efficiency | Sparse generalising circuits | Ablation-verified critical set (20 units, 0.20 accuracy) |
| Hidden progress | Smooth internal change before metric jumps | Per-class birth clock; staggered onsets |
| Scaling laws | Smooth loss scaling | Density audit as a required control for topological quantities |
| Model editing | Localised factual edits | Validated rebound decision procedure; explicit proxy negative |
| Synchronisation and TDA | Order parameters and persistence | Calibrated surrogate family; causal intervention |

**Table 14. Roadmap execution summary (25 items, six dimensions).**

| Dimension | Items | Executed here | Deferred (with reason) |
|---|---|---|---|
| D1 theory | 4 | terminology turn, precision matrix, assumptions memo, relations section, consolidation index | — |
| D2 experiments | 5 | three-arm causal v2.0, 32-seed grid + power, cross-architecture (3 families $\times$ 8 seeds), multi-skill proxy + released checkpoint pipeline, seed extension | continuous tier on Pythia/OLMo (no download budget), true Mamba/RWKV/RetNet at scale |
| D3 methodology | 4 | protocol repository + change log, 12-candidate registry, density-audit toolkit with tests and CLI, container-ready layout, per-figure data exports | continuous integration service |
| D4 literature | 4 | mirage decomposition experiment, circuit-topology coupling, scaling-relation caution, editing-protocol link | automated circuit discovery [56],[57] (ACDC) at scale |
| D5 applications | 4 | audit protocol + flowchart + validated probe, monitor package with CLI and dashboard, early-stop rule (34% saving), alignment proxy (honest negative) | RLHF-scale safety evaluation |
| D6 presentation | 4 | venue formatting and declarations, contributions $\leq 5$, figure style guide and vector export, structured appendices and reproducibility checklist | journal-specific two-column production |

**Table 15. Protocol version history (change log, abbreviated).**

| Version | Date | Change | Reason |
|---|---|---|---|
| v1.0 | 2026-10-13 | initial registration, eight predictions, sub-protocols A–D | framework as published in the framework/the framework |
| v2.0 | 2026-10-13 | main-protocol intervention redesigned: label-free geometry pressure (participation ratio) replaces class-consistency loss; new control arm (random ten-dimensional marginal); $\Delta$ criterion unchanged | v1.0 arm definition leaked class structure (2,000-step trivial generalisation) and its control was mathematically equivalent to the treatment; the redesign preserves the registered criterion |


**Table 24. Depth ladder (two seeds per depth; four-rule corpus).**

| Depth | Final accuracy | Onset step | $\Lambda$ (final) | Spectral gap (final) | Participation ratio (final) |
|---|---|---|---|---|---|
| 2 layers | 0.994 | 750 | undefined | 0.108 / 0.158 | 29.0 / 28.0 |
| 4 layers | 0.942 | 750 | 0.306 | 0.070 / 0.091 | 27.3 / 29.8 |
| 6 layers | 0.956 | 1,000 | 0.300 | 0.064 / 0.206 | 26.7 / 29.5 |

**Table 25. What predicts capability on the integration probes (28 probes, four- and six-layer runs).**

| Predictor | Spearman $\rho$ with accuracy | Partial $\rho$ given spectral gap |
|---|---|---|
| Integration index $\Lambda$ | 0.693 | 0.739 |
| Spectral gap | 0.172 | — |
| Participation ratio | 0.163 | — |

$\rho(\Lambda, s_g) = 0.106$: the relational and single-scale markers are nearly independent.

**Table 26. Activation patching at layer 2 (base accuracy 0.911).**

| Manipulation | Integration direction | Random directions (mean of 10) | $z$ |
|---|---|---|---|
| Add at 1 s.d. | 0.899 | 0.909 | $-1.1$ |
| Subtract at 1 s.d. | 0.901 | 0.911 | $-1.3$ |
| Project out | 0.755 | 0.911 | $-5.6$ |

**Table 27. Granularity-free index across resolutions.**

| Clusters per scale | 4 | 8 | 16 | 32 |
|---|---|---|---|---|
| Null-calibrated index | 0.937 | 0.708 | 0.666 | 0.789 |

Reported value: maximum 0.937, spread 0.271 across resolutions.

**Table 28. Analogy audit for circuit birth times.**

| Quantity | Empirical | Best Wright-Fisher fit | Verdict |
|---|---|---|---|
| Coefficient of variation | 0.402 | 0.867 ($N_e = 50$, $s = 0.4$) | over-dispersed |
| KS test (rescaled) | — | $p < 10^{-3}$ | rejected |
| Grade | — | — | heuristic (promotion refused) |

**Table 29. Sparse signed-graph estimators against the dense graph.**

| $n$ | $\beta_1$ dense | Top-$k$: $\beta_1$ / rel. error | Hierarchical: $\beta_1$ / rel. error |
|---|---|---|---|
| 200 | 203 | 527 / 160% | 1,072 / 428% |
| 500 | 1,996 | 1,304 / 35% | 2,683 / 34% |
| 1,000 | 8,991 | 2,611 / 71% | 5,326 / 41% |

**Table 30. Scale and execution ledger.**

| Tier | Content | Status |
|---|---|---|
| In-house depth ladder | 2/4/6 layers, two seeds, four-rule corpus | executed |
| In-house width ladder | hidden width 50-400, three seeds | executed |
| Cross-architecture | state-space, RWKV-style, RetNet-style, eight seeds | executed |
| Public checkpoints (Pythia, OLMo) | spectral gap, participation ratio, density audit, composition-null stationarity | scripted, **not executed**: no outbound network in the execution environment |
| Sparse autoencoders | feature extraction and activation patching at checkpoint scale | scripted, not executed (compute-bound) |
| MoE architectures | integration index on mixture-of-experts routing | not executed (no accessible weights) |

## References

[1] Zhang S. A unified programme for intelligence theory, the framework: terminology, claim tiers and test protocols. Technical report. 2026.

[2] Wei J, Tay Y, Bommasani R, Raffel C, Zoph B, Borgeaud S, et al. Emergent abilities of large language models. Transactions on Machine Learning Research. 2022.

[3] Schaeffer R, Miranda B, Koyejo S. Are emergent abilities of large language models a mirage? Advances in Neural Information Processing Systems. 2023;36.

[4] Srivastava A, Rastogi A, Rao A, Shoeb AAM, Abid A, Fisch A, et al. Beyond the Imitation Game: Quantifying and extrapolating the capabilities of language models. Transactions on Machine Learning Research. 2023.

[5] Ganguli D, Hernandez D, Lovitt L, Askell A, Bai Y, Chen A, et al. Predictability and unpredictability in large language models. Transactions on Machine Learning Research. 2024.

[6] Kaplan J, McCandlish S, Henighan T, Brown TB, Chess B, Child R, et al. Scaling laws for neural language models. arXiv:2001.08361. 2020.

[7] Hoffmann J, Borgeaud S, Mensch A, Buchatskaya E, Cai T, Rutherford E, et al. Training compute-optimal large language models. Advances in Neural Information Processing Systems. 2022;35.

[8] Olsson C, Elhage N, Nanda N, Joseph N, DasSarma N, Henighan T, et al. In-context learning and induction heads. Transformer Circuits Thread. 2022.

[9] Wang K, Variengien A, Conmy A, Shlegeris B, Steinhardt J. Interpretability in the wild: A circuit for indirect object identification in GPT-2 small. International Conference on Learning Representations. 2023.

[10] Nanda N, Lee A, Wattenberg M. Emergent linear representations in world models of self-supervised sequence models. In: Proceedings of the 6th BlackboxNLP Workshop. 2023.

[11] Carlsson G. Topology and data. Bulletin of the American Mathematical Society. 2009;46(2):255-308.

[12] Edelsbrunner H, Harer J. Computational Topology: An Introduction. American Mathematical Society; 2010.

[13] Kuramoto Y. Chemical Oscillations, Waves, and Turbulence. Springer; 1984.

[14] Acebrón JA, Bonilla LL, Pérez Vicente CJ, Ritort F, Spigler R. The Kuramoto model: A simple paradigm for synchronization phenomena. Reviews of Modern Physics. 2005;77(1):137-185.

[15] Helfrich W. Elastic properties of lipid bilayers: Theory and possible experiments. Zeitschrift für Naturforschung C. 1973;28(11):693-703.

[16] Power A, Burda Y, Edwards H, Babuschkin I, Misra V. Grokking: Generalization beyond overfitting on small algorithmic datasets. arXiv:2201.02177. 2022.

[17] Strogatz SH. From Kuramoto to Crawford: Exploring the onset of synchronization in populations of coupled oscillators. Physica D. 2000;143(1-4):1-20.

[18] Kimura M. On the probability of fixation of mutant genes in a population. Genetics. 1962;47(6):713-719.

[19] Maynard Smith J. Evolution and the Theory of Games. Cambridge University Press; 1982.

[20] Diestel R. Graph Theory. 5th ed. Springer; 2017.

[21] do Carmo MP. Differential Geometry of Curves and Surfaces. Prentice-Hall; 1976.

[22] Nosek BA, Ebersole CR, DeHaven AC, Mellor DT. The preregistration revolution. Proceedings of the National Academy of Sciences. 2018;115(11):2600-2606.

[23] Munafò MR, Nosek BA, Bishop DVM, Button KS, Chambers CD, du Sert NP, et al. A manifesto for reproducible science. Nature Human Behaviour. 2017;1:0021.

[24] Frankle J, Dziugaite GK, Roy DM, Carbin M. Linear mode connectivity and the lottery ticket hypothesis. International Conference on Machine Learning. 2020.

[25] Garipov T, Izmailov P, Podoprikhin D, Vetrov D, Wilson AG. Loss surfaces, mode connectivity, and fast ensembling of DNNs. Advances in Neural Information Processing Systems. 2018;31.

[26] Liu Z, Michaud EJ, Tegmark M. Towards understanding grokking: An effective theory of representation learning. Advances in Neural Information Processing Systems. 2022;35.

[27] Gromov A. Grokking modular arithmetic. arXiv:2301.02679. 2023.

[28] Liu Z, Kitouni O, Nolte N, Michaud EJ, Tegmark M, Williams M. Omnigrok: Grokking beyond algorithmic data. International Conference on Learning Representations. 2024.

[29] Meng K, Bau D, Andonian A, Belinkov Y. Locating and editing factual associations in GPT. Advances in Neural Information Processing Systems. 2022;35.

[30] Meng K, Sharma AS, Andonian A, Belinkov Y, Bau D. Mass-editing memory in a transformer. International Conference on Learning Representations. 2023.

[31] Hagberg A, Schult D, Swart P. Exploring network structure, dynamics, and function using NetworkX. In: Proceedings of the 7th Python in Science Conference. 2008.

[32] Zachary WW. An information flow model for conflict and fission in small groups. Journal of Anthropological Research. 1977;33(4):452-473.

[33] Barak B, Edelman A, Goel S, Kakade S, Malach E, Zhang C. Hidden progress in deep learning: SGD learns parities near the computational limit. Advances in Neural Information Processing Systems. 2022;35.

[34] Biderman S, Schoelkopf H, Sutcliffe R, Blecher C, Towers O, Black S, et al. Pythia: A suite for analyzing large language models across training and scaling. International Conference on Machine Learning. 2024.

[35] Gu A, Dao T. Mamba: Linear-time sequence modeling with selective state spaces. arXiv:2312.00752. 2023.

[36] Roy O, Vetterli M. The effective rank: a measure of effective dimensionality. European Signal Processing Conference. 2007.

[37] Cohen J. Statistical Power Analysis for the Behavioral Sciences. 2nd ed. Hillsdale: Erlbaum; 1988.

[38] Sun Y, Dong L, Huang S, Ma S, Xia Y, Xue J, et al. Retentive network: a successor to transformer for large language models. arXiv:2307.08621. 2023.

[39] Groeneveld D, Beltagy I, Walsh P, Bhagia A, Kinney R, Tafjord O, et al. OLMo: accelerating the science of language models. Annual Meeting of the Association for Computational Linguistics. 2024.

[40] Rousseeuw PJ. Silhouettes: a graphical aid to the interpretation and validation of cluster analysis. Journal of Computational and Applied Mathematics. 1987;20:53-65.

[41] Kornblith S, Norouzi M, Lee H, Hinton G. Similarity of neural network representations revisited. International Conference on Machine Learning. 2019.

[42] Varma V, Shah R, Kenton Z, Kramár J, Kumar R, Hadfield-Menell D, et al. Explaining grokking through circuit efficiency. Advances in Neural Information Processing Systems. 2023;36.

[43] Naitzat G, Zhitnikov A, Lim LH. Topology of deep neural networks. Journal of Machine Learning Research. 2020;21(184):1-40.

[44] Hase P, Bansal M, Kim B, Neubig G. Does localization inform editing? Contrasting behaviors in language model model editing. International Conference on Learning Representations. 2024.

[45] Elhage N, Hume T, Olsson C, Schiefer N, Henighan T, Kravec S, et al. Toy models of superposition. Transformer Circuits Thread. 2022.

[46] Levina E, Bickel PJ. Maximum likelihood estimation of intrinsic dimension. Annals of Statistics. 2004;32(6).

[47] Facco E, d'Errico M, Rodriguez A, Laio A. Estimating the intrinsic dimension of datasets by a minimal neighborhood information. Scientific Reports. 2017;7:12140.

[48] Ansuini A, Laio A, Macke JH, Zoccolan D. Intrinsic dimension of data representations in deep neural networks. Advances in Neural Information Processing Systems. 2019;32.

[49] Villani C. Optimal Transport: Old and New. Springer; 2009.

[50] Knuth DE. The Stanford GraphBase: A Platform for Combinatorial Computing. Addison-Wesley; 1993.

[51] Kingma DP, Ba J. Adam: a method for stochastic optimization. International Conference on Learning Representations. 2015.

[52] Loshchilov I, Hutter F. Decoupled weight decay regularization. International Conference on Learning Representations. 2019.

[53] Peng B, Alcaide E, Anthony Q, Albalak A, Arcadinho S, Biderman S, et al. RWKV: reinventing RNNs for the transformer era. Findings of the Association for Computational Linguistics: EMNLP. 2023.

[54] Chung FRK. Spectral Graph Theory. Providence: American Mathematical Society; 1997.

[55] Pineau J, Vincent-Lamarre P, Sinha K, Larivière V, Beygelzimer A, d'Alché-Buc F, et al. Improving reproducibility in machine learning research. Journal of Machine Learning Research. 2021;22(164):1-20.

[56] Conmy A, Mavor-Parker A, Lynch A, Heimersheim S, Garriga-Alonso A. Towards automated circuit discovery for mechanistic interpretability. Advances in Neural Information Processing Systems. 2023;36.

[57] Syed A, Rager C, Conmy A. Attribution patching outperforms automated circuit discovery. arXiv:2310.10348. 2023.

[58] Cunningham H, Ewart A, Riggs L, Huben R, Sharkey L. Sparse autoencoders find highly interpretable features in language models. arXiv:2309.08600. 2023.

[59] Zhang F, Nanda N. Towards best practices of activation patching in language models: metrics and methods. International Conference on Learning Representations. 2024.

[60] Tibshirani R. Regression shrinkage and selection via the lasso. Journal of the Royal Statistical Society: Series B. 1996;58(1):267-288.

[61] Ewens WJ. Mathematical Population Genetics I: Theoretical Introduction. 2nd ed. New York: Springer; 2004.
