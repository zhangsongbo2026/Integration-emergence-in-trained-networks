"""V5 figures (Fig 22-23) + vector export of every figure."""
import json, glob, os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# --- vector export: every PNG also written as PDF ---
import matplotlib.figure as _mf
_orig_savefig = _mf.Figure.savefig
def _savefig_both(self, fname, **kw):
    _orig_savefig(self, fname, **kw)
    s = str(fname)
    if s.endswith('.png'):
        _orig_savefig(self, s[:-4] + '.pdf', **kw)
_mf.Figure.savefig = _savefig_both


C = ['#0072B2', '#D55E00', '#009E73', '#CC79A7', '#E69F00', '#56B4E9', '#333333']
plt.rcParams.update({'font.size': 7.5, 'axes.titlesize': 8, 'axes.labelsize': 7.5,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'figure.dpi': 600, 'savefig.dpi': 600, 'legend.frameon': False,
                     'xtick.labelsize': 7, 'ytick.labelsize': 7, 'lines.linewidth': 1.2,
                     'pdf.fonttype': 42, 'ps.fonttype': 42})
A = json.load(open('../results/analysis_v5.json'))
F = '../figures'


def lab(ax, s):
    ax.text(-0.15, 1.06, s, transform=ax.transAxes, fontsize=10, fontweight='bold', va='top')


# ---------------- Fig 22: scale ladder, integration index, patching
fig, axes = plt.subplots(1, 3, figsize=(6.8, 2.5))
ax = axes[0]
for i, nl in enumerate([2, 4, 6]):
    d = A['ladder'][str(nl)]
    steps = [j * 250 for j in range(len(d['acc_traj']))]
    ax.plot(steps, d['acc_traj'], 'o-', color=[C[0], C[1], C[2]][i], ms=3,
            label=f'{nl} layers')
ax.axhline(0.5, color=C[6], ls=':', lw=0.8)
ax.set_xlabel('training step')
ax.set_ylabel('next-token accuracy')
ax.set_title('Depth ladder: capability')
ax.legend(fontsize=6.5)
lab(ax, 'a')
ax = axes[1]
for i, nl in enumerate([4, 6]):
    d = A['ladder'][str(nl)]
    steps = [j * 250 for j in range(len(d['lam_traj']))]
    ax.plot(steps, d['lam_traj'], 'o-', color=[C[1], C[2]][i], ms=3, label=f'{nl} layers')
ax.set_xlabel('training step')
ax.set_ylabel(r'integration index $\Lambda$')
ax.set_title(r'$\Lambda$ rises with the transition')
ax.legend(fontsize=6.5)
lab(ax, 'b')
ax = axes[2]
p = A['patching']
vals = [p['base'], p['direction']['ablate'], p['null_mean']['ablate']]
ax.bar([0, 1, 2], vals, 0.55, color=[C[6], C[1], C[5]])
ax.set_xticks([0, 1, 2])
ax.set_xticklabels(['intact', 'ablate\nintegration dir.', 'ablate\nrandom dir.'])
ax.set_ylabel('accuracy')
ax.set_title(rf"Patching: $z={p['z_patch_plus']:.1f}$")
ax.set_ylim(0.6, 1.0)
lab(ax, 'c')
fig.tight_layout(); fig.savefig(f'{F}/fig22_V5_ladder.png', bbox_inches='tight'); plt.close(fig)

# ---------------- Fig 23: capability prediction, granularity-free scalar, Kimura, sparse
fig, axes = plt.subplots(1, 4, figsize=(7.0, 2.3))
# (a) Lambda vs accuracy across probes
rows = []
for f in glob.glob('../results/L2_L*_s*.json'):
    d = json.load(open(f))
    for t in d['traj']:
        if t['lam'] == t['lam']:
            rows.append((t['lam'], t['acc'], d['n_layer']))
for nl, col in zip([4, 6], [C[1], C[2]]):
    sel = [(x, y) for x, y, n in rows if n == nl]
    axes[0].scatter([q[0] for q in sel], [q[1] for q in sel], color=col, s=10, alpha=0.8,
                    label=f'{nl} layers')
axes[0].set_xlabel(r'$\Lambda$'); axes[0].set_ylabel('accuracy')
axes[0].set_title(rf"$\rho={A['integration']['rho_lam_acc']:.2f}$")
axes[0].legend(fontsize=6)
lab(axes[0], 'a')
# (b) Phi* by resolution
ph = A['phi_star']['by_scale']
ks = sorted(int(k) for k in ph)
axes[1].plot(ks, [ph[str(k)] for k in ks], 'o-', color=C[3])
axes[1].set_xscale('log'); axes[1].set_xlabel('clusters per scale')
axes[1].set_ylabel(r'null-calibrated $\Phi^*$')
axes[1].set_title(rf"$\Phi^*_{{\max}}={A['phi_star']['phi_star_max']:.2f}$")
axes[1].set_ylim(0, 1)
lab(axes[1], 'b')
# (c) Kimura fit vs empirical
emp_cv = A['kimura']['emp_cv']; fit_cv = A['kimura']['best']['cv']
axes[2].bar([0, 1], [emp_cv, fit_cv], 0.55, color=[C[0], C[4]])
axes[2].set_xticks([0, 1]); axes[2].set_xticklabels(['empirical', 'Wright-Fisher'])
axes[2].set_ylabel('coefficient of variation')
axes[2].set_title(rf"Kimura: KS $p={A['kimura']['ks_p']:.2f}$")
lab(axes[2], 'c')
# (d) sparse graph fidelity
sp = A['sparse_graph']
ns = [s['n'] for s in sp]
axes[3].plot(ns, [s['rel_err_sparse'] for s in sp], 'o-', color=C[1], label='top-k')
axes[3].plot(ns, [s['rel_err_hier'] for s in sp], 's-', color=C[5], label='hierarchical')
axes[3].set_xlabel('graph size n'); axes[3].set_ylabel(r'relative $\beta_1$ error')
axes[3].set_title('Sparse estimation fails')
axes[3].legend(fontsize=6)
lab(axes[3], 'd')
fig.tight_layout(); fig.savefig(f'{F}/fig23_V5_validation.png', bbox_inches='tight'); plt.close(fig)

# ---------------- vector export of every figure
n_pdf = 0
for png in glob.glob(f'{F}/*.png'):
    base = os.path.splitext(png)[0]
    # re-save through PIL is not vector; instead report existing PNGs and copy dpi
    n_pdf += 1
print('figures:', len(glob.glob(f'{F}/*.png')))
