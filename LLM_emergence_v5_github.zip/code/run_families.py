"""V3 experiment families (route-map D2.2-D2.5, D4.1-D4.3, D5.4 support).

Families:
  X   : extended main grid (seeds 8..31), probes every 4000  -> X_seed{n}.json
  W   : hidden-width scaling (arg2 = width)                  -> W{w}_seed{n}.json
  ARCH: minimal cross-architecture family (arg2 in
        retnet|rwkv|ssm|attn)                                -> ARCH_{a}_seed{n}.json
  MET : capability-metric definitions (exact acc, margins)   -> MET_seed{n}.json
  CIR : circuit tracking (per-unit readout norms, ablation)  -> CIR_seed{n}.json
  MSL : multi-skill lattice = L2 checkpoint-trajectory proxy -> MSL_seed{n}.json
Usage: python run_families.py <family> <seed> [arg2]
"""
import json, os, sys, time, gc
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from grok_core import make_data
from mlp_core import (MLPModel, cloud_prep, h1_diagram, two_nn_id,
                      spectral_gap, class_means, zstd)

torch.set_num_threads(1)
p = 29
OUT = '../results'
os.makedirs(OUT, exist_ok=True)


def cycle_align(Z, S):
    Z = Z - Z.mean(0, keepdims=True)
    n = len(Z)
    rng = np.random.default_rng(0)
    i = rng.integers(0, n, 15000); j = rng.integers(0, n, 15000)
    k = i != j; i, j = i[k], j[k]
    Zn = Z / (np.linalg.norm(Z, axis=1, keepdims=True) + 1e-12)
    A = (Zn[i] * Zn[j]).sum(1)
    d = np.abs(S[i] - S[j]); d = np.minimum(d, p - d)
    return float(np.corrcoef(A, np.cos(2 * np.pi * d / p))[0, 1])


def base_metrics(lv, H, S, heavy=True):
    Lc = cloud_prep(lv, max_points=300, seed=0)
    out = dict(sg=spectral_gap(Lc), id=two_nn_id(Lc), r_logit=cycle_align(lv.numpy(), S))
    if heavy:
        dgm = h1_diagram(Lc)
        out['psi'] = float((dgm[:, 1] - dgm[:, 0]).sum()) if len(dgm) else 0.0
    return out


# ---------------------------------------------------------------- X family
def fam_X(seed, steps=48000):
    m = MLPModel(p=p, seed=seed)
    Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
    S = ((Xva[:, 0] + Xva[:, 1]) % p).numpy().astype(float)
    opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=2.0)
    traj = []
    for step in range(steps + 1):
        if step % 4000 == 0 or step == steps:
            m.eval()
            with torch.no_grad():
                lv, H = m(Xva)
                v = (lv.argmax(-1) == Yva).float().mean().item()
                lt, _ = m(Xtr); tr = (lt.argmax(-1) == Ytr).float().mean().item()
                met = base_metrics(lv, H, S)
            m.train()
            met.update(step=step, val=v, train=tr)
            traj.append(met)
            json.dump(dict(seed=seed, traj=traj), open(f'{OUT}/X_seed{seed}.json', 'w'))
            torch.save(m.state_dict(), f'{OUT}/X_weights_seed{seed}.pt')
            print(f'X s{seed} st {step} val {v:.3f} sg {met["sg"]:.3f} psi {met["psi"]:.1f}', flush=True)
        if step == steps:
            break
        opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
    gc.collect()


# ---------------------------------------------------------------- W family
def fam_W(seed, w, steps=60000):
    m = MLPModel(p=p, d=128, dh=w, seed=seed)
    Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
    S = ((Xva[:, 0] + Xva[:, 1]) % p).numpy().astype(float)
    opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=2.0)
    traj = []
    for step in range(steps + 1):
        if step % 4000 == 0 or step == steps:
            m.eval()
            with torch.no_grad():
                lv, H = m(Xva)
                v = (lv.argmax(-1) == Yva).float().mean().item()
                lt, _ = m(Xtr); tr = (lt.argmax(-1) == Ytr).float().mean().item()
                Lc = cloud_prep(lv, max_points=300, seed=0)
                sg = spectral_gap(Lc); idv = two_nn_id(Lc)
            m.train()
            traj.append(dict(step=step, val=v, train=tr, sg=sg, id=idv))
            json.dump(dict(seed=seed, w=w, traj=traj), open(f'{OUT}/W{w}_seed{seed}.json', 'w'))
            print(f'W{w} s{seed} st {step} val {v:.3f} sg {sg:.3f} id {idv:.1f}', flush=True)
            if v >= 0.9:
                break
        if step == steps:
            break
        opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
    gc.collect()


# ---------------------------------------------------------------- ARCH family
class RetNetLite(nn.Module):
    """Minimal decayed linear-attention (RetNet-style): h = g*v(x1)+v(x2)."""
    def __init__(self, p=29, d=128, dh=100, seed=0):
        super().__init__()
        torch.manual_seed(seed)
        self.ea = nn.Embedding(p, d); self.eb = nn.Embedding(p, d)
        self.v = nn.Linear(d, dh); self.g = nn.Parameter(torch.zeros(dh))
        self.V = nn.Linear(dh, dh); self.C = nn.Linear(dh, p)

    def forward(self, t):
        g = torch.sigmoid(self.g)
        h = g * torch.tanh(self.v(self.ea(t[:, 0]))) + torch.tanh(self.v(self.eb(t[:, 1])))
        return self.C(F.relu(self.V(h))), h


class RWKVLite(nn.Module):
    """Minimal RWKV-style gated time-mix over two tokens."""
    def __init__(self, p=29, d=128, dh=100, seed=0):
        super().__init__()
        torch.manual_seed(seed)
        self.ea = nn.Embedding(p, d); self.eb = nn.Embedding(p, d)
        self.w = nn.Linear(d, dh); self.v = nn.Linear(d, dh); self.mix = nn.Linear(d, d)
        self.V = nn.Linear(dh, dh); self.C = nn.Linear(dh, p)

    def forward(self, t):
        c1 = self.ea(t[:, 0]); c2 = self.eb(t[:, 1]) + self.mix(self.ea(t[:, 0]))
        w = torch.sigmoid(self.w(c2))
        h = w * torch.tanh(self.v(c2)) + (1 - w) * torch.tanh(self.v(c1))
        return self.C(F.relu(self.V(h))), h


class SSMHead(nn.Module):
    """Minimal selective SSM (used in E11) + composition head."""
    def __init__(self, p=29, d=128, dh=100, seed=0):
        super().__init__()
        torch.manual_seed(seed)
        self.ea = nn.Embedding(p, d); self.eb = nn.Embedding(p, d)
        self.W = nn.Linear(d, dh); self.lam = nn.Parameter(torch.zeros(dh))
        self.V = nn.Linear(dh, dh); self.C = nn.Linear(dh, p)

    def forward(self, t):
        lam = torch.sigmoid(self.lam)
        h1 = torch.tanh(self.W(self.ea(t[:, 0])))
        h2 = lam * h1 + (1 - lam) * torch.tanh(self.W(self.eb(t[:, 1])))
        return self.C(F.relu(self.V(h2))), h2


class AttnLite(nn.Module):
    """One-layer, two-head attention over the pair plus MLP head."""
    def __init__(self, p=29, d=128, dh=100, seed=0):
        super().__init__()
        torch.manual_seed(seed)
        self.emb = nn.Embedding(p + 1, d)
        self.pos = nn.Parameter(torch.zeros(3, d))
        self.attn = nn.MultiheadAttention(d, 2, batch_first=True)
        self.V = nn.Linear(d, dh); self.C = nn.Linear(dh, p)

    def forward(self, t):
        eq = torch.full((t.shape[0], 1), p, dtype=torch.long)
        x = self.emb(torch.cat([t, eq], 1)) + self.pos
        a, _ = self.attn(x, x, x, need_weights=False)
        h = F.relu(self.V(x + a))[:, -1, :]
        return self.C(h), h


ARCHS = dict(retnet=RetNetLite, rwkv=RWKVLite, ssm=SSMHead, attn=AttnLite)


def fam_ARCH(seed, name, steps=60000, lr=1e-3):
    m = ARCHS[name](p=p, seed=seed)
    Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
    S = ((Xva[:, 0] + Xva[:, 1]) % p).numpy().astype(float)
    opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=2.0)
    traj, tau = [], None
    for step in range(steps + 1):
        if step % 2000 == 0 or step == steps:
            m.eval()
            with torch.no_grad():
                lv, H = m(Xva)
                v = (lv.argmax(-1) == Yva).float().mean().item()
                lt, _ = m(Xtr); tr = (lt.argmax(-1) == Ytr).float().mean().item()
                met = base_metrics(lv, H, S)
            m.train()
            met.update(step=step, val=v, train=tr)
            traj.append(met)
            if tau is None and tr >= 0.995 and v >= 0.5:
                tau = step
            json.dump(dict(seed=seed, arch=name, tau=tau, traj=traj),
                      open(f'{OUT}/ARCH_{name}_seed{seed}.json', 'w'))
            print(f'{name} s{seed} st {step} val {v:.3f} sg {met["sg"]:.3f} r {met["r_logit"]:.3f}', flush=True)
            if v >= 0.9 or (tau is not None and step - tau > 10000):
                break
        if step == steps:
            break
        opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
    gc.collect()


# ---------------------------------------------------------------- MET family
def fam_MET(seed, steps=60000):
    """Capability metric definitions: exact accuracy, logit margin (continuous),
    margin-thresholded accuracy at 0 and 1, plus consolidation statistics."""
    m = MLPModel(p=p, seed=seed)
    Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
    S = ((Xva[:, 0] + Xva[:, 1]) % p).numpy().astype(float)
    opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=2.0)
    traj = []
    for step in range(steps + 1):
        if step % 500 == 0 or step == steps:
            m.eval()
            with torch.no_grad():
                lv, H = m(Xva)
                logit_true = lv.gather(1, Yva[:, None]).squeeze(1)
                others = lv.clone(); others.scatter_(1, Yva[:, None], -1e9)
                margin = logit_true - others.max(1).values
                acc_exact = (lv.argmax(-1) == Yva).float().mean().item()
                acc_m0 = (margin > 0).float().mean().item()
                acc_m1 = (margin > 1).float().mean().item()
                cont = torch.sigmoid(margin).mean().item()      # continuous capability
                Lc = cloud_prep(lv, max_points=300, seed=0)
                sg = spectral_gap(Lc)
            m.train()
            traj.append(dict(step=step, acc_exact=acc_exact, acc_m0=acc_m0,
                             acc_m1=acc_m1, cont=cont, sg=sg,
                             mean_margin=float(margin.mean().item())))
            json.dump(dict(seed=seed, traj=traj), open(f'{OUT}/MET_seed{seed}.json', 'w'))
            print(f'MET s{seed} st {step} acc {acc_exact:.3f} cont {cont:.3f} sg {sg:.3f}', flush=True)
            if acc_exact >= 0.95:
                break
        if step == steps:
            break
        opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
    gc.collect()


# ---------------------------------------------------------------- CIR family
def fam_CIR(seed, steps=60000):
    """Circuit tracking: per-unit readout weight norms across training and
    final ablation sensitivity of hidden units."""
    m = MLPModel(p=p, seed=seed)
    Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
    opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=2.0)
    traj = []
    final_crit = None
    for step in range(steps + 1):
        if step % 2000 == 0 or step == steps:
            with torch.no_grad():
                lv, _ = m(Xva)
                v = (lv.argmax(-1) == Yva).float().mean().item()
                wn = m.fc2.weight.detach().norm(dim=0).numpy()   # per-unit readout norm
                la, _ = m(Xtr); tr = (la.argmax(-1) == Ytr).float().mean().item()
            traj.append(dict(step=step, val=v, train=tr,
                             unit_norm=wn.tolist(),
                             norm_share=float((np.sort(wn)[-20:] ** 2).sum() /
                                              (wn ** 2).sum())))
            json.dump(dict(seed=seed, traj=traj), open(f'{OUT}/CIR_seed{seed}.json', 'w'))
            print(f'CIR s{seed} st {step} val {v:.3f} top20 share {traj[-1]["norm_share"]:.3f}', flush=True)
            if v >= 0.9:
                break
        if step == steps:
            break
        opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
    # ablation sensitivity of hidden units at the final checkpoint
    with torch.no_grad():
        base = (m(Xva)[0].argmax(-1) == Yva).float().mean().item()
        sens = []
        for u in range(m.dh):
            orig = m.fc1.weight.data[:, u].clone()
            m.fc1.weight.data[:, u] = 0.0
            acc = (m(Xva)[0].argmax(-1) == Yva).float().mean().item()
            m.fc1.weight.data[:, u] = orig
            sens.append(base - acc)
    crit = np.argsort(sens)[::-1][:20].tolist()
    json.dump(dict(seed=seed, traj=traj, base_acc=base,
                   critical_units=crit,
                   crit_sensitivity=float(np.sum(np.sort(sens)[::-1][:20]))),
              open(f'{OUT}/CIR_seed{seed}.json', 'w'))
    gc.collect()


# ---------------------------------------------------------------- MSL family
def fam_MSL(seed, steps=60000):
    """Multi-skill lattice (L2 proxy): four skills trained jointly with a task
    token; per-skill generalisation onsets."""
    class MSL(nn.Module):
        def __init__(self, p, d=128, dh=100, seed=0):
            super().__init__()
            torch.manual_seed(seed)
            self.et = nn.Embedding(4, 16); self.ea = nn.Embedding(p, d)
            self.eb = nn.Embedding(p, d)
            self.fc1 = nn.Linear(2 * d + 16, dh); self.fc2 = nn.Linear(dh, p + 1)

        def forward(self, t):
            x = torch.cat([self.et(t[:, 0]), self.ea(t[:, 1]), self.eb(t[:, 2])], 1)
            h = F.relu(self.fc1(x))
            return self.fc2(h), h

    rng = np.random.default_rng(seed)
    a, b = np.meshgrid(np.arange(p), np.arange(p), indexing='ij')
    a, b = a.ravel(), b.ravel()
    A = np.broadcast_to(a, (4, len(a))).copy()
    B = np.broadcast_to(b, (4, len(b))).copy()
    T = np.repeat(np.arange(4), len(a)).reshape(4, -1).copy()
    Y = np.stack([(a + b) % p, (a - b) % p, a % p, (p - b) % p])  # add, sub, copy, negate
    Xall = np.stack([T.ravel(), A.ravel(), B.ravel()], 1)
    Yall = Y.ravel()
    idx = rng.permutation(len(Xall)); n_tr = int(0.5 * len(idx))
    tr, va = idx[:n_tr], idx[n_tr:]
    Xtr = torch.tensor(Xall[tr]); Ytr = torch.tensor(Yall[tr])
    Xva = torch.tensor(Xall[va]); Yva = torch.tensor(Yall[va])
    m = MSL(p, seed=seed)
    opt = torch.optim.AdamW(m.parameters(), lr=2e-3, weight_decay=2.0)
    traj = []
    for step in range(steps + 1):
        if step % 2000 == 0 or step == steps:
            m.eval()
            with torch.no_grad():
                lv, H = m(Xva)
                per = {}
                for t_id in range(4):
                    mask = Xva[:, 0] == t_id
                    if mask.any():
                        per[t_id] = float((lv[mask].argmax(-1) == Yva[mask]).float().mean().item())
                overall = (lv.argmax(-1) == Yva).float().mean().item()
                lt, _ = m(Xtr); tr_a = (lt.argmax(-1) == Ytr).float().mean().item()
                Lc = cloud_prep(lv, max_points=300, seed=0)
                sg = spectral_gap(Lc); idv = two_nn_id(Lc)
                Lh = cloud_prep(H, max_points=300, seed=0)
                psih = 0.0
                dgm = h1_diagram(Lh)
                psih = float((dgm[:, 1] - dgm[:, 0]).sum()) if len(dgm) else 0.0
            m.train()
            traj.append(dict(step=step, overall=overall, train=tr_a, per=per, sg=sg,
                             id=idv, psi_hidden=psih))
            json.dump(dict(seed=seed, traj=traj), open(f'{OUT}/MSL_seed{seed}.json', 'w'))
            print(f'MSL s{seed} st {step} overall {overall:.3f} per {per} sg {sg:.3f}', flush=True)
        if step == steps:
            break
        opt.zero_grad(); lg, _ = m(Xtr)
        F.cross_entropy(lg, Ytr).backward(); opt.step()
    gc.collect()


if __name__ == '__main__':
    fam, seed = sys.argv[1], int(sys.argv[2])
    arg2 = sys.argv[3] if len(sys.argv) > 3 else None
    if fam == 'X':
        fam_X(seed)
    elif fam == 'W':
        fam_W(seed, int(arg2))
    elif fam == 'ARCH':
        fam_ARCH(seed, arg2, lr=float(sys.argv[4]) if len(sys.argv) > 4 else 1e-3)
    elif fam == 'MET':
        fam_MET(seed)
    elif fam == 'CIR':
        fam_CIR(seed)
    elif fam == 'MSL':
        fam_MSL(seed)
