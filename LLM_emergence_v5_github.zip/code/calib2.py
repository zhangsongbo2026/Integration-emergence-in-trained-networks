import json, time, numpy as np, torch, torch.nn.functional as F
from grok_core import make_data
from mlp_core import MLPModel, probe

p, lr, wd, steps, seed = 29, 1e-3, 2.0, 60000, 0
m = MLPModel(p=p, seed=seed)
Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
Xtr_d, Ytr_d, Xva_d = Xtr, Ytr, Xva
Xva_np = Xva.numpy()
opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=wd)
traj = []
t0 = time.time()
dgm_keep = {}
for step in range(steps + 1):
    if step % 1000 == 0 or step == steps:
        with torch.no_grad():
            lv, _ = m(Xva_d); v = (lv.argmax(-1) == Yva).float().mean().item()
            lt, _ = m(Xtr_d); tr = (lt.argmax(-1) == Ytr_d).float().mean().item()
        pv, dgm = probe(m, Xva_d, Xva_np, Yva, p, seed=seed)
        pv.update(step=step, train_acc=tr, val_acc=v)
        traj.append(pv)
        if step in (10000, 20000, 23000, 26000, 40000, 60000):
            dgm_keep[step] = [[float(a), float(b)] for a, b in dgm[:60]]
        print(f"step {step} val {v:.2f} psi_top5 {pv['psi_top5']:.2f} r_prompt {pv['r_prompt']:.2f} r_class {pv['r_class']:.2f} unif {pv['unif']:.2f} id {pv['id']:.1f} sg {pv['sg']:.3f}", flush=True)
    if step == steps:
        break
    opt.zero_grad(); lg, _ = m(Xtr_d); F.cross_entropy(lg, Ytr_d).backward(); opt.step()
print('wall', time.time() - t0)
json.dump(dict(traj=traj, dgms=dgm_keep), open('calib_mlp_seed0.json', 'w'))
