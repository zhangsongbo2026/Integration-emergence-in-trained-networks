"""Core grokking simulation: mod-p addition, attention-only transformer, CPU.

Implements the measurement suite for the V2 paper:
  - train/val accuracy trajectories
  - Psi1: persistent-homology H1 total persistence of the activation cloud
  - r:   Kuramoto order parameter (phase = unit angle in top-2 PCA of unit space)
  - ID:  intrinsic dimension (PCA-95% + TwoNN)
  - SG:  spectral gap of cosine-similarity graph
  - AS:  activation sparsity (fraction |a|<1e-3)
  - attention adjacency graphs for the beta1 identity audit
"""
import math, json, time, os
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.set_num_threads(4)


class AttnOnlyModel(nn.Module):
    """One-layer attention-only transformer for (a+b) mod p (Nanda-style)."""

    def __init__(self, p=29, d_model=64, n_heads=2, seed=0):
        super().__init__()
        torch.manual_seed(seed)
        self.p = p
        self.d_model = d_model
        self.embed = nn.Embedding(p + 1, d_model)   # tokens 0..p-1, p = '='
        self.pos = nn.Parameter(torch.zeros(3, d_model))
        nn.init.normal_(self.pos, std=0.02)
        self.attn = nn.MultiheadAttention(d_model, n_heads, batch_first=True)
        self.out = nn.Linear(d_model, p, bias=False)

    def forward(self, tokens):
        # tokens: (B, 2) -> append '='
        eq = torch.full((tokens.shape[0], 1), self.p, dtype=torch.long,
                        device=tokens.device)
        x = self.embed(torch.cat([tokens, eq], dim=1)) + self.pos
        a_out, _ = self.attn(x, x, x, need_weights=False)
        h = x + a_out                      # residual stream, (B, 3, D)
        return self.out(h[:, -1, :]), h    # logits, hidden states

    def attention_adjacency(self, tokens, thresh_quantile=0.5):
        """Thresholded attention adjacency over tokens (for beta1 audit)."""
        eq = torch.full((tokens.shape[0], 1), self.p, dtype=torch.long,
                        device=tokens.device)
        x = self.embed(torch.cat([tokens, eq], dim=1)) + self.pos
        a_out, w = self.attn(x, x, x, need_weights=True, average_attn_weights=True)
        # w: (B, T, T) averaged over heads; aggregate over batch
        A = w.mean(dim=0).detach().cpu().numpy()
        thr = np.quantile(A, thresh_quantile)
        return (A > thr).astype(np.int64)


def make_data(p=29, frac_train=0.5, seed=0):
    rng = np.random.default_rng(seed)
    a, b = np.meshgrid(np.arange(p), np.arange(p), indexing="ij")
    X = np.stack([a.ravel(), b.ravel()], axis=1)
    Y = (a + b).ravel() % p
    idx = rng.permutation(len(X))
    n_tr = int(round(frac_train * len(X)))
    tr, va = idx[:n_tr], idx[n_tr:]
    return (torch.tensor(X[tr]), torch.tensor(Y[tr]),
            torch.tensor(X[va]), torch.tensor(Y[va]))


# ---------------------------------------------------------------- PH metrics
def psi1_of_cloud(H, max_points=300, seed=0, tau_frac=0.35):
    """Psi1: weighted total H1 persistence of the last-layer activation cloud."""
    from ripser import ripser
    rng = np.random.default_rng(seed)
    X = H.detach().cpu().numpy()
    if X.shape[0] > max_points:
        sel = rng.choice(X.shape[0], max_points, replace=False)
        X = X[sel]
    X = X - X.mean(axis=0, keepdims=True)
    nrm = np.linalg.norm(X, axis=1, keepdims=True)
    nrm[nrm == 0] = 1.0
    X = X / nrm                       # project to sphere; cosine geometry
    D = 1.0 - X @ X.T
    D = np.clip((D + D.T) / 2, 0, 2)
    dgms = ripser(D, maxdim=1, distance_matrix=True)["dgms"]
    h1 = dgms[1]
    if len(h1) == 0:
        return 0.0, 0.0, 0
    b, d = h1[:, 0], h1[:, 1]
    pers = d - b
    tau = tau_frac * np.median(pers) if len(pers) else 0.0
    w = np.maximum(0.0, (pers - tau)) / (tau if tau > 0 else 1.0)
    return float(w.sum()), float(pers.max()), int(len(pers))


def kuramoto_r(H, units_dim):
    """Order parameter r: unit phases from top-2 PCA of the unit-activation space."""
    U = H.detach().cpu().numpy().T          # (D, n_prompts) one row per unit
    U = U - U.mean(axis=1, keepdims=True)
    U = U / (np.linalg.norm(U, axis=1, keepdims=True) + 1e-12)
    # top-2 PCA of unit vectors via SVD
    Uc = U - U.mean(axis=0, keepdims=True)
    try:
        Vt = np.linalg.svd(Uc, full_matrices=False)[2]
        v1, v2 = Vt[0], Vt[1]
    except np.linalg.LinAlgError:
        return 0.0
    proj1, proj2 = Uc @ v1, Uc @ v2
    theta = np.arctan2(proj2, proj1)
    r = np.abs(np.exp(1j * theta).mean())
    return float(r)


def intrinsic_dim(X, k=5):
    """Levina-Bickel MLE intrinsic dimension."""
    from sklearn.neighbors import NearestNeighbors
    X = X.detach().cpu().numpy()
    n = min(len(X), 400)
    rng = np.random.default_rng(0)
    Xs = X[rng.choice(len(X), n, replace=False)] if len(X) > n else X
    nn = NearestNeighbors(n_neighbors=k + 1).fit(Xs)
    d, _ = nn.kneighbors(Xs)
    d = d[:, 1:]                              # skip self
    d = np.maximum(d, 1e-12)
    m = k
    x = np.log(d[:, -1][:, None] / d[:, :-1]).sum(axis=1)
    id_mle = (m - 1) / x
    return float(np.mean(id_mle))


def spectral_gap(H, max_points=300, seed=0):
    """Normalized spectral gap of the cosine-similarity kNN graph."""
    rng = np.random.default_rng(seed)
    X = H.detach().cpu().numpy()
    if X.shape[0] > max_points:
        sel = rng.choice(X.shape[0], max_points, replace=False)
        X = X[sel]
    X = X - X.mean(axis=0, keepdims=True)
    nrm = np.linalg.norm(X, axis=1, keepdims=True); nrm[nrm == 0] = 1
    X = X / nrm
    S = np.clip(X @ X.T, 0, 1)
    np.fill_diagonal(S, 0)
    # kNN symmetrize (k=10)
    k = 10
    W = np.zeros_like(S)
    idxp = np.argpartition(-S, k, axis=1)[:, :k]
    for i, js in enumerate(idxp):
        W[i, js] = S[i, js]
        W[js, i] = np.maximum(W[js, i], S[i, js])
    deg = W.sum(axis=1) + 1e-12
    Dm = np.diag(1.0 / np.sqrt(deg))
    L = np.eye(len(W)) - Dm @ W @ Dm
    ev = np.sort(np.linalg.eigvalsh(L))
    return float(ev[1] - ev[0]) if len(ev) > 1 else 0.0


def sparsity(H):
    return float((np.abs(H.detach().cpu().numpy()) < 1e-3).mean())


def wasserstein_barcodes(dgmA, dgmB):
    """1-Wasserstein distance between two H1 diagrams (persim)."""
    from persim import wasserstein
    return float(wasserstein(dgmA, dgmB, matching=False))


# ---------------------------------------------------------------- training
def train_run(p=29, d_model=64, n_heads=2, frac_train=0.5, lr=1e-3, wd=1.0,
              steps=20000, seed=0, probe_every=250, max_probes=60,
              device="cpu", collect_full=False):
    """Train one run; probe metrics at scheduled checkpoints.

    probe_every: probe every N steps (accelerating schedule beyond first
    max_probes probes: geometric spacing to cover 20k steps cheaply).
    Returns dict with trajectories.
    """
    model = AttnOnlyModel(p, d_model, n_heads, seed).to(device)
    Xtr, Ytr, Xva, Yva = make_data(p, frac_train, seed)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=wd)
    # probe schedule: linear up to 2000 steps then geometric
    sched = list(range(0, min(steps, 2000) + 1, probe_every))
    t = 2000
    while t < steps:
        t = max(t + 1, int(t * 1.25))
        sched.append(t)
    sched = sorted(set([s for s in sched if s <= steps]))
    if collect_full:
        sched = list(range(0, steps + 1, probe_every))

    Xtr_d, Ytr_d = Xtr.to(device), Ytr.to(device)
    Xva_d, Yva_d = Xva.to(device), Yva.to(device)
    probe_prompts = Xtr_d          # activation cloud = train prompts

    traj = dict(step=[], train_acc=[], val_acc=[], psi1=[], r=[], id=[],
                sg=[], sp=[], nloops=[], psi_max=[])
    attn_graphs = {}
    h1_diagrams = {}
    barcodes_steps = []
    t0 = time.time()
    probe_set = set(sched)
    step = 0
    while step <= steps:
        if step in probe_set:
            model.eval()
            with torch.no_grad():
                logits_tr, H_tr = model(probe_prompts)
                acc_tr = (logits_tr.argmax(-1) == Ytr_d).float().mean().item()
                logits_va, H_va = model(Xva_d)
                acc_va = (logits_va.argmax(-1) == Yva_d).float().mean().item()
                Hcloud = H_va[:, -1, :]          # last-token hidden states
                psi1, psi_max, nloops = psi1_of_cloud(Hcloud, seed=seed)
                r = kuramoto_r(H_tr[:, -1, :], d_model)
                idm = intrinsic_dim(Hcloud)
                sg = spectral_gap(Hcloud, seed=seed)
                sp = sparsity(Hcloud)
            for k, v in zip(traj.keys()[1:] if False else
                            ["step", "train_acc", "val_acc", "psi1", "r",
                             "id", "sg", "sp", "nloops", "psi_max"],
                            [step, acc_tr, acc_va, psi1, r, idm, sg, sp,
                             nloops, psi_max]):
                traj[k].append(v)
            # keep a few H1 diagrams for barcode stability analysis
            if step in (0, 500, 1000, 2000) or (step % 2500 == 0) or step == steps:
                from ripser import ripser
                Xc = Hcloud.detach().cpu().numpy()
                Xc = Xc - Xc.mean(0, keepdims=True)
                nrm = np.linalg.norm(Xc, axis=1, keepdims=True); nrm[nrm == 0] = 1
                Xc = Xc / nrm
                D = 1.0 - Xc @ Xc.T
                dgms = ripser(np.clip((D + D.T) / 2, 0, 2), maxdim=1,
                              distance_matrix=True)["dgms"]
                h1_diagrams[step] = dgms[1].tolist()
            # attention adjacency for beta1 audit
            if step in (500, 2000, 5000, 10000, 20000) and step <= steps:
                attn_graphs[step] = model.attention_adjacency(
                    probe_prompts[:128]).tolist()
            model.train()
        if step == steps:
            break
        opt.zero_grad()
        logits, _ = model(Xtr_d)
        loss = F.cross_entropy(logits, Ytr_d)
        loss.backward()
        opt.step()
        step += 1
    traj["wall_time_s"] = time.time() - t0
    traj["config"] = dict(p=p, d_model=d_model, n_heads=n_heads,
                          frac_train=frac_train, lr=lr, wd=wd, steps=steps,
                          seed=seed)
    traj["h1_diagrams"] = h1_diagrams
    traj["attn_graphs"] = attn_graphs
    return traj


def jump_step(vals, steps, lo_thr, hi_thr):
    """First step where value crosses from < lo_thr regime to >= hi_thr."""
    va = np.array(vals)
    above = va >= hi_thr
    if not above.any():
        return None
    i = int(np.argmax(above))
    if i == 0:
        return int(steps[0])
    return int(steps[i])


if __name__ == "__main__":
    import sys
    t0 = time.time()
    tr = train_run(steps=6000, seed=0, probe_every=250)
    print("wall", time.time() - t0, "s for 6000 steps")
    import numpy as np
    va = np.array(tr["val_acc"]); st = np.array(tr["step"])
    print("final train/val:", tr["train_acc"][-1], tr["val_acc"][-1])
    print("val acc trace (every probe):", np.round(va[::2], 2))
    print("psi1 trace:", np.round(np.array(tr["psi1"])[::2], 2))
    print("r trace:", np.round(np.array(tr["r"])[::2], 3))
