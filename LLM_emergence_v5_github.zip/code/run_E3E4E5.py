"""E3 (reversibility/hysteresis), E4 (edit rebound-collapse threshold),
E5 (budget truncation -> transfer plasticity).
Usage: python run_E3E4E5.py <exp> <seed>
"""
import json, os, sys, time, gc
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from grok_core import make_data
from mlp_core import MLPModel

torch.set_num_threads(1)
p = 29
OUT = '../results'

def cyc(Z, S):
    Z = Z - Z.mean(0, keepdims=True)
    rng = np.random.default_rng(0)
    n = len(Z)
    i = rng.integers(0, n, 15000); j = rng.integers(0, n, 15000)
    k = i != j; i, j = i[k], j[k]
    Zn = Z / (np.linalg.norm(Z, axis=1, keepdims=True) + 1e-12)
    A = (Zn[i] * Zn[j]).sum(1)
    d = np.abs(S[i] - S[j]); d = np.minimum(d, p - d)
    B = np.cos(2 * np.pi * d / p)
    return float(np.corrcoef(A, B)[0, 1])

def psi_of(m, X):
    from mlp_core import cloud_prep, h1_diagram
    m.eval()
    with torch.no_grad():
        L, _ = m(X)
    Lc = cloud_prep(L, max_points=300, seed=0)
    dgm = h1_diagram(Lc)
    m.train()
    return float((dgm[:, 1] - dgm[:, 0]).sum()) if len(dgm) else 0.0

def val_of(m, X, Y):
    m.eval()
    with torch.no_grad():
        L, _ = m(X)
    m.train()
    return float((L.argmax(-1) == Y).float().mean().item())


def E3(seed):
    """Perturb-recover + task inversion from the E1 fully-trained model."""
    m = MLPModel(p=p, seed=seed)
    m.load_state_dict(torch.load(f'{OUT}/E1_weights_seed{seed}.pt'))
    Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
    S = ((Xva[:, 0] + Xva[:, 1]) % p).numpy().astype(float)
    res = dict(seed=seed, perturb=[], inversion={})
    with torch.no_grad():
        L0, H0 = m(Xva)
    r0 = cyc(L0.numpy(), S); v0 = val_of(m, Xva, Yva); psi0 = psi_of(m, Xva)
    rng = np.random.default_rng(seed)
    W0 = m.fc2.weight.detach().clone()
    for eps in [0.02, 0.05, 0.1, 0.2, 0.4]:
        torch.manual_seed(100 + seed)
        E = torch.randn_like(W0)
        E = E / E.norm() * (eps * W0.norm())
        with torch.no_grad():
            m.fc2.weight.copy_(W0 + E)
        v_pert = val_of(m, Xva, Yva)
        # recovery: 1500 steps small-lr on the ORIGINAL task
        opt = torch.optim.AdamW(m.parameters(), lr=1e-4, weight_decay=2.0)
        for _ in range(1500):
            opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
        v_rec = val_of(m, Xva, Yva)
        with torch.no_grad():
            L1, _ = m(Xva)
        r_rec = cyc(L1.numpy(), S)
        res['perturb'].append(dict(eps=eps, val_pert=v_pert, val_rec=v_rec,
                                   r_rec=r_rec, drift=float((m.fc2.weight - W0).norm() / W0.norm())))
        with torch.no_grad():
            m.fc2.weight.copy_(W0)
    # task inversion: (a-b) % p from the grokked (a+b) model
    Yinv = (Xva[:, 0] - Xva[:, 1]) % p
    Ytr_inv = (Xtr[:, 0] - Xtr[:, 1]) % p
    S_inv = ((Xva[:, 0] - Xva[:, 1]) % p).numpy().astype(float)
    opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=2.0)
    traj = []
    for step in range(8001):
        if step % 500 == 0:
            v_new = float(((m(Xva)[0].argmax(-1) == Yinv).float().mean().item()))
            v_old = val_of(m, Xva, Yva)
            with torch.no_grad():
                L2, _ = m(Xva)
            traj.append(dict(step=step, val_inv=v_new, val_old=v_old,
                             r_inv=cyc(L2.numpy(), S_inv), r_old=cyc(L2.numpy(), S)))
        if step == 8000:
            break
        opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr_inv).backward(); opt.step()
    res['inversion'] = traj
    json.dump(res, open(f'{OUT}/E3_seed{seed}.json', 'w'))
    gc.collect()


def E4(seed):
    """Rank-1 value edits with rebound-collapse threshold."""
    m = MLPModel(p=p, seed=seed)
    m.load_state_dict(torch.load(f'{OUT}/E1_weights_seed{seed}.pt'))
    Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
    v0 = val_of(m, Xva, Yva)
    rng = np.random.default_rng(42 + seed)
    # pick 12 correctly-classified val prompts, spread over classes
    with torch.no_grad():
        L, H = m(Xva)
    correct = (L.argmax(-1) == Yva).nonzero().flatten()
    sel = rng.choice(correct.numpy(), 12, replace=False)
    res = dict(seed=seed, v0=v0, edits=[])
    for eps in [0.25, 0.5, 1.0, 2.0, 4.0, 8.0]:
        persist_n, rebound_n, dmg = 0, 0, 0.0
        for k, idx in enumerate(sel):
            idx = int(idx)
            a0, b0 = Xva[idx]
            true_c = int(Yva[idx])
            tgt = int((true_c + 1 + rng.integers(0, p - 2)) % p)
            with torch.no_grad():
                _, h = m(Xva[idx:idx + 1])
            u = h[0] / (h[0].norm() + 1e-8)
            # rank-1 edit: boost target logit along the prompt's hidden direction
            with torch.no_grad():
                m.fc2.weight[tgt] += eps * u
                m.fc2.bias[tgt] += eps
            # immediate persistence: does the edited prompt now output tgt?
            with torch.no_grad():
                Lp, _ = m(Xva[idx:idx + 1])
            if int(Lp.argmax(-1)) == tgt:
                persist_n += 1
            dmg += val_of(m, Xva, Yva)
            # rebound: 400 light fine-tune steps on train (original task)
            opt = torch.optim.AdamW(m.parameters(), lr=1e-4, weight_decay=2.0)
            for _ in range(400):
                opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
            with torch.no_grad():
                Lr, _ = m(Xva[idx:idx + 1])
            if int(Lr.argmax(-1)) == true_c:
                rebound_n += 1
            # restore weights: recompute fresh model each prompt (cheap: reload)
            m.load_state_dict(torch.load(f'{OUT}/E1_weights_seed{seed}.pt'))
        res['edits'].append(dict(eps=eps, persist=persist_n / len(sel),
                                 rebound=rebound_n / len(sel),
                                 mean_val=dmg / len(sel)))
        print(f'E4 seed {seed} eps {eps}: persist {persist_n}/12 rebound {rebound_n}/12', flush=True)
    json.dump(res, open(f'{OUT}/E4_seed{seed}.json', 'w'))
    gc.collect()


def E5(seed, only=None):
    """Budget truncation -> transfer plasticity on the inverted task."""
    res_p = f'{OUT}/E5_seed{seed}.json'
    res = json.load(open(res_p)) if os.path.exists(res_p) else dict(
        seed=seed, tau_task1=None, budgets={})
    tr = json.load(open(f'{OUT}/E1_seed{seed}.json'))['traj']
    tau = None
    for d in tr:
        if d['train_acc'] >= 0.995 and d['val_acc'] >= 0.5:
            tau = d['step']; break
    if tau is None:
        tau = 60000
    res['tau_task1'] = tau
    Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
    Ytr_inv = (Xtr[:, 0] - Xtr[:, 1]) % p
    Yva_inv = (Xva[:, 0] - Xva[:, 1]) % p
    for name, B in [('truncated', max(2000, int(0.3 * tau))), ('full', 3 * tau)]:
        if only and name != only:
            continue
        if name in res['budgets']:
            continue
        m = MLPModel(p=p, seed=seed)
        opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=2.0)
        for step in range(B):
            opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
        v1 = val_of(m, Xva, Yva)
        opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=2.0)
        t_step = None
        for step in range(30001):
            if step % 200 == 0:
                v = val_of(m, Xva, Yva_inv)
                if t_step is None and v >= 0.5:
                    t_step = step
                    break
            opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr_inv).backward(); opt.step()
        res['budgets'][name] = dict(budget=B, val_after_budget=v1,
                                    transfer_steps=t_step)
        print(f'E5 seed {seed} {name}: B={B} val1={v1:.2f} transfer={t_step}', flush=True)
        json.dump(res, open(res_p, 'w'))
        gc.collect()


if __name__ == '__main__':
    exp, seed = sys.argv[1], int(sys.argv[2])
    only = sys.argv[3] if len(sys.argv) > 3 else None
    if exp == 'E5':
        E5(seed, only)
    else:
        dict(E3=E3, E4=E4)[exp](seed)
