"""V4 figures: Fig 20 (barrier landscape, signed graph, U_rep) and
Fig 21 (granularity, energy ledger, dose response)."""
import json, glob
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# --- vector export: every PNG also written as PDF ---
import matplotlib.figure as _mf
_orig_savefig = _mf.Figure.savefig
def _savefig_both(self, fname, **kw):
    _orig_savefig(self, fname, **kw)
    s = str(fname)
    if s.endswith('.png'):
        _orig_savefig(self, s[:-4] + '.pdf', **kw)
_mf.Figure.savefig = _savefig_both


C = ['#0072B2', '#D55E00', '#009E73', '#CC79A7', '#E69F00', '#56B4E9', '#333333']
plt.rcParams.update({'font.size': 7.5, 'axes.titlesize': 8, 'axes.labelsize': 7.5,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'figure.dpi': 300, 'savefig.dpi': 300, 'legend.frameon': False,
                     'xtick.labelsize': 7, 'ytick.labelsize': 7, 'lines.linewidth': 1.2})
R = json.load(open('../results/analysis_v4.json'))
F = '../figures'


def lab(ax, s):
    ax.text(-0.14, 1.06, s, transform=ax.transAxes, fontsize=10, fontweight='bold', va='top')


# ---- Fig 20
fig, axes = plt.subplots(1, 3, figsize=(6.8, 2.5))
ax = axes[0]
for i, s in enumerate([0, 1, 2]):
    d = json.load(open(f'../results/V4_landscape_seed{s}.json'))
    path = d['path']
    al = [q['alpha'] for q in path]; acc = [q['acc'] for q in path]
    psi = [q['psi'] for q in path]; sg = [q['sg'] for q in path]
    ax.plot(al, acc, color=[C[0], C[1], C[2]][i], alpha=0.85, label=f'seed {s}')
ax.axhline(0.5, color=C[6], ls=':', lw=0.8)
ax.set_xlabel(r'interpolation coordinate $\alpha$ (memorisation $\to$ consolidation)')
ax.set_ylabel('validation accuracy')
ax.set_title('Barrier between the two solutions')
ax.legend(fontsize=6.5)
lab(ax, 'a')
ax = axes[1]
x = np.arange(2)
b1a = [R['landscape_summary']['mean_b1_abs_fin']] * 2
b1p = [R['landscape_summary']['mean_b1_pos_fin']] * 2
ax.bar([0], [R['landscape_summary']['mean_b1_abs_fin']], 0.55, color=C[3],
       label=r'$|T|$ graph (non-negative)')
ax.bar([1], [R['landscape_summary']['mean_b1_pos_fin']], 0.55, color=C[2],
       label=r'sign-respecting $T$')
ax.set_xticks([0, 1]); ax.set_xticklabels([r'$|T|$', r'$T$ (signed)'])
ax.set_ylabel(r'cycle rank $\beta_1$ at matched density')
ax.set_title(f"Signed graph: {R['landscape_summary']['mean_neg_fin']:.0%} negative edges")
ax.legend(fontsize=6.5)
lab(ax, 'b')
ax = axes[2]
ur = R['urep']
runs = ur['runs']
phis = np.array([r['phi'] for r in runs]); accs = np.array([r['acc'] for r in runs])
ax.scatter(phis, accs, color=C[0], s=12, alpha=0.8, label='MLP family (n=64)')
ar = ur['arch_runs']
ax.scatter([r['phi'] for r in ar], [r['acc'] for r in ar], color=C[1], s=12, marker='s',
           alpha=0.8, label='recurrent families (n=18)')
ax.set_xlabel(r'$\Phi_c$'); ax.set_ylabel('final accuracy')
ax.set_title(rf"U_rep: LOO $R^2$ = {ur['loo_r2_full']:.2f} (fail)")
ax.legend(fontsize=6)
lab(ax, 'c')
fig.tight_layout(); fig.savefig(f'{F}/fig20_V4_mechanism.png', bbox_inches='tight'); plt.close(fig)

# ---- Fig 21
fig, axes = plt.subplots(1, 3, figsize=(6.8, 2.5))
ax = axes[0]
gran = R['granularity']['families']
names = [k for k in gran if k != 'retnet']
vals = [gran[k]['phi_mean'] for k in names]
errs = [gran[k]['phi_sd'] for k in names]
cols = [C[0] if not k.startswith('INT') else C[3] for k in names]
ax.barh(range(len(names)), vals, xerr=errs, color=cols, alpha=0.9)
ax.set_yticks(range(len(names))); ax.set_yticklabels(names, fontsize=6)
ax.axvline(0, color=C[6], lw=0.8)
ax.set_xlabel(r'$\Phi_c$ (family mean $\pm$ s.d.)')
ax.set_title('Granularity of $\\Phi_c$')
lab(ax, 'a')
ax = axes[1]
en = R['energy']
# recompute scatter from raw W/X runs for display
pts = []
for w in [50, 100, 200, 400]:
    for f in sorted(glob.glob(f'../results/W{w}_seed*.json')):
        d = json.load(open(f)); t = d['traj'][-1]
        params = 2 * 29 * 128 + (256 + 1) * w + (w + 1) * 29
        pts.append((6 * params * t['step'], t['val'], w))
for f in sorted(glob.glob('../results/X_seed*.json')):
    d = json.load(open(f)); t = d['traj'][-1]
    pts.append((6 * 36000 * t['step'], t['val'], 100))
for w, col in zip([50, 100, 200, 400], [C[0], C[1], C[2], C[4]]):
    sel = [(np.log10(p[0]), p[1]) for p in pts if p[2] == w]
    if sel:
        ax.scatter([q[0] for q in sel], [q[1] for q in sel], color=col, s=12,
                   label=f'w={w}')
ax.set_xlabel(r'$\log_{10}$ training FLOPs'); ax.set_ylabel('final accuracy')
ax.set_title(rf"Energy-capacity: $R^2$ = {en['r2_linear']:.2f} (saturated)")
ax.legend(fontsize=6)
lab(ax, 'b')
ax = axes[2]
dr = R['dose_response']
x = [p['d_pr'] for p in dr['points']]; y = [p['d_acc'] for p in dr['points']]
ax.scatter(x, y, color=C[3], s=16)
xx = np.linspace(min(x), max(x), 20)
ax.plot(xx, dr['slope'] * xx + dr['intercept'], color=C[6], ls='--', lw=1)
ax.set_xlabel(r'$\Delta$ participation ratio (A3$-$A1)')
ax.set_ylabel(r'$\Delta$ accuracy (A1$-$A3)')
ax.set_title(rf"Dose-response: $R^2$ = {dr['r2']:.2f} (failed)")
lab(ax, 'c')
fig.tight_layout(); fig.savefig(f'{F}/fig21_V4_granularity.png', bbox_inches='tight'); plt.close(fig)
print('V4 figures done')
