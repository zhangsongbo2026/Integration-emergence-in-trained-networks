"""E6 density-conditioned audit; E9 surrogate calibration + PH cost scaling;
E7 loop-birth post-processing from E1 profiles."""
import json, os, glob, time
import numpy as np

OUT = '../results'
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(7)


# ---------------- graph tools
def beta1_of(n_nodes, edges):
    """Exact beta1 = m - n + c via union-find."""
    par = list(range(n_nodes))
    def find(x):
        while par[x] != x:
            par[x] = par[par[x]]; x = par[x]
        return x
    c = n_nodes
    for u, v in edges:
        ru, rv = find(u), find(v)
        if ru != rv:
            par[ru] = rv; c -= 1
    return len(edges) - n_nodes + c


def er_graph(n, kbar, rng):
    p_edge = kbar / (n - 1)
    edges = [(i, j) for i in range(n) for j in range(i + 1, n)
             if rng.random() < p_edge]
    return edges


def E6():
    res = dict(synthetic=[], real=[])
    # (a) synthetic families: kbar ~ c * n^alpha
    for alpha in [0.0, 0.3, 0.6]:
        rows = []
        for n in [100, 200, 500, 1000, 2000]:
            for rep in range(3):
                kbar = max(2.5, 4.0 * (n / 100.0) ** alpha)
                edges = er_graph(n, kbar, rng)
                b1 = beta1_of(n, edges)
                m = len(edges)
                kbar_hat = 2 * m / n
                rows.append(dict(n=n, m=m, c=1, beta1=b1, kbar=kbar_hat,
                                 alpha=alpha))
        res['synthetic'].append(dict(alpha=alpha, rows=rows))
    # (b) real networks (networkx built-ins, open classic datasets)
    import networkx as nx
    named = {
        'karate_club': nx.karate_club_graph(),
        'davis_women': nx.davis_southern_women_graph(),
        'florentine_families': nx.florentine_families_graph(),
        'les_miserables': nx.les_miserables_graph(),
    }
    try:
        g = nx.graph_atlas(1000)  # deterministic atlas graph as extra
        named['atlas_1000'] = g
    except Exception:
        pass
    for name, G in named.items():
        G = nx.convert_node_labels_to_integers(G)
        edges = list(G.edges())
        b1 = beta1_of(G.number_of_nodes(), edges)
        m = len(edges); n = G.number_of_nodes()
        res['real'].append(dict(name=name, n=n, m=m, c=nx.number_connected_components(G),
                                beta1=b1, kbar=2 * m / n))
    # (c) regressions
    import numpy as np
    def ols(X, y):
        X = np.column_stack([np.ones(len(y)), X])
        beta, *_ = np.linalg.lstsq(X, y, rcond=None)
        pred = X @ beta
        r2 = 1 - ((y - pred) ** 2).sum() / ((y - y.mean()) ** 2).sum()
        return beta, r2
    # naive: pool all synthetic rows (mixed alpha) -> log beta1 ~ log n
    rows = [r for d in res['synthetic'] for r in d['rows']]
    y = np.log10([r['beta1'] + 1 for r in rows])
    xn = np.log10([r['n'] for r in rows])
    xk = np.log10([r['kbar'] for r in rows])
    (b0, bn), r2n = ols(xn[:, None], y)
    (b0c, bn_c, bk), r2c = ols(np.column_stack([xn, xk]), y)
    res['regression_naive'] = dict(b=bn, R2=r2n)
    res['regression_conditioned'] = dict(b_n=bn_c, b_logkbar=bk, R2=r2c)
    # per-alpha conditioned vs naive
    res['per_alpha'] = []
    for d in res['synthetic']:
        rr = d['rows']
        y = np.log10([r['beta1'] + 1 for r in rr])
        xn = np.log10([r['n'] for r in rr]); xk = np.log10([r['kbar'] for r in rr])
        (_, bn), r2n = ols(xn[:, None], y)
        (_, bnc, bk), r2c = ols(np.column_stack([xn, xk]), y)
        res['per_alpha'].append(dict(alpha=d['alpha'], b_naive=bn, R2_naive=r2n,
                                     b_cond=bnc, b_logk=bk, R2_cond=r2c))
    json.dump(res, open(f'{OUT}/E6_density_audit.json', 'w'))
    print('E6 done:', json.dumps(res['regression_naive']),
          json.dumps(res['regression_conditioned']))
    print('per_alpha:', json.dumps(res['per_alpha']))
    print('real:', json.dumps(res['real']))


def E9():
    """Surrogate calibration from E1 trajectories + PH cost scaling."""
    files = sorted(glob.glob(f'{OUT}/E1_seed*.json'))
    rows = []
    for f in files:
        d = json.load(open(f))
        seed = d['seed']
        for t in d['traj']:
            rows.append(dict(seed=seed, step=t['step'], val=t['val_acc'],
                             psi=t['psi'], r=t['r_logit'], rh=t['r_hidden'],
                             id=t['id'], sg=t['sg'], n_feat=t['n_feat'],
                             t_ph=t['t_ph'], t_id=t['t_id']))
    import scipy.stats as st
    def sp(a, b):
        return float(st.spearmanr(a, b).statistic)
    cal = dict(
        n_probes=len(rows), n_seeds=len(files),
        rho_psi_val=sp([r['psi'] for r in rows], [r['val'] for r in rows]),
        rho_psi_id=sp([r['psi'] for r in rows], [r['id'] for r in rows]),
        rho_psi_sg=sp([r['psi'] for r in rows], [r['sg'] for r in rows]),
        rho_id_val=sp([r['id'] for r in rows], [r['val'] for r in rows]),
        rho_sg_val=sp([r['sg'] for r in rows], [r['val'] for r in rows]),
        rho_r_val=sp([r['r'] for r in rows], [r['val'] for r in rows]),
        rho_rh_val=sp([r['rh'] for r in rows], [r['val'] for r in rows]),
        rho_psi_r=sp([r['psi'] for r in rows], [r['r'] for r in rows]),
        time_ph_s=float(np.mean([r['t_ph'] for r in rows])),
        time_surrogate_s=float(np.mean([r['t_id'] for r in rows])),
    )
    # PH cost scaling benchmark
    from mlp_core import cloud_prep, h1_diagram
    import torch
    from grok_core import make_data
    from mlp_core import MLPModel
    torch.set_num_threads(1)
    m = MLPModel(p=29, seed=0)
    m.load_state_dict(torch.load(f'{OUT}/E1_weights_seed0.pt'))
    _, _, Xva, Yva = make_data(29, 0.5, 0)
    with torch.no_grad():
        L, H = m(Xva)
    bench = []
    for N in [100, 200, 400, 600, 800]:
        Lc = cloud_prep(L, max_points=N, seed=0)
        t0 = time.time(); dgm = h1_diagram(Lc); dt = time.time() - t0
        pers = (dgm[:, 1] - dgm[:, 0]).sum() if len(dgm) else 0.0
        bench.append(dict(N=N, time_s=dt, psi=float(pers)))
    # approximate pipeline: PCA-8 + subsample 200 vs full-800 reference
    X = L.numpy(); mu = X.mean(0, keepdims=True); sd = X.std(0, keepdims=True) + 1e-9
    Xs = (X - mu) / sd
    from sklearn.decomposition import PCA
    Z = PCA(n_components=8, random_state=0).fit_transform(Xs)
    Z = Z / np.linalg.norm(Z, axis=1, keepdims=True)
    sel = np.random.default_rng(0).choice(len(Z), 200, replace=False)
    Zs = Z[sel]
    D = 1.0 - np.clip(Zs @ Zs.T, -1, 1)
    dgm = h1_diagram(np.clip((D + D.T) / 2, 0, 2))
    psi_fast = float((dgm[:, 1] - dgm[:, 0]).sum()) if len(dgm) else 0.0
    psi_full = [b for b in bench if b['N'] == 800][0]['psi']
    cal['ph_scaling'] = bench
    cal['approx_pipeline'] = dict(pca_dim=8, n_sub=200, psi_fast=psi_fast,
                                  psi_full800=psi_full,
                                  rel_diff=abs(psi_fast - psi_full) / max(psi_full, 1e-9))
    json.dump(dict(calibration=cal), open(f'{OUT}/E9_surrogate_calibration.json', 'w'))
    print('E9:', json.dumps({k: v for k, v in cal.items() if k != 'ph_scaling'}))


def E7():
    """Loop birth times from E1 class profiles: t_s = first probe where
    corr(P_t[s,:], P_final[s,:]) > 0.8. Waiting-time distribution test."""
    from scipy.stats import kstest
    births = []
    for f in sorted(glob.glob(f'{OUT}/E1_seed*.json')):
        d = json.load(open(f))
        traj = d['traj']
        P = np.array([t['profile'] for t in traj])   # (T, p, p)
        Pf = P[-1]
        steps = [t['step'] for t in traj]
        for s in range(P.shape[1]):
            cs = [float(np.corrcoef(P[t, s], Pf[s])[0, 1]) for t in range(P.shape[0])]
            idx = next((i for i, c in enumerate(cs) if c > 0.8), None)
            births.append(dict(seed=d['seed'], cls=s, birth=steps[idx] if idx is not None else None))
    ts = [b['birth'] for b in births if b['birth'] is not None]
    born = np.array([t for t in ts if t > 0], dtype=float)
    # exponential fit: lambda = 1/mean; KS test
    lam = 1.0 / born.mean()
    ks = kstest(born / born.mean(), 'expon')
    json.dump(dict(births=births, n=len(born), mean_birth=float(born.mean()),
                   median_birth=float(np.median(born)),
                   cv=float(born.std() / born.mean()), ks_stat=ks.statistic,
                   ks_p=ks.pvalue),
              open(f'{OUT}/E7_loop_births.json', 'w'))
    print('E7: n', len(born), 'mean', born.mean(), 'CV', born.std() / born.mean(),
          'KS', ks.statistic, 'p', ks.pvalue)


if __name__ == '__main__':
    import sys
    which = sys.argv[1] if len(sys.argv) > 1 else 'all'
    if which in ('E6', 'all'):
        E6()
    if which in ('E7', 'all'):
        E7()
    if which in ('E9', 'all'):
        E9()
