"""MLP grokking core with full measurement suite (V2 locked metrics candidate)."""
import math, json, time
import numpy as np
import torch, torch.nn as nn, torch.nn.functional as F
from grok_core import make_data

torch.set_num_threads(4)


class MLPModel(nn.Module):
    def __init__(self, p=29, d=128, dh=100, seed=0):
        super().__init__()
        torch.manual_seed(seed)
        self.p, self.dh = p, dh
        self.ea = nn.Embedding(p, d)
        self.eb = nn.Embedding(p, d)
        self.fc1 = nn.Linear(2 * d, dh)
        self.fc2 = nn.Linear(dh, p)

    def forward(self, tokens):
        x = torch.cat([self.ea(tokens[:, 0]), self.eb(tokens[:, 1])], dim=1)
        h = F.relu(self.fc1(x))
        return self.fc2(h), h


class LoopMLPModel(nn.Module):
    """RAU-analog: fraction theta of hidden units rerouted through a
    persistent loop-memory buffer (ring update), hybrid gain gamma."""

    def __init__(self, p=29, d=128, dh=100, theta=0.2, gamma=0.5, seed=0):
        super().__init__()
        torch.manual_seed(seed)
        self.p, self.dh, self.gamma = p, dh, gamma
        n_loop = max(1, int(round(theta * dh)))
        self.n_loop = n_loop
        self.ea = nn.Embedding(p, d)
        self.eb = nn.Embedding(p, d)
        self.fc1 = nn.Linear(2 * d, dh)
        self.fc2 = nn.Linear(dh, p)
        # ring (cyclic) mixing matrix over loop units
        ring = torch.zeros(n_loop, n_loop)
        for i in range(n_loop):
            ring[i, (i + 1) % n_loop] = 1.0
        self.register_buffer('ring', ring)
        self.loop_state = None

    def reset_loop(self, batch=1):
        self.loop_state = torch.zeros(batch, self.n_loop)

    def forward(self, tokens):
        x = torch.cat([self.ea(tokens[:, 0]), self.eb(tokens[:, 1])], dim=1)
        h = F.relu(self.fc1(x))
        hl = h[:, :self.n_loop]
        # one ring step (persistent recurrence across forward passes when kept)
        if self.loop_state is None or self.loop_state.shape[0] != tokens.shape[0]:
            self.loop_state = torch.zeros_like(hl)
        hl_new = (1 - self.gamma) * hl + self.gamma * (hl @ self.ring + self.loop_state)
        self.loop_state = hl_new.detach() * 0.5 + self.loop_state.detach() * 0.5
        h2 = torch.cat([hl_new, h[:, self.n_loop:]], dim=1)
        return self.fc2(h2), h2


def cloud_prep(H, max_points=300, seed=0, standardize=True):
    rng = np.random.default_rng(seed)
    X = H.detach().cpu().numpy()
    if X.shape[0] > max_points:
        sel = rng.choice(X.shape[0], max_points, replace=False)
        X = X[sel]
    if standardize:
        mu, sd = X.mean(0, keepdims=True), X.std(0, keepdims=True) + 1e-9
        X = (X - mu) / sd
    nrm = np.linalg.norm(X, axis=1, keepdims=True); nrm[nrm == 0] = 1
    return X / nrm


def h1_diagram(Xprep):
    from ripser import ripser
    D = 1.0 - np.clip(Xprep @ Xprep.T, -1, 1)
    D = np.clip((D + D.T) / 2, 0, 2)
    return ripser(D, maxdim=1, distance_matrix=True)['dgms'][1]


def psi1_variants(dgm):
    pers = dgm[:, 1] - dgm[:, 0] if len(dgm) else np.array([0.0])
    out = {}
    out['psi_weighted'] = float(np.maximum(0, pers - np.median(pers) if len(pers) else 0).sum() / (np.median(pers) if len(pers) and np.median(pers) > 0 else 1))
    out['psi_top5'] = float(np.sort(pers)[-5:].sum())
    out['psi_top1'] = float(np.sort(pers)[-1])
    out['psi_total'] = float(pers.sum())
    out['n_feat'] = int(len(pers))
    return out


def class_means(H, cls, p):
    """Class-mean activation vectors (the Z_p circuit cloud)."""
    X = H.detach().cpu().numpy()
    means = np.zeros((p, X.shape[1]))
    for s in range(p):
        m = X[cls == s]
        means[s] = m.mean(0) if len(m) else 0.0
    return means


def zstd(X):
    mu, sd = X.mean(0, keepdims=True), X.std(0, keepdims=True) + 1e-9
    Z = (X - mu) / sd
    return Z / (np.linalg.norm(Z, axis=1, keepdims=True) + 1e-12)


def psi1_circuit(H, cls, p, n_null=3, seed=0):
    """Psi1: weighted total H1 persistence of the class-mean cloud.
    Null: class labels randomly permuted before averaging (breaks the cycle
    structure but keeps the marginal geometry)."""
    rng = np.random.default_rng(seed)
    means = class_means(H, cls, p)
    Z = zstd(means)
    dgm = h1_diagram(Z)
    pers = dgm[:, 1] - dgm[:, 0] if len(dgm) else np.array([0.0])
    tau = np.median(pers) if len(pers) else 1.0
    val = float(np.maximum(pers - 0.5 * tau, 0).sum()) if len(pers) else 0.0
    null_vals = []
    cls_np = np.asarray(cls)
    for _ in range(n_null):
        perm = rng.permutation(cls_np)
        Zn = zstd(class_means(H, perm, p))
        dn = h1_diagram(Zn)
        pn = dn[:, 1] - dn[:, 0] if len(dn) else np.array([0.0])
        tn = np.median(pn) if len(pn) else 1.0
        null_vals.append(float(np.maximum(pn - 0.5 * tn, 0).sum()) if len(pn) else 0.0)
    return val, float(np.mean(null_vals)), dgm


def kuramoto_r_circuit(H, cls, p):
    """r: phase-locking of the p class oscillators to the task frequency lattice.
    theta_c = angle of class-mean in top-2 PCA plane; phi_c = 2*pi*c/p.
    r = |mean exp(i(theta_c - phi_c))| maximized over orientation and shift
    (the lattice's absolute phase is a gauge freedom)."""
    means = class_means(H, cls, p)
    Zm = zstd(means) - zstd(means).mean(0, keepdims=True)
    V = np.linalg.svd(Zm, full_matrices=False)[2][:2]
    proj = Zm @ V.T
    theta = np.arctan2(proj[:, 1], proj[:, 0])
    phi = 2 * np.pi * np.arange(p) / p
    conc2 = float((np.linalg.svd(Zm, compute_uv=False)[0] ** 2 +
                   np.linalg.svd(Zm, compute_uv=False)[1] ** 2) /
                  (np.linalg.svd(Zm, compute_uv=False) ** 2).sum() + 1e-12)
    best, best_shift = 0.0, 0.0
    for sign in (+1, -1):
        for shift in np.linspace(0, 2 * np.pi, p, endpoint=False):
            r = abs(np.exp(1j * (theta - sign * phi - shift)).mean())
            if r > best:
                best, best_shift = r, shift
    return best, conc2


def two_nn_id(X, k=5):
    from sklearn.neighbors import NearestNeighbors
    n = len(X)
    nn = NearestNeighbors(n_neighbors=min(k + 1, n)).fit(X)
    d, _ = nn.kneighbors(X)
    d = np.maximum(d[:, 1:], 1e-12)
    m = d.shape[1]
    return float(np.mean((m) / np.log(d[:, -1][:, None] / d[:, :-1]).sum(axis=1)))


def spectral_gap(Xp, k=10):
    S = np.clip(Xp @ Xp.T, 0, 1); np.fill_diagonal(S, 0)
    W = np.zeros_like(S)
    idxp = np.argpartition(-S, k, axis=1)[:, :k]
    for i, js in enumerate(idxp):
        W[i, js] = S[i, js]; W[js, i] = np.maximum(W[js, i], S[i, js])
    deg = W.sum(1) + 1e-12
    L = np.eye(len(W)) - (1 / np.sqrt(deg))[:, None] * W * (1 / np.sqrt(deg))[None, :]
    ev = np.sort(np.linalg.eigvalsh(L))
    return float(ev[1] - ev[0])


def probe(m, Xva_d, Xva_np, Yva, p, seed=0):
    m.eval()
    with torch.no_grad():
        _, H = m(Xva_d)
    cls = Yva.numpy()
    psi_c, psi_null, dgm_c = psi1_circuit(H, cls, p, seed=seed)
    r_c, conc2 = kuramoto_r_circuit(H, cls, p)
    Xp = cloud_prep(H, seed=seed)          # prompt cloud for ID/SG/sparsity
    dgm_p = h1_diagram(Xp)
    pv = dict(psi=psi_c, psi_null=psi_null,
              psi_net=psi_c - psi_null, r=r_c, conc2=conc2,
              psi_top5=float(np.sort(dgm_c[:, 1] - dgm_c[:, 0])[-5:].sum()
                             if len(dgm_c) else 0.0))
    pv['id'] = two_nn_id(Xp)
    pv['sg'] = spectral_gap(Xp)
    pv['sparsity'] = float((np.abs(H.detach().cpu().numpy()) < 1e-3).mean())
    m.train()
    return pv, dgm_c, dgm_p
