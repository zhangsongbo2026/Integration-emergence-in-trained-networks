import time, sys, numpy as np, torch, torch.nn.functional as F
from grok_core import AttnOnlyModel, make_data

lr = float(sys.argv[1]); wd = float(sys.argv[2]); steps = int(sys.argv[3])
seed = int(sys.argv[4]) if len(sys.argv) > 4 else 0
p = int(sys.argv[5]) if len(sys.argv) > 5 else 29

m = AttnOnlyModel(p=p, seed=seed)
Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=wd)
t0 = time.time()
first_grok = None
for step in range(steps + 1):
    if step % 2000 == 0 or step == steps:
        with torch.no_grad():
            lv, _ = m(Xva); v = (lv.argmax(-1) == Yva).float().mean().item()
            lt, _ = m(Xtr); tr = (lt.argmax(-1) == Ytr).float().mean().item()
        if v > 0.8 and first_grok is None:
            first_grok = step
        print(f'cfg lr={lr} wd={wd} step={step} train={tr:.3f} val={v:.3f} t={time.time()-t0:.0f}s', flush=True)
    if step == steps:
        break
    opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
print('RESULT', lr, wd, p, seed, 'grok_step', first_grok, flush=True)
