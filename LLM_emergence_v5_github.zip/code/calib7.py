import json, time, numpy as np, torch, torch.nn.functional as F
from grok_core import make_data
from mlp_core import MLPModel, cloud_prep, h1_diagram, two_nn_id, spectral_gap

p, lr, wd, steps, seed = 29, 1e-3, 2.0, 60000, 0
m = MLPModel(p=p, seed=seed)
Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
S = ((Xva[:, 0] + Xva[:, 1]) % p).numpy().astype(float)
opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=wd)

def cycle_align(Z):
    """r_cyc: alignment of pairwise cosine similarity with the class cycle."""
    Z = Z - Z.mean(0, keepdims=True)
    n = len(Z)
    rng = np.random.default_rng(0)
    i = rng.integers(0, n, 20000); j = rng.integers(0, n, 20000)
    keep = i != j
    i, j = i[keep], j[keep]
    Zn = Z / (np.linalg.norm(Z, axis=1, keepdims=True) + 1e-12)
    A = (Zn[i] * Zn[j]).sum(1)
    d = np.abs(S[i] - S[j]); d = np.minimum(d, p - d)
    B = np.cos(2 * np.pi * d / p)
    return float(np.corrcoef(A, B)[0, 1])

traj = []
t0 = time.time()
for step in range(steps + 1):
    if step % 2000 == 0 or step == steps:
        m.eval()
        with torch.no_grad():
            L, H = m(Xva); v = (L.argmax(-1) == Yva).float().mean().item()
        Hn = H.numpy()
        r_h = cycle_align(Hn)
        r_l = cycle_align(L.numpy())
        # topological metrics on logit cloud
        Lc = cloud_prep(L, seed=0)
        dgm = h1_diagram(Lc)
        psi = float((dgm[:, 1] - dgm[:, 0]).sum()) if len(dgm) else 0.0
        idv = two_nn_id(Lc); sgv = spectral_gap(Lc)
        m.train()
        traj.append(dict(step=step, val=v, r_hidden=r_h, r_logit=r_l,
                         psi=psi, id=idv, sg=sgv))
        print(f"st {step} val {v:.2f} r_h {r_h:.3f} r_l {r_l:.3f} psi {psi:.1f} id {idv:.1f} sg {sgv:.3f}", flush=True)
    if step == steps:
        break
    opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
print('wall', round(time.time() - t0, 1))
json.dump(traj, open('calib_mlp6_seed0.json', 'w'))
