"""V4 consolidated analysis: landscape barrier, signed interaction graph,
U_rep test (leave-one-run-out), dose-response calibration, granularity
registration, energy ledger, Phi_c normalisation invariance."""
import json, glob
import numpy as np
from scipy import stats as st
from scipy.optimize import curve_fit

OUT = '../results'
R = {}


def load(pat):
    out = []
    for f in sorted(glob.glob(f'{OUT}/{pat}')):
        try:
            out.append(json.load(open(f)))
        except Exception:
            pass
    return out


# ---------------------------------------------------------------- A. landscape
land = load('V4_landscape_seed*.json')
rows = []
for d in land:
    path = d['path']
    psi0, sg0 = path[0]['psi'], path[0]['sg']
    # two-channel index along the path (id not recorded on the interpolation sweep)
    phi = [0.5 * ((1 - q['psi'] / max(psi0, 1e-9)) + (1 - q['sg'] / max(sg0, 1e-9))) for q in path]
    accs = [q['acc'] for q in path]
    imin = int(np.argmin(accs))
    rows.append(dict(seed=d['seed'], tau=d['tau'],
                     acc_mem=accs[0], acc_fin=accs[-1],
                     min_acc=float(accs[imin]), alpha_min=float(path[imin]['alpha']),
                     phi_end=float(phi[-1]),
                     sg_mem=float(path[0]['sg']), sg_fin=float(path[-1]['sg']),
                     neg_frac_mem=path[0]['neg_frac'], neg_frac_fin=path[-1]['neg_frac'],
                     b1_abs_mem=path[0]['b1_abs'], b1_pos_mem=path[0]['b1_pos'],
                     b1_abs_fin=path[-1]['b1_abs'], b1_pos_fin=path[-1]['b1_pos']))
R['landscape'] = rows
R['landscape_summary'] = dict(
    n=len(rows),
    mean_min_acc=float(np.mean([r['min_acc'] for r in rows])),
    mean_alpha=float(np.mean([r['alpha_min'] for r in rows])),
    mean_phi_end=float(np.mean([r['phi_end'] for r in rows])),
    mean_neg_mem=float(np.mean([r['neg_frac_mem'] for r in rows])),
    mean_neg_fin=float(np.mean([r['neg_frac_fin'] for r in rows])),
    mean_b1_abs_fin=float(np.mean([r['b1_abs_fin'] for r in rows])),
    mean_b1_pos_fin=float(np.mean([r['b1_pos_fin'] for r in rows])))


# ---------------------------------------------------------------- B. U_rep test
def phi_from(psi0, psi1, sg0, sg1, id0, id1):
    return 1 / 3 * ((1 - psi1 / max(psi0, 1e-9)) + (1 - sg1 / max(sg0, 1e-9)) +
                    (1 - id1 / max(id0, 1e-9)))


runs = []
for d in load('E1_seed*.json'):
    t0, t1 = d['traj'][0], d['traj'][-1]
    runs.append(dict(family='MLP-E1', seed=d['seed'], phi=phi_from(t0['psi'], t1['psi'], t0['sg'], t1['sg'],
                                                                   t0['id'], t1['id']),
                     acc=t1['val_acc'], steps=t1['step'], params=36000))
for d in load('X_seed*.json'):
    t0, t1 = d['traj'][0], d['traj'][-1]
    runs.append(dict(family='MLP-X', seed=d['seed'], phi=phi_from(t0['psi'], t1['psi'], t0['sg'], t1['sg'],
                                                                  t0['id'], t1['id']),
                     acc=t1['val'], steps=t1['step'], params=36000))
for a in ['A0', 'A1', 'A2', 'A3']:
    for d in load(f'D21b_{a}_seed*.json'):
        t0, t1 = d['traj'][0], d['traj'][-1]
        runs.append(dict(family=f'INT-{a}', seed=d['seed'], phi=phi_from(t0['psi'], t1['psi'], t0['sg'], t1['sg'],
                                                                        t0['id'], t1['id']),
                         acc=t1['val'], steps=t1['step'], params=36000))
# surrogate-based phi for architectures (no psi stored)
arch_runs = []
EXCL = []
for name in ['retnet', 'rwkv', 'ssm']:
    for d in load(f'ARCH_{name}_seed*.json'):
        t0, t1 = d['traj'][0], d['traj'][-1]
        if t0['sg'] < 0.01:            # degenerate baseline: index undefined
            EXCL.append(dict(family=name, seed=d['seed'], sg0=t0['sg'],
                             reason='degenerate baseline (sg0<0.01)'))
            continue
        phi_s = 0.5 * ((1 - t1['sg'] / t0['sg']) + (1 - t1['id'] / t0['id']))
        arch_runs.append(dict(family=name, seed=d['seed'], phi=float(phi_s),
                              acc=t1['val'], steps=t1['step'], params=36000))
R['excluded_degenerate'] = EXCL


def loo_r2(rs, key='phi'):
    """Leave-one-run-out R^2 of a monotone (isotonic-free) logistic fit."""
    phis = np.array([r[key] for r in rs]); acc = np.array([r['acc'] for r in rs])
    preds = []
    for i in range(len(rs)):
        m = np.ones(len(rs), bool); m[i] = False
        x, y = phis[m], acc[m]
        # fit a 3-parameter logistic; fall back to linear if it fails
        try:
            def f(x, a, b, c): return a / (1 + np.exp(-b * (x - c)))
            p0 = [max(y.max(), 0.5), 3.0, float(np.median(x))]
            popt, _ = curve_fit(f, x, y, p0=p0, maxfev=20000)
            preds.append(float(f(phis[i], *popt)))
        except Exception:
            k, b0 = np.polyfit(x, y, 1)
            preds.append(float(k * phis[i] + b0))
    preds = np.array(preds)
    ss_res = ((acc - preds) ** 2).sum()
    ss_tot = ((acc - acc.mean()) ** 2).sum()
    return float(1 - ss_res / ss_tot), phis, acc


r2_all, phis, accs = loo_r2(runs)
r2_arch, phis_a, accs_a = loo_r2(arch_runs)
R['urep'] = dict(n_full=len(runs), loo_r2_full=r2_all, n_excluded=len(EXCL),
                 n_arch=len(arch_runs), loo_r2_arch=r2_arch,
                 threshold=0.8,
                 verdict_full='supported' if r2_all >= 0.8 else 'not supported',
                 verdict_arch='supported' if r2_arch >= 0.8 else 'not supported',
                 phi_range_full=[float(min(phis)), float(max(phis))],
                 phi_range_arch=[float(min(phis_a)), float(max(phis_a))],
                 runs=runs, arch_runs=arch_runs)

# ---------------------------------------------------------------- C. dose-response (V8)
dose = []
for s in range(8):
    try:
        a1 = json.load(open(f'{OUT}/D21b_A1_seed{s}.json'))['traj'][-1]
        a3 = json.load(open(f'{OUT}/D21b_A3_seed{s}.json'))['traj'][-1]
        dose.append(dict(seed=s, d_pr=a3['pr'] - a1['pr'], d_acc=a1['val'] - a3['val']))
    except Exception:
        pass
x = np.array([d['d_pr'] for d in dose]); y = np.array([d['d_acc'] for d in dose])
k, b = np.polyfit(x, y, 1)
pred = k * x + b
r2 = 1 - ((y - pred) ** 2).sum() / ((y - y.mean()) ** 2).sum()
R['dose_response'] = dict(n=len(dose), slope=float(k), intercept=float(b),
                          r2=float(r2), pearson=float(st.pearsonr(x, y).statistic),
                          points=dose,
                          verdict='calibration failed' if r2 < 0.3 else 'calibrated')

# ---------------------------------------------------------------- D. granularity + invariance
fam = {}
for r in runs + arch_runs:
    fam.setdefault(r['family'], []).append(r)
gran = {k: dict(n=len(v), phi_mean=float(np.mean([q['phi'] for q in v])),
                phi_sd=float(np.std([q['phi'] for q in v])),
                acc_mean=float(np.mean([q['acc'] for q in v])),
                acc_sd=float(np.std([q['acc'] for q in v])),
                steps_mean=float(np.mean([q['steps'] for q in v])))
        for k, v in fam.items()}
# normalisation invariance: own-baseline vs global-baseline phi
base_phi = np.array([r['phi'] for r in runs])
# global baseline: use the mean first-probe values of the MLP-X family
xg = load('X_seed*.json')
g_psi = np.mean([d['traj'][0]['psi'] for d in xg])
g_sg = np.mean([d['traj'][0]['sg'] for d in xg])
g_id = np.mean([d['traj'][0]['id'] for d in xg])
alt = []
for d in xg:
    t1 = d['traj'][-1]
    alt.append(1 / 3 * ((1 - t1['psi'] / g_psi) + (1 - t1['sg'] / g_sg) + (1 - t1['id'] / g_id)))
own = [r['phi'] for r in runs if r['family'] == 'MLP-X']
R['granularity'] = dict(families=gran,
                        invariance_spearman=float(st.spearmanr(own, alt).statistic),
                        invariance_n=len(own))

# ---------------------------------------------------------------- E. energy ledger
led = []
for d in load('X_seed*.json'):
    t1 = d['traj'][-1]
    led.append(dict(family='MLP-X', steps=t1['step'], params=36000,
                    flops=6 * 36000 * t1['step'], acc=t1['val']))
for w in [50, 100, 200, 400]:
    for d in load(f'W{w}_seed*.json'):
        t1 = d['traj'][-1]
        params = 2 * 29 * 128 + (256 + 1) * w + (w + 1) * 29
        led.append(dict(family=f'W{w}', steps=t1['step'], params=params,
                        flops=6 * params * t1['step'], acc=t1['val'],
                        sg=t1['sg']))
la = np.log10([q['flops'] for q in led])
ac = np.array([q['acc'] for q in led])
k, b = np.polyfit(la, ac, 1)
pred = k * la + b
r2_energy = 1 - ((ac - pred) ** 2).sum() / ((ac - ac.mean()) ** 2).sum()
R['energy'] = dict(n=len(led), slope=float(k), r2_linear=float(r2_energy),
                   acc_range=[float(ac.min()), float(ac.max())],
                   note='capacity saturates: accuracy spans only 0.72-1.00 across a 20-fold compute range')

json.dump(R, open(f'{OUT}/analysis_v4.json', 'w'), indent=1, default=str)
print('landscape:', json.dumps(R['landscape_summary']))
print('U_rep:', {k: R['urep'][k] for k in ['n_full', 'loo_r2_full', 'n_arch', 'loo_r2_arch',
                                           'verdict_full', 'verdict_arch', 'threshold']})
print('dose:', {k: R['dose_response'][k] for k in ['n', 'slope', 'r2', 'pearson', 'verdict']})
print('granularity families:', {k: (v['n'], round(v['phi_mean'], 2), round(v['acc_mean'], 3))
                                for k, v in gran.items()})
print('invariance rho:', R['granularity']['invariance_spearman'])
print('energy:', {k: R['energy'][k] for k in ['n', 'slope', 'r2_linear']})
