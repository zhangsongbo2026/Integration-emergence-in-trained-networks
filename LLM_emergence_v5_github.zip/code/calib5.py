import json, time, numpy as np, torch, torch.nn.functional as F
from grok_core import make_data
from mlp_core import MLPModel, cloud_prep, h1_diagram, two_nn_id, spectral_gap

p, lr, wd, steps, seed = 29, 1e-3, 2.0, 60000, 0
m = MLPModel(p=p, seed=seed)
Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=wd)

def lock_and_psi():
    """Equivariance (Z_p lock-in) + PH of the prompt-logit cloud."""
    m.eval()
    with torch.no_grad():
        L, H = m(Xva)                       # (n, p) logits, (n, dh) hidden
        # shifted prompts: (a+1, b+1)
        Xsh = Xva.clone(); Xsh[:, 0] = (Xsh[:, 0] + 1) % p; Xsh[:, 1] = (Xsh[:, 1] + 1) % p
        Lsh, _ = m(Xsh)
        # equivariance: Lsh[c+1] should equal L[c]
        Lsh_rolled = torch.roll(Lsh, shifts=1, dims=1)
        err = (L - Lsh_rolled).abs().mean().item()
        scale = L.abs().mean().item() + 1e-9
        e_norm = err / scale
        # also reverse equivariance check for stability
        r_lock = float(np.exp(-e_norm))     # ~0 pre, ->1 post (monotone map)
        # PH of prompt-logit cloud (n=300 points in R^p)
        Lc = cloud_prep(L, max_points=300, seed=0, standardize=True)
        dgm = h1_diagram(Lc)
        pers = dgm[:, 1] - dgm[:, 0] if len(dgm) else np.array([0.0])
        psi = float(pers.sum())
        psi_top3 = float(np.sort(pers)[-3:].sum())
        n_feat = len(pers)
        idv = two_nn_id(Lc)
        sgv = spectral_gap(Lc)
    m.train()
    return dict(r_lock=r_lock, e_norm=e_norm, psi=psi, psi_top3=psi_top3,
                n_feat=n_feat, id=idv, sg=sgv)

traj = []
t0 = time.time()
for step in range(steps + 1):
    if step % 2000 == 0 or step == steps:
        with torch.no_grad():
            lv, _ = m(Xva); v = (lv.argmax(-1) == Yva).float().mean().item()
        met = lock_and_psi()
        met.update(step=step, val=v)
        traj.append(met)
        print(f"st {step} val {v:.2f} r_lock {met['r_lock']:.3f} e_norm {met['e_norm']:.2f} "
              f"psi {met['psi']:.2f} top3 {met['psi_top3']:.2f} nf {met['n_feat']} id {met['id']:.1f} sg {met['sg']:.3f}", flush=True)
    if step == steps:
        break
    opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
print('wall', round(time.time() - t0, 1))
json.dump(traj, open('calib_mlp4_seed0.json', 'w'))
