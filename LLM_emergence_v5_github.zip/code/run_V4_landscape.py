"""V4 experiments: (a) barrier landscape along the memorisation->consolidation
interpolation; (b) signed interaction graph measurements.

(a) For a grokking run, save W_mem at a pre-grok probe and W_final at grokking;
sweep the linear interpolation W(alpha) = (1-alpha) W_mem + alpha W_final,
recording validation accuracy, loss, consolidation index and signed-graph
statistics. A dip in accuracy along the path quantifies the barrier between
the two solutions (linear-mode-connectivity style).

(b) Signed interaction graph: class-mean activation correlations at the same
checkpoints; positive/negative edge fractions; cycle rank of |T|-thresholded
graph versus sign-respecting graph.

Usage: python run_V4_landscape.py <seed>
"""
import json, os, sys, time, gc
import numpy as np, torch, torch.nn.functional as F
from grok_core import make_data
from mlp_core import MLPModel, cloud_prep, two_nn_id, spectral_gap, h1_diagram

torch.set_num_threads(1)
p = 29
OUT = '../results'


def psi_of_logits(lv):
    Lc = cloud_prep(lv, max_points=300, seed=0)
    dgm = h1_diagram(Lc)
    return float((dgm[:, 1] - dgm[:, 0]).sum()) if len(dgm) else 0.0


def index_and_signed(m, Xva, p):
    """Consolidation index components and signed class-mean correlations."""
    with torch.no_grad():
        lv, H = m(Xva)
    cls = ((Xva[:, 0] + Xva[:, 1]) % p).numpy()
    means = np.stack([H.numpy()[cls == c].mean(0) if (cls == c).any() else np.zeros(H.shape[1])
                      for c in range(p)])
    Z = (means - means.mean(0, keepdims=True)) / (means.std(0, keepdims=True) + 1e-9)
    C = np.corrcoef(Z)                       # signed class-class correlation matrix
    iu = np.triu_indices(p, 1)
    vals = C[iu]
    neg = float((vals < 0).mean())
    strong_neg = float((vals < -0.2).mean())
    # cycle rank on a thresholded graph vs the sign-respecting graph
    thr = np.quantile(np.abs(vals), 0.75)
    dense = C.copy(); np.fill_diagonal(dense, 0)
    A_abs = (np.abs(dense) > thr).astype(int)          # non-negative graph
    A_pos = ((dense > thr)).astype(int)                # sign-respecting: keep positive edges
    b1_abs = _beta1(A_abs); b1_pos = _beta1(A_pos)
    return dict(neg_frac=neg, strong_neg_frac=strong_neg,
                b1_abs=b1_abs, b1_pos=b1_pos, kbar_abs=float(A_abs.sum() / p),
                kbar_pos=float(A_pos.sum() / p))


def _beta1(A):
    n = len(A)
    par = list(range(n))
    def find(x):
        while par[x] != x:
            par[x] = par[par[x]]; x = par[x]
        return x
    c = n; m = 0
    for i in range(n):
        for j in range(i + 1, n):
            if A[i, j]:
                m += 1
                ri, rj = find(i), find(j)
                if ri != rj:
                    par[ri] = rj; c -= 1
    return int(m - n + c)


def run(seed, steps=60000):
    m = MLPModel(p=p, seed=seed)
    Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
    opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=2.0)
    W_mem = None; step_mem = None; tau = None
    t0 = time.time()
    for step in range(steps + 1):
        if step % 1000 == 0:
            with torch.no_grad():
                lv, _ = m(Xva); v = (lv.argmax(-1) == Yva).float().mean().item()
            if W_mem is None and step >= 4000:
                W_mem = {k: v2.detach().clone() for k, v2 in m.state_dict().items()}
                step_mem = step
            if tau is None and v >= 0.5:
                tau = step
            if v >= 0.92:
                break
        if step == steps:
            break
        opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
    W_fin = {k: v2.detach().clone() for k, v2 in m.state_dict().items()}
    with torch.no_grad():
        lv, _ = m(Xva)
    chk = dict(val=float((lv.argmax(-1) == Yva).float().mean().item()),
               loss=float(F.cross_entropy(lv, Yva).item()), psi=psi_of_logits(lv),
               id=two_nn_id(cloud_prep(lv, max_points=300, seed=0)),
               sg=spectral_gap(cloud_prep(lv, max_points=300, seed=0)),
               **_and_signed_safe(m, Xva, p))
    # interpolation sweep
    alphas = np.linspace(0, 1, 41)
    path = []
    for a in alphas:
        sd = {k: (1 - a) * W_mem[k] + a * W_fin[k] for k in W_fin}
        m.load_state_dict(sd)
        with torch.no_grad():
            lv, _ = m(Xva)
            acc = float((lv.argmax(-1) == Yva).float().mean().item())
            loss = float(F.cross_entropy(lv, Yva).item())
            Lc = cloud_prep(lv, max_points=300, seed=0)
        sgn = _and_signed_safe(m, Xva, p)
        path.append(dict(alpha=float(a), acc=acc, loss=loss,
                         psi=psi_of_logits(lv), sg=spectral_gap(Lc),
                         **sgn))
        if a in (0.0, 1.0):
            print(f'seed {seed} alpha {a:.2f} acc {acc:.3f} sg {path[-1]["sg"]:.3f}', flush=True)
    # barrier = accuracy dip along the path
    accs = [q['acc'] for q in path]
    imin = int(np.argmin(accs))
    rec = dict(seed=seed, tau=tau, step_mem=step_mem, final=chk,
               path=path, barrier=dict(min_acc=float(accs[imin]),
                                       alpha_at_min=float(alphas[imin]),
                                       acc_endpoints=[float(accs[0]), float(accs[-1])]),
               wall=time.time() - t0)
    json.dump(rec, open(f'{OUT}/V4_landscape_seed{seed}.json', 'w'))
    print(f'seed {seed}: tau {tau} barrier min acc {accs[imin]:.3f} at alpha {alphas[imin]:.2f}', flush=True)
    gc.collect()


def _and_signed_safe(m, Xva, p):
    try:
        return index_and_signed(m, Xva, p)
    except Exception as e:
        print('signed measure failed:', e, flush=True)
        return dict(neg_frac=None, strong_neg_frac=None, b1_abs=None, b1_pos=None,
                    kbar_abs=None, kbar_pos=None)


if __name__ == '__main__':
    run(int(sys.argv[1]))
