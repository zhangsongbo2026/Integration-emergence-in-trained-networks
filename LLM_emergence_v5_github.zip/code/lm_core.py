"""Language-model core for the scale-ladder / cross-layer integration study.

A small decoder-only Transformer trained on a synthetic multi-skill corpus
(four in-context rules). Measured at each probe:
  - per-skill next-token accuracy and loss
  - per-layer spectral gap and participation ratio
  - cross-layer CKA matrix and the integration index Lambda
    (adjacent-layer minus distant-layer CKA)
"""
import math, json, time, os
import numpy as np
import torch, torch.nn as nn, torch.nn.functional as F

torch.set_num_threads(1)
VOCAB = 64          # 0 = task-0 marker ... 3 = task-3 marker; data tokens 4..63
NTASK = 4
SEQ = 24
N_DATA = 60


def make_batch(rng, batch, seq=SEQ):
    """task id at position 0, data tokens afterwards; targets = rule output."""
    task = rng.integers(0, NTASK, batch)[:, None]
    data = rng.integers(0, N_DATA, (batch, seq - 1))
    x = np.concatenate([task, data], axis=1) + 0  # token ids 0..3 then 0..59
    x[:, 0] = task[:, 0]                            # markers 0..3
    x[:, 1:] = data + 4                             # data tokens 4..63
    y = np.zeros_like(x)
    # rule targets for positions 1..seq-1 (predict next data token)
    prev = np.concatenate([data[:, :1], data[:, :-1]], axis=1)
    pos = np.arange(seq - 1)[None, :]
    t = task[:, 0][:, None]
    out = np.where(t == 0, prev,                                  # copy
          np.where(t == 1, (prev + 1) % N_DATA,                   # successor
          np.where(t == 2, (prev * 2 + 1) % N_DATA,               # affine
                   (prev + pos) % N_DATA)))                       # position shift
    y[:, 0] = -100
    y[:, 1:] = out + 4
    return torch.tensor(x), torch.tensor(y)


class TinyLM(nn.Module):
    def __init__(self, vocab=VOCAB, d=64, n_layer=4, n_head=2, seq=SEQ, seed=0):
        super().__init__()
        torch.manual_seed(seed)
        self.d, self.n_layer = d, n_layer
        self.tok = nn.Embedding(vocab, d)
        self.pos = nn.Parameter(torch.zeros(seq, d))
        nn.init.normal_(self.pos, std=0.02)
        layer = nn.TransformerEncoderLayer(d, n_head, dim_feedforward=4 * d,
                                           dropout=0.0, batch_first=True,
                                           activation='gelu', norm_first=True)
        self.blocks = nn.TransformerEncoder(layer, n_layer, enable_nested_tensor=False)
        self.ln = nn.LayerNorm(d)
        self.head = nn.Linear(d, vocab, bias=False)

    def forward(self, x, return_layers=False):
        h = self.tok(x) + self.pos[:x.shape[1]]
        hs = []
        for blk in self.blocks.layers:
            h = blk(h)
            hs.append(h)
        out = self.head(self.ln(h))
        if return_layers:
            return out, hs
        return out


def linear_cka(A, B):
    A = A - A.mean(0, keepdims=True)
    B = B - B.mean(0, keepdims=True)
    num = float(((A.T @ B) ** 2).sum())
    den = float(np.linalg.norm(A.T @ A) * np.linalg.norm(B.T @ B))
    return num / den if den > 0 else 0.0


def cka_matrix(hs, max_tokens=1024):
    """Cross-layer CKA on position-averaged hidden states."""
    Zs = []
    for h in hs:
        Z = h.reshape(-1, h.shape[-1]).detach().numpy()
        if len(Z) > max_tokens:
            Z = Z[np.random.default_rng(0).choice(len(Z), max_tokens, replace=False)]
        Zs.append(Z)
    L = len(Zs)
    C = np.eye(L)
    for i in range(L):
        for j in range(i + 1, L):
            C[i, j] = C[j, i] = linear_cka(Zs[i], Zs[j])
    return C


def integration_index(C):
    """Lambda = mean CKA of adjacent layer pairs - mean CKA of distant pairs."""
    L = C.shape[0]
    if L < 3:
        return float('nan')
    adj = np.mean([C[i, i + 1] for i in range(L - 1)])
    dist = np.mean([C[i, j] for i in range(L) for j in range(i + 2, L)])
    return float(adj - dist)


def spectral_gap(X, k=10):
    Z = np.asarray(X, float)
    k = max(1, min(k, len(Z) - 2)) if len(Z) > 3 else 1
    Z = (Z - Z.mean(0, keepdims=True)) / (Z.std(0, keepdims=True) + 1e-9)
    Z = Z / (np.linalg.norm(Z, axis=1, keepdims=True) + 1e-12)
    S = np.clip(Z @ Z.T, 0, 1); np.fill_diagonal(S, 0)
    W = np.zeros_like(S)
    idx = np.argpartition(-S, k, axis=1)[:, :k]
    for i, js in enumerate(idx):
        W[i, js] = S[i, js]
        W[js, i] = np.maximum(W[js, i], S[i, js])
    deg = W.sum(1) + 1e-12
    Lm = np.eye(len(W)) - (1 / np.sqrt(deg))[:, None] * W * (1 / np.sqrt(deg))[None, :]
    ev = np.sort(np.linalg.eigvalsh(Lm))
    return float(ev[1] - ev[0])


def participation_ratio(X):
    Z = np.asarray(X, float)
    Z = Z - Z.mean(0, keepdims=True)
    s = np.linalg.svd(Z, compute_uv=False)
    return float((s.sum() ** 2) / (s ** 2).sum())


def probe(model, seed=0):
    """Metrics on a fixed probe set, per task."""
    rng = np.random.default_rng(1000 + seed)
    x, y = make_batch(rng, 96)
    model.eval()
    with torch.no_grad():
        logits, hs = model(x, return_layers=True)
    pred = logits.argmax(-1)
    mask = y != -100
    acc = float((pred[mask] == y[mask]).float().mean().item())
    per_task = {}
    for t in range(NTASK):
        m = (x[:, 0] == t)[:, None] & mask
        per_task[str(t)] = float((pred[m] == y[m]).float().mean().item())
    C = cka_matrix(hs)
    layer_sg, layer_pr = [], []
    for h in hs:
        Z = h[:, -1, :].detach().numpy()          # last-token states
        layer_sg.append(spectral_gap(Z))
        layer_pr.append(participation_ratio(Z))
    last = hs[-1][:, -1, :].detach().numpy()
    model.train()
    return dict(acc=acc, per_task=per_task, loss=float(F.cross_entropy(
        logits[mask], y[mask]).item()), cka=C.tolist(),
        lam=integration_index(C), layer_sg=layer_sg, layer_pr=layer_pr,
        sg=layer_sg[-1], pr=layer_pr[-1], final_pr=participation_ratio(last))


def train(n_layer=4, d=64, steps=2500, seed=0, lr=3e-3, probe_every=250,
          out='../results'):
    model = TinyLM(d=d, n_layer=n_layer, seed=seed)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.05)
    rng = np.random.default_rng(seed)
    traj = []
    t0 = time.time()
    for step in range(steps + 1):
        if step % probe_every == 0 or step == steps:
            m = probe(model, seed)
            m.update(step=step, wall=time.time() - t0)
            traj.append(m)
            json.dump(dict(seed=seed, n_layer=n_layer, d=d, traj=traj),
                      open(f'{out}/L2_L{n_layer}_s{seed}.json', 'w'))
            print(f'L{n_layer} s{seed} st {step} acc {m["acc"]:.3f} '
                  f'lam {m["lam"]:.3f} sg {m["sg"]:.3f} pr {m["pr"]:.1f}', flush=True)
        if step == steps:
            break
        x, y = make_batch(rng, 24)
        logits = model(x)
        loss = F.cross_entropy(logits.reshape(-1, VOCAB), y.reshape(-1),
                               ignore_index=-100)
        opt.zero_grad(); loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
    torch.save(model.state_dict(), f'{out}/L2_L{n_layer}_s{seed}.pt')
    return traj


if __name__ == '__main__':
    import sys
    n_layer = int(sys.argv[1]); seed = int(sys.argv[2])
    steps = int(sys.argv[3]) if len(sys.argv) > 3 else 4000
    train(n_layer=n_layer, seed=seed, steps=steps)
