"""Consolidated statistical analysis of E1-E11 -> analysis_summary.json."""
import json, glob, os
import numpy as np
from scipy import stats as st

OUT = '../results'
S = {}

# ---------- E1: jump locking + final-state correlations
def jump(vals, steps, base_frac=0.1, plateau_frac=0.9):
    v = np.array(vals, float); s = np.array(steps)
    base = np.mean(v[:max(3, int(len(v) * 0.1))])
    plat = np.mean(v[-max(3, int(len(v) * 0.1)):])
    thr = base + 0.5 * (plat - base)
    idx = np.argmax(v >= thr) if (v >= thr).any() else None
    return int(s[idx]) if idx is not None else None, base, plat

e1 = []
for f in sorted(glob.glob(f'{OUT}/E1_seed*.json')):
    d = json.load(open(f))
    tr = d['traj']
    steps = [t['step'] for t in tr]
    val = [t['val_acc'] for t in tr]
    r = [t['r_logit'] for t in tr]
    psi = [t['psi'] for t in tr]
    idv = [t['id'] for t in tr]
    sg = [t['sg'] for t in tr]
    tau_val, _, _ = jump(val, steps)
    tau_r, _, _ = jump(r, steps)
    tau_psi, _, _ = jump(psi, steps)   # collapse direction still midpoint crossing
    tau_id, _, _ = jump(idv, steps)
    tau_sg, _, _ = jump(sg, steps)
    e1.append(dict(seed=d['seed'], final_val=val[-1], final_r=r[-1],
                   final_psi=psi[-1], final_id=idv[-1], final_sg=sg[-1],
                   tau_val=tau_val, tau_r=tau_r, tau_psi=tau_psi,
                   tau_id=tau_id, tau_sg=tau_sg,
                   lock_r_val=(tau_r - tau_val), lock_psi_val=(tau_psi - tau_val),
                   psi_drop_ratio=psi[0] / max(psi[-1], 1e-9),
                   sg_drop_ratio=sg[2] / max(sg[-1], 1e-9),
                   id_drop_ratio=idv[2] / max(idv[-1], 1e-9)))
S['E1'] = e1
fv = [e['final_val'] for e in e1]; fr = [e['final_r'] for e in e1]
fp = [e['final_psi'] for e in e1]; fid = [e['final_id'] for e in e1]
S['E1_stats'] = dict(
    n=len(e1),
    spearman_r_val=float(st.spearmanr(fv, fr).statistic),
    spearman_psi_val=float(st.spearmanr(fp, fv).statistic),
    spearman_id_val=float(st.spearmanr(fid, fv).statistic),
    median_lock_r_val=float(np.median([abs(e['lock_r_val']) for e in e1 if e['lock_r_val'] is not None])),
    median_lock_psi_val=float(np.median([abs(e['lock_psi_val']) for e in e1 if e['lock_psi_val'] is not None])),
    median_psi_drop=float(np.median([e['psi_drop_ratio'] for e in e1])),
    median_sg_drop=float(np.median([e['sg_drop_ratio'] for e in e1])),
    median_id_drop=float(np.median([e['id_drop_ratio'] for e in e1])),
    mean_final_val=float(np.mean(fv)))

# ---------- E2: Arrhenius vs power law
rows = []
for f in sorted(glob.glob(f'{OUT}/E2_lr*_seed*.json')):
    rows.append(json.load(open(f)))
lrs = sorted(set(r['lr'] for r in rows))
arr = []
for lr in lrs:
    ts = [r['tau'] for r in rows if r['lr'] == lr and r['tau']]
    arr.append(dict(lr=lr, tau_mean=float(np.mean(ts)), tau_sd=float(np.std(ts)),
                    n=len(ts)))
x = np.log(1 / np.array([a['lr'] for a in arr]))
y = np.log([a['tau_mean'] for a in arr])
sl_a, ic_a, r_a, p_a, se_a = st.linregress(x, y)
xl = np.log([a['lr'] for a in arr])
sl_p, ic_p, r_p, p_p, se_p = st.linregress(xl, y)
S['E2'] = dict(per_lr=arr,
               arrhenius=dict(slope=float(sl_a), intercept=float(ic_a),
                              R2=float(r_a ** 2), p=float(p_a)),
               powerlaw=dict(exponent=float(sl_p), R2=float(r_p ** 2), p=float(p_p)),
               verdict='partial' if r_a ** 2 < 0.85 else 'support')

# ---------- E3
e3 = []
for f in sorted(glob.glob(f'{OUT}/E3_seed*.json')):
    d = json.load(open(f))
    rec = d['perturb']
    inv = d['inversion'] if isinstance(d['inversion'], list) else []
    e3.append(dict(seed=d['seed'],
                   eps=[r['eps'] for r in rec],
                   val_pert=[r['val_pert'] for r in rec],
                   val_rec=[r['val_rec'] for r in rec],
                   r_rec=[r['r_rec'] for r in rec],
                   inv_traj=inv))
S['E3'] = e3
# aggregated recovery at moderate eps
rec50 = np.mean([d['val_rec'][d['eps'].index(0.05)] for d in e3])
rec20 = np.mean([d['val_rec'][d['eps'].index(0.2)] for d in e3])
S['E3_stats'] = dict(mean_rec_val_eps05=float(rec50), mean_rec_val_eps20=float(rec20),
                     n_seeds=len(e3))

# ---------- E4
e4 = []
for f in sorted(glob.glob(f'{OUT}/E4_seed*.json')):
    e4.append(json.load(open(f)))
eps_list = [0.25, 0.5, 1.0, 2.0, 4.0, 8.0]
S['E4'] = dict(seeds=len(e4),
               persist_mean=[float(np.mean([ed['edits'][i]['persist'] for ed in e4])) for i in range(len(eps_list))],
               rebound_mean=[float(np.mean([ed['edits'][i]['rebound'] for ed in e4])) for i in range(len(eps_list))],
               val_mean=[float(np.mean([ed['edits'][i]['mean_val'] for ed in e4])) for i in range(len(eps_list))],
               eps=eps_list)

# ---------- E5
e5 = []
for f in sorted(glob.glob(f'{OUT}/E5_seed*.json')):
    d = json.load(open(f))
    if 'truncated' in d['budgets'] and 'full' in d['budgets']:
        e5.append(dict(seed=d['seed'],
                       trunc=d['budgets']['truncated']['transfer_steps'],
                       full=d['budgets']['full']['transfer_steps'],
                       val_trunc=d['budgets']['truncated']['val_after_budget'],
                       val_full=d['budgets']['full']['val_after_budget']))
tr = [e['trunc'] for e in e5]; fu = [e['full'] for e in e5]
w = st.wilcoxon(tr, fu) if len(e5) >= 5 else None
S['E5'] = dict(seeds=e5,
               mean_trunc=float(np.mean(tr)), mean_full=float(np.mean(fu)),
               median_trunc=float(np.median(tr)), median_full=float(np.median(fu)),
               n=len(e5), frac_full_faster=float(np.mean([f < t for t, f in zip(tr, fu)])),
               wilcoxon_p=float(w.pvalue) if w else None)

# ---------- E6
S['E6'] = json.load(open(f'{OUT}/E6_density_audit.json'))

# ---------- E7
e7 = json.load(open(f'{OUT}/E7_loop_births.json'))
# add lognormal fit
born = np.array([b['birth'] for b in e7['births'] if b['birth'] and b['birth'] > 0], float)
ln = np.log(born)
mu, sd = ln.mean(), ln.std()
ks_ln = st.kstest((ln - mu) / sd, 'norm')
e7['lognormal'] = dict(mu=float(mu), sigma=float(sd), ks=float(ks_ln.statistic), p=float(ks_ln.pvalue))
S['E7'] = e7

# ---------- E8
S['E8'] = json.load(open(f'{OUT}/E8_static_check.json'))

# ---------- E9
S['E9'] = json.load(open(f'{OUT}/E9_surrogate_calibration.json'))['calibration']

# ---------- E10
S['E10'] = json.load(open(f'{OUT}/E10_summary.json'))

# ---------- E11
e11 = []
for f in sorted(glob.glob(f'{OUT}/E11_ssm_seed*.json')):
    d = json.load(open(f))
    tr = d['traj']
    e11.append(dict(seed=d['seed'], tau=d['tau'], final_val=tr[-1]['val'],
                    final_r=tr[-1]['r'], max_r=max(t['r'] for t in tr)))
S['E11'] = e11

json.dump(S, open(f'{OUT}/analysis_summary.json', 'w'), indent=1)
print(json.dumps({k: S[k] for k in ['E1_stats', 'E2', 'E3_stats', 'E5'] if k in S},
                 indent=1, default=str)[:3000])
print('E4:', json.dumps(S['E4']))
print('E11:', json.dumps(S['E11']))
