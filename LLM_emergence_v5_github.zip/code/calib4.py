import json, time, numpy as np, torch, torch.nn.functional as F
from grok_core import make_data
from mlp_core import MLPModel, cloud_prep, h1_diagram

p, lr, wd, steps, seed = 29, 1e-3, 2.0, 60000, 0
m = MLPModel(p=p, seed=seed)
Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
cls = Yva.numpy()
opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=wd)

def fourier_metrics(H):
    X = H.numpy()
    means = np.stack([X[cls == s].mean(0) if (cls == s).any() else np.zeros(X.shape[1])
                      for s in range(p)])
    M = means - means.mean(0, keepdims=True)
    T = []
    for k in range(p):
        e = np.exp(-2j * np.pi * k * np.arange(p) / p)
        F_k = (M * e[:, None]).mean(0)
        T.append(float((np.abs(F_k) ** 2).sum()))
    T = np.array(T)
    var_total = T.sum() + 1e-12
    Tn = T.copy(); Tn[0] = 0
    kstar = int(np.argmax(Tn))
    r_spec = float(np.sqrt(Tn[kstar] / var_total))
    # reconstruct in dominant-mode 2-plane and compute PH of the ring
    e = np.exp(-2j * np.pi * kstar * np.arange(p) / p)
    F_k = (M * e[:, None]).mean(0)          # complex vector
    u, v = F_k.real, F_k.imag
    pc = M @ u.T if False else np.stack([M @ u, M @ v], axis=1)  # (p,2) ellipse coords
    rad = np.linalg.norm(pc, axis=1)
    rad = rad / (rad.mean() + 1e-12)
    dgm = h1_diagram(pc / (np.linalg.norm(pc, axis=1, keepdims=True) + 1e-12) if True else pc)
    psi_ring = float((dgm[:, 1] - dgm[:, 0]).sum()) if len(dgm) else 0.0
    # readout-column spectrum (circuit level)
    W = m.fc2.weight.detach().numpy()        # (p, dh)
    Wc = W - W.mean(0, keepdims=True)
    Tr = []
    for k in range(p):
        e = np.exp(-2j * np.pi * k * np.arange(p) / p)
        Fk = (Wc * e[:, None]).mean(0)
        Tr.append(float((np.abs(Fk) ** 2).sum()))
    Tr = np.array(Tr); vr = Tr.sum() + 1e-12; Tr[0] = 0
    r_read = float(np.sqrt(Tr.max() / vr))
    # ellipticity of the ring (radial dispersion)
    ell = float(rad.std())
    return r_spec, kstar, psi_ring, ell, r_read

traj = []
t0 = time.time()
for step in range(steps + 1):
    if step % 2000 == 0 or step == steps:
        with torch.no_grad():
            lv, H = m(Xva); v = (lv.argmax(-1) == Yva).float().mean().item()
        r_spec, kstar, psi_ring, ell, r_read = fourier_metrics(H)
        traj.append(dict(step=step, val=v, r_spec=r_spec, kstar=kstar,
                         psi_ring=psi_ring, ell=ell, r_read=r_read))
        print(f"st {step} val {v:.2f} r_spec {r_spec:.3f} k* {kstar} psi_ring {psi_ring:.3f} ell {ell:.3f} r_read {r_read:.3f}", flush=True)
    if step == steps:
        break
    opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
print('wall', round(time.time() - t0, 1))
json.dump(traj, open('calib_mlp3_seed0.json', 'w'))
