"""E8 inference-time static check (attention transformer);
E10 rewiring-budget theta scan; E11 minimal SSM cross-architecture pre-study."""
import json, os, sys, time, gc
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from grok_core import make_data, AttnOnlyModel
from mlp_core import MLPModel, cloud_prep, h1_diagram

torch.set_num_threads(1)
p = 29
OUT = '../results'

def psi_cloud(Z):
    dgm = h1_diagram(Z)
    return float((dgm[:, 1] - dgm[:, 0]).sum()) if len(dgm) else 0.0, dgm

def wass(dgmA, dgmB):
    from persim import wasserstein
    A = np.array(dgmA) if len(dgmA) else np.zeros((0, 2))
    B = np.array(dgmB) if len(dgmB) else np.zeros((0, 2))
    if len(A) == 0 and len(B) == 0:
        return 0.0
    if len(A) == 0 or len(B) == 0:
        return float('inf')
    return float(wasserstein(A, B, matching=False))


def E8():
    """Train attention transformer; static check at inference time."""
    ckpt = f'{OUT}/E8_attn_weights.pt'
    m = AttnOnlyModel(p=p, seed=0)
    if os.path.exists(ckpt):
        m.load_state_dict(torch.load(ckpt))
    else:
        Xtr, Ytr, Xva, Yva = make_data(p, 0.5, 0)
        opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=1.0)
        for step in range(20001):
            if step == 20000:
                break
            opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
        torch.save(m.state_dict(), ckpt)
    Xtr, Ytr, Xva, Yva = make_data(p, 0.5, 0)
    allX = torch.cat([Xtr, Xva])
    rng = np.random.default_rng(0)
    perm = rng.permutation(len(allX))
    batches = [allX[torch.tensor(perm[i * 200:(i + 1) * 200])] for i in range(5)]
    m.eval()
    def barcodes(Xb):
        with torch.no_grad():
            _, H = m(Xb)
        Z = cloud_prep(H[:, -1, :], max_points=200, seed=0)
        _, dgm = psi_cloud(Z)
        return dgm
    B = [barcodes(b) for b in batches]
    # repeat determinism
    B_rep = barcodes(batches[0])
    res = dict(repeat_w=[wass(B[0], B_rep) for _ in range(1)],
               cross_prompt_w=[wass(B[i], B[j]) for i in range(5) for j in range(i + 1, 5)])
    # cross-task: (a-b) prompts
    Xinv = allX[torch.tensor(perm[1000:1200])].clone()
    Xinv2 = Xinv.clone(); Xinv2[:, 1] = (p - Xinv2[:, 1]) % p
    res['cross_task_w'] = [wass(B[0], barcodes(Xinv2))]
    # training contrast: barcodes across training checkpoints
    traj_ck = []
    m2 = AttnOnlyModel(p=p, seed=0)
    m2.load_state_dict(torch.load(ckpt))  # final
    # train a fresh model capturing checkpoints
    m3 = AttnOnlyModel(p=p, seed=0)
    Xtr2, Ytr2, _, _ = make_data(p, 0.5, 0)
    opt = torch.optim.AdamW(m3.parameters(), lr=1e-3, weight_decay=1.0)
    ck_steps = {0: None, 5000: None, 10000: None, 15000: None, 20000: None}
    for step in range(20001):
        if step in ck_steps:
            m3.eval()
            with torch.no_grad():
                _, H = m3(batches[0])
            Z = cloud_prep(H[:, -1, :], max_points=200, seed=0)
            _, dgm = psi_cloud(Z)
            ck_steps[step] = dgm
            m3.train()
        if step == 20000:
            break
        opt.zero_grad(); lg, _ = m3(Xtr2); F.cross_entropy(lg, Ytr2).backward(); opt.step()
    ks = sorted(ck_steps)
    res['cross_time_w'] = [wass(ck_steps[ks[i]], ck_steps[ks[j]])
                           for i in range(len(ks)) for j in range(i + 1, len(ks))]
    # scale reference: median persistence of final barcode
    pers = [d - b for b, d in np.array(ck_steps[20000]).tolist()] if len(ck_steps[20000]) else [1.0]
    res['scale_ref_median_persistence'] = float(np.median(pers)) if len(pers) else 1.0
    json.dump(res, open(f'{OUT}/E8_static_check.json', 'w'))
    print('E8:', json.dumps(res))

def E10():
    """Rewiring-budget theta: fraction of hidden units re-randomized every
    100 steps (turnover). Measure tau, final val, reversibility, quality."""
    import torch.nn.init as init
    results = []
    for theta in [0.0, 0.05, 0.1, 0.2, 0.3, 0.4]:
        for seed in [0, 1]:
            f = f'{OUT}/E10_theta{theta}_seed{seed}.json'
            if os.path.exists(f):
                continue
            m = MLPModel(p=p, seed=seed)
            Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
            opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=2.0)
            n_rw = int(round(theta * m.dh))
            tau = None; v_final = 0.0
            for step in range(40001):
                if step % 200 == 0:
                    with torch.no_grad():
                        lv, _ = m(Xva); v = (lv.argmax(-1) == Yva).float().mean().item()
                        lt, _ = m(Xtr); tr = (lt.argmax(-1) == Ytr).float().mean().item()
                    if tau is None and tr >= 0.995 and v >= 0.5:
                        tau = step
                    if v >= 0.9:
                        v_final = v
                        break
                    if tau is not None and step - tau > 6000:
                        v_final = v
                        break
                if step == 40000:
                    with torch.no_grad():
                        lv, _ = m(Xva); v_final = (lv.argmax(-1) == Yva).float().mean().item()
                    break
                if n_rw and step % 100 == 0 and step > 0:
                    with torch.no_grad():
                        cols = np.random.default_rng(step).choice(m.dh, n_rw, replace=False)
                        W = m.fc1.weight.data
                        W[:, cols] *= 0.9          # mild turnover (decay event)
                opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
            # reversibility: eps=0.1 perturbation on fc2 + 1500 recovery steps
            W0 = m.fc2.weight.detach().clone()
            torch.manual_seed(100 + seed)
            E = torch.randn_like(W0); E = E / E.norm() * (0.1 * W0.norm())
            with torch.no_grad():
                m.fc2.weight.copy_(W0 + E)
            opt = torch.optim.AdamW(m.parameters(), lr=1e-4, weight_decay=2.0)
            for _ in range(1500):
                opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
            with torch.no_grad():
                lv, _ = m(Xva); v_rec = (lv.argmax(-1) == Yva).float().mean().item()
            v0 = max(v_final, 1e-3)
            rev = min(1.0, v_rec / v0)
            quality = 0.6 * v_final + 0.4 * rev
            r = dict(theta=theta, seed=seed, tau=tau, val=v_final,
                     val_rec=v_rec, rev_ratio=rev, quality=quality)
            json.dump(r, open(f, 'w'))
            results.append(r)
            print('E10', r, flush=True)
            gc.collect()
    # summary
    import collections
    agg = collections.defaultdict(list)
    for f in glob.glob(f'{OUT}/E10_theta*.json'):
        d = json.load(open(f))
        agg[d['theta']].append(d)
    summary = {}
    for th, rs in sorted(agg.items()):
        summary[th] = dict(
            tau_mean=float(np.mean([r['tau'] for r in rs if r['tau']] or [80000])),
            val_mean=float(np.mean([r['val'] for r in rs])),
            rev_mean=float(np.mean([r['rev_ratio'] for r in rs])),
            quality_mean=float(np.mean([r['quality'] for r in rs])))
    json.dump(summary, open(f'{OUT}/E10_summary.json', 'w'))
    print('E10 summary:', json.dumps(summary))


class MiniSSM(nn.Module):
    """Two-step selective linear SSM: h1 = lam*h0+(1-lam)*tanh(W x1),
    h2 = lam*h1+(1-lam)*tanh(W x2); logits = C h2."""
    def __init__(self, p=29, d=128, dh=100, seed=0):
        super().__init__()
        torch.manual_seed(seed)
        self.ea = nn.Embedding(p, d); self.eb = nn.Embedding(p, d)
        self.W = nn.Linear(d, dh)
        self.lam = nn.Parameter(torch.zeros(dh))   # sigmoid -> 0.5
        self.V = nn.Linear(dh, dh)                 # composition head
        self.C = nn.Linear(dh, p)

    def forward(self, tokens):
        x1, x2 = self.ea(tokens[:, 0]), self.eb(tokens[:, 1])
        lam = torch.sigmoid(self.lam)
        h0 = torch.zeros(tokens.shape[0], self.W.out_features, device=x1.device)
        h1 = lam * h0 + (1 - lam) * torch.tanh(self.W(x1))
        h2 = lam * h1 + (1 - lam) * torch.tanh(self.W(x2))
        return self.C(F.relu(self.V(h2))), h2


def E11():
    for seed in [0, 1]:
        f = f'{OUT}/E11_ssm_seed{seed}.json'
        if os.path.exists(f):
            continue
        m = MiniSSM(p=p, seed=seed)
        Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
        S = ((Xva[:, 0] + Xva[:, 1]) % p).numpy().astype(float)
        opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=2.0)
        from run_E3E4E5 import cyc
        traj = []
        tau = None
        for step in range(60001):
            if step % 2000 == 0:
                with torch.no_grad():
                    lv, H = m(Xva); v = (lv.argmax(-1) == Yva).float().mean().item()
                    lt, _ = m(Xtr); tr = (lt.argmax(-1) == Ytr).float().mean().item()
                r = cyc(lv.numpy(), S)
                traj.append(dict(step=step, val=v, train=tr, r=r))
                if tau is None and tr >= 0.995 and v >= 0.5:
                    tau = step
                print(f'E11 seed {seed} st {step} val {v:.2f} r {r:.3f}', flush=True)
            if step == 60000:
                break
            opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
        json.dump(dict(seed=seed, tau=tau, traj=traj), open(f, 'w'))
        gc.collect()


if __name__ == '__main__':
    import glob
    dict(E8=E8, E10=E10, E11=E11)[sys.argv[1]]()
