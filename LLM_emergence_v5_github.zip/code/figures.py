"""Publication figures for the LLM-emergence V2 paper (PLOS CompBio style)."""
import json, glob
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# --- vector export: every PNG also written as PDF ---
import matplotlib.figure as _mf
_orig_savefig = _mf.Figure.savefig
def _savefig_both(self, fname, **kw):
    _orig_savefig(self, fname, **kw)
    s = str(fname)
    if s.endswith('.png'):
        _orig_savefig(self, s[:-4] + '.pdf', **kw)
_mf.Figure.savefig = _savefig_both


C = ['#0072B2', '#D55E00', '#009E73', '#CC79A7', '#E69F00', '#56B4E9', '#333333']
plt.rcParams.update({
    'font.size': 7.5, 'axes.titlesize': 8, 'axes.labelsize': 7.5,
    'axes.spines.top': False, 'axes.spines.right': False,
    'figure.dpi': 300, 'savefig.dpi': 300, 'legend.frameon': False,
    'xtick.labelsize': 7, 'ytick.labelsize': 7, 'lines.linewidth': 1.2,
})
S = json.load(open('../results/analysis_summary.json'))
F = '../figures'


def panel_label(ax, s):
    ax.text(-0.13, 1.06, s, transform=ax.transAxes, fontsize=10,
            fontweight='bold', va='top')


# ---------------- Fig 1: E1 trajectories (seed 0)
d0 = json.load(open('../results/E1_seed0.json'))['traj']
st_ = [t['step'] for t in d0]
fig, axes = plt.subplots(2, 2, figsize=(6.8, 4.6))
ax = axes[0, 0]
ax.plot(st_, [t['train_acc'] for t in d0], color=C[6], label='train acc')
ax.plot(st_, [t['val_acc'] for t in d0], color=C[0], label='val acc')
ax.set_xscale('log'); ax.set_xlabel('training step'); ax.set_ylabel('accuracy')
ax.legend(loc='lower right'); ax.set_title('Grokking trajectory (seed 0)')
panel_label(ax, 'a')
ax = axes[0, 1]
ax.plot(st_, [t['r_logit'] for t in d0], color=C[1])
ax.set_xscale('log'); ax.set_xlabel('training step')
ax.set_ylabel(r'cycle alignment $r$')
ax.set_title('Circuit lock-in order parameter')
panel_label(ax, 'b')
ax = axes[1, 0]
ax.plot(st_, [t['psi'] for t in d0], color=C[2], label=r'$\Psi_1$ (H1 persistence)')
ax2 = ax.twinx(); ax2.spines.top.set_visible(False)
ax2.plot(st_, [t['n_feat'] for t in d0], color=C[3], alpha=0.7)
ax2.set_ylabel('H1 feature count', color=C[3])
ax2.tick_params(axis='y', colors=C[3])
ax.set_xscale('log'); ax.set_xlabel('training step'); ax.set_ylabel(r'$\Psi_1$')
ax.set_title(r'Topological collapse of $\Psi_1$')
panel_label(ax, 'c')
ax = axes[1, 1]
ax.plot(st_, [t['id'] for t in d0], color=C[4], label='intrinsic dim (TwoNN)')
ax2 = ax.twinx(); ax2.spines.top.set_visible(False)
ax2.plot(st_, [t['sg'] for t in d0], color=C[5])
ax2.set_ylabel('spectral gap', color=C[5]); ax2.tick_params(axis='y', colors=C[5])
ax.set_xscale('log'); ax.set_xlabel('training step'); ax.set_ylabel('intrinsic dimension')
ax.set_title('Geometric order parameters')
panel_label(ax, 'd')
fig.tight_layout()
fig.savefig(f'{F}/fig1_E1_trajectories.png', bbox_inches='tight')
plt.close(fig)

# ---------------- Fig 2: across-seed final states
e1 = S['E1']
fig, axes = plt.subplots(1, 3, figsize=(6.8, 2.3))
ax = axes[0]
fv = [e['final_val'] for e in e1]; fp = [e['final_psi'] for e in e1]
ax.scatter(fv, fp, color=C[0], s=18)
rho = S['E1_stats']['spearman_psi_val']
ax.set_xlabel('final val accuracy'); ax.set_ylabel(r'final $\Psi_1$')
ax.set_title(rf'$\rho = {rho:.2f}$')
panel_label(ax, 'a')
ax = axes[1]
fi = [e['final_id'] for e in e1]
ax.scatter(fv, fi, color=C[4], s=18)
ax.set_xlabel('final val accuracy'); ax.set_ylabel('final intrinsic dim')
ax.set_title(rf"$\rho = {S['E1_stats']['spearman_id_val']:.2f}$")
panel_label(ax, 'b')
ax = axes[2]
fr = [e['final_r'] for e in e1]
ax.scatter(fv, fr, color=C[1], s=18)
ax.set_xlabel('final val accuracy'); ax.set_ylabel(r'final $r$')
ax.set_title(rf"$\rho = {S['E1_stats']['spearman_r_val']:.2f}$ (across seeds)")
panel_label(ax, 'c')
fig.tight_layout()
fig.savefig(f'{F}/fig2_E1_across_seeds.png', bbox_inches='tight')
plt.close(fig)

# ---------------- Fig 3: E2 Arrhenius
e2 = S['E2']
arr = e2['per_lr']
x = 1 / np.array([a['lr'] for a in arr])
y = np.array([a['tau_mean'] for a in arr])
sd = np.array([a['tau_sd'] for a in arr])
fig, axes = plt.subplots(1, 2, figsize=(6.8, 2.5))
ax = axes[0]
sl = e2['arrhenius']['slope']; ic = e2['arrhenius']['intercept']
ax.errorbar(x, np.log(y), yerr=sd / y, fmt='o', color=C[0], capsize=2, ms=4)
xs = np.linspace(x.min(), x.max(), 50)
ax.plot(xs, sl * xs + ic, '--', color=C[1],
        label=f"slope={sl:.2f}, $R^2$={e2['arrhenius']['R2']:.2f}")
ax.set_xlabel(r'$1/\eta$  (inverse learning rate)')
ax.set_ylabel(r'$\log \tau$  (grokking step)')
ax.legend(); ax.set_title('Arrhenius-style scaling of delay')
panel_label(ax, 'a')
ax = axes[1]
ax.errorbar([a['lr'] for a in arr], y, yerr=sd / y, fmt='s', color=C[2], capsize=2, ms=4)
ax.set_xscale('log')
ax.set_xlabel(r'learning rate $\eta$'); ax.set_ylabel(r'$\log \tau$')
ax.set_title(rf"power-law view ($\gamma={-e2['powerlaw']['exponent']:.2f}$)")
panel_label(ax, 'b')
fig.tight_layout()
fig.savefig(f'{F}/fig3_E2_arrhenius.png', bbox_inches='tight')
plt.close(fig)

# ---------------- Fig 4: E3 reversibility
fig, axes = plt.subplots(1, 2, figsize=(6.8, 2.6))
ax = axes[0]
eps3 = [0.02, 0.05, 0.1, 0.2, 0.4]
val_p = np.array([[d['val_pert'][i] for i in range(len(eps3))] for d in S['E3']])
val_r = np.array([[d['val_rec'][i] for i in range(len(eps3))] for d in S['E3']])
ax.errorbar(eps3, val_p.mean(0), yerr=val_p.std(0), fmt='o-', color=C[3],
            capsize=2, label='after perturbation')
ax.errorbar(eps3, val_r.mean(0), yerr=val_r.std(0), fmt='o-', color=C[2],
            capsize=2, label='after recovery window')
ax.set_xlabel(r'perturbation $\epsilon$ (rel. Frobenius on $W_\mathrm{out}$)')
ax.set_ylabel('val accuracy'); ax.legend()
ax.set_title('Perturbation and recovery (n=4 seeds)')
panel_label(ax, 'a')
ax = axes[1]
inv = S['E3'][0]['inv_traj']
ax.plot([t['step'] for t in inv], [t['val_inv'] for t in inv], color=C[1],
        label='new task $(a-b)$ val')
ax.plot([t['step'] for t in inv], [t['val_old'] for t in inv], color=C[0],
        label='old task $(a+b)$ val')
ax2 = ax.twinx(); ax2.spines.top.set_visible(False)
ax2.plot([t['step'] for t in inv], [t['r_inv'] for t in inv], '--', color=C[1], alpha=0.6)
ax2.plot([t['step'] for t in inv], [t['r_old'] for t in inv], '--', color=C[0], alpha=0.6)
ax2.set_ylabel(r'$r$ (dashed)', alpha=0.7)
ax.set_xlabel('inversion training step'); ax.set_ylabel('val accuracy')
ax.legend(loc='center right')
ax.set_title('Task inversion (seed 0): hysteresis')
panel_label(ax, 'b')
fig.tight_layout()
fig.savefig(f'{F}/fig4_E3_reversibility.png', bbox_inches='tight')
plt.close(fig)

# ---------------- Fig 5: E4 edit threshold
eps4 = S['E4']['eps']
fig, ax = plt.subplots(figsize=(3.4, 2.6))
ax.plot(eps4, S['E4']['persist_mean'], 'o-', color=C[0], label='edit persistence')
ax.plot(eps4, S['E4']['rebound_mean'], 's-', color=C[1], label='rebound (recovery)')
ax.axvspan(0.5, 2.0, color=C[4], alpha=0.15)
ax.text(1.0, 0.5, 'threshold\nwindow', ha='center', fontsize=7, color=C[4])
ax.set_xscale('log')
ax.set_xlabel(r'edit strength $\varepsilon$ (logit units)')
ax.set_ylabel('fraction of edits')
ax.legend(loc='center left')
ax.set_title('Rebound-collapse threshold (n=4 seeds)')
panel_label(ax, '')
fig.tight_layout()
fig.savefig(f'{F}/fig5_E4_edit_threshold.png', bbox_inches='tight')
plt.close(fig)

# ---------------- Fig 6: E5 transfer plasticity
fig, ax = plt.subplots(figsize=(3.4, 2.6))
seeds = [e['seed'] for e in S['E5']['seeds']]
tr = [e['trunc'] for e in S['E5']['seeds']]
fu = [e['full'] for e in S['E5']['seeds']]
xs = np.arange(len(seeds))
ax.bar(xs - 0.18, tr, 0.36, color=C[0], label='truncated budget (0.3$\\tau$)')
ax.bar(xs + 0.18, fu, 0.36, color=C[1], label='full budget (3$\\tau$)')
ax.set_xticks(xs); ax.set_xticklabels([f's{s}' for s in seeds])
ax.set_ylabel('steps to 0.5 val on new task')
ax.set_title('Transfer plasticity: P-E1 not supported')
ax.legend(fontsize=6.5)
ax.text(0.02, 0.95, f"Wilcoxon p = {S['E5']['wilcoxon_p']:.2f}",
        transform=ax.transAxes, va='top', fontsize=6.5)
panel_label(ax, '')
fig.tight_layout()
fig.savefig(f'{F}/fig6_E5_transfer.png', bbox_inches='tight')
plt.close(fig)

# ---------------- Fig 7: E6 density audit
e6 = S['E6']
fig, axes = plt.subplots(1, 2, figsize=(6.8, 2.6))
ax = axes[0]
alphas = [d['alpha'] for d in e6['synthetic']]
bn = [d['b_naive'] for d in e6['per_alpha']]
bc = [d['b_cond'] for d in e6['per_alpha']]
xs = np.arange(len(alphas))
ax.bar(xs - 0.18, bn, 0.36, color=C[3], label='naive (no density control)')
ax.bar(xs + 0.18, bc, 0.36, color=C[2], label='density-conditioned')
ax.axhline(1.0, color=C[6], ls=':', lw=1)
ax.set_xticks(xs); ax.set_xticklabels([f'$\\alpha$={a}' for a in alphas])
ax.set_ylabel(r'fitted exponent $b$ in $\log\beta_1 \sim b\log n$')
ax.set_title('Spurious scaling exponents and the audit')
ax.legend(fontsize=6.5, loc='upper left')
panel_label(ax, 'a')
ax = axes[1]
names = [r['name'] for r in e6['real']]
b1 = [r['beta1'] for r in e6['real']]
idn = [r['n'] for r in e6['real']]
kb = [r['kbar'] for r in e6['real']]
pred = [(k / 2 - 1) * n + 1 for n, k in zip(idn, kb)]
xs = np.arange(len(names))
ax.bar(xs - 0.18, b1, 0.36, color=C[0], label=r'$\beta_1$ (exact)')
ax.bar(xs + 0.18, pred, 0.36, color=C[5], alpha=0.8,
       label=r'$n(\bar k/2-1)+c$')
ax.set_xticks(xs)
ax.set_xticklabels([n.replace('_', '\n') for n in names], fontsize=6)
ax.set_ylabel('cycle rank')
ax.set_title('Real open networks: identity check')
ax.legend(fontsize=6.5)
panel_label(ax, 'b')
fig.tight_layout()
fig.savefig(f'{F}/fig7_E6_density_audit.png', bbox_inches='tight')
plt.close(fig)

# ---------------- Fig 8: E7 birth times
e7 = S['E7']
born = np.array([b['birth'] for b in e7['births'] if b['birth'] and b['birth'] > 0], float)
fig, ax = plt.subplots(figsize=(3.4, 2.6))
ax.hist(born / 1000, bins=24, color=C[0], alpha=0.75, density=True)
ln = e7['lognormal']
xs = np.linspace(born.min() / 1000, born.max() / 1000, 200)
from scipy import stats as st_
pdf = st_.lognorm.pdf(xs * 1000, ln['sigma'], scale=np.exp(ln['mu']))
ax.plot(xs, pdf, color=C[1], lw=1.5,
        label=f"lognormal fit (KS p={ln['p']:.2f})")
ax.set_xlabel('loop birth time (ksteps)')
ax.set_ylabel('density')
ax.set_title(f"Circuit birth times (CV={e7['cv']:.2f})")
ax.legend(fontsize=6.5)
panel_label(ax, '')
fig.tight_layout()
fig.savefig(f'{F}/fig8_E7_birth_times.png', bbox_inches='tight')
plt.close(fig)

# ---------------- Fig 9: E8 static check
e8 = S['E8']
fig, ax = plt.subplots(figsize=(3.4, 2.6))
cp = e8['cross_prompt_w']
ct = e8['cross_time_w']
ax.scatter(np.random.default_rng(0).normal(0, 0.05, len(cp)), cp, color=C[0],
           s=14, label='cross-prompt (composition null)')
ax.scatter(np.ones(len(ct)) + np.random.default_rng(1).normal(0, 0.05, len(ct)),
           ct, color=C[1], s=14, label='same prompts across training')
ax.scatter([2], [0.0], marker='x', color=C[2], s=30, label='repeat (determinism)')
ax.set_xticks([0, 1, 2])
ax.set_xticklabels(['cross-prompt', 'cross-time', 'repeat'])
ax.set_ylabel(r'$W_1$ barcode distance')
ax.set_title('Inference-time static check')
ax.legend(fontsize=6)
panel_label(ax, '')
fig.tight_layout()
fig.savefig(f'{F}/fig9_E8_static.png', bbox_inches='tight')
plt.close(fig)

# ---------------- Fig 10: E9 surrogate calibration
e9 = S['E9']
fig, axes = plt.subplots(1, 3, figsize=(6.8, 2.4))
ax = axes[0]
keys = [r'$\Psi_1$ vs val', 'ID vs val', 'SG vs val', r'$r$ vs val', r'$r_h$ vs val',
        r'SG vs $\Psi_1$', r'ID vs $\Psi_1$']
vals = [e9['rho_psi_val'], e9['rho_id_val'], e9['rho_sg_val'], e9['rho_r_val'],
        e9['rho_rh_val'], e9['rho_psi_sg'], e9['rho_psi_id']]
cols = [C[3] if abs(v) >= 0.9 else (C[4] if abs(v) >= 0.7 else C[6]) for v in vals]
xs = np.arange(len(keys))
ax.bar(xs, vals, color=cols)
ax.axhline(0.9, color=C[0], ls=':', lw=1); ax.axhline(-0.9, color=C[0], ls=':', lw=1)
ax.axhline(0.7, color=C[6], ls=':', lw=0.8); ax.axhline(-0.7, color=C[6], ls=':', lw=0.8)
ax.set_xticks(xs); ax.set_xticklabels(keys, rotation=45, ha='right', fontsize=6)
ax.set_ylabel('Spearman ' + r'$\rho$')
ax.set_title('Surrogate calibration (n=248 probes)')
panel_label(ax, 'a')
ax = axes[1]
sc = e9['ph_scaling']
ax.plot([b['N'] for b in sc], [b['time_s'] for b in sc], 'o-', color=C[2])
ax.set_xlabel('cloud size N'); ax.set_ylabel('PH time (s)')
ax.set_title('Persistent-homology cost scaling')
panel_label(ax, 'b')
ax = axes[2]
ap = e9['approx_pipeline']['variants']
ax.plot([v['pca_dim'] for v in ap], [v['rel_diff'] for v in ap], 's-',
        color=C[1])
ax.set_xlabel('PCA dimensions retained')
ax.set_ylabel(r'rel. error of $\Psi_1$')
ax.set_title('Lossy pipeline bias')
panel_label(ax, 'c')
fig.tight_layout()
fig.savefig(f'{F}/fig10_E9_surrogates.png', bbox_inches='tight')
plt.close(fig)

# ---------------- Fig 11: E10 + E11
fig, axes = plt.subplots(1, 2, figsize=(6.8, 2.6))
ax = axes[0]
th = sorted(float(k) for k in S['E10'])
q = [S['E10'][str(t)]['quality_mean'] for t in th]
ax.plot(th, q, 'o-', color=C[0])
ax.axvline(0.2, color=C[3], ls='--', lw=1)
ax.text(0.2, ax.get_ylim()[0] + 0.005, r'$\theta^*=0.20$ (V1 claim)',
        ha='center', fontsize=6.5, color=C[3])
ax.set_xlabel(r'rewiring budget $\theta$')
ax.set_ylabel('quality $Q=0.6\,$val $+0.4\,$rev')
ax.set_title('Dynamic-static ratio: no interior optimum')
panel_label(ax, 'a')
ax = axes[1]
for f, col in zip(sorted(glob.glob('../results/E11_ssm_seed*.json')), [C[0], C[1]]):
    d = json.load(open(f))
    ax.plot([t['step'] for t in d['traj']], [t['r'] for t in d['traj']],
            color=col, label=f"SSM seed {d['seed']}")
ax.set_xscale('log')
ax.set_xlabel('training step'); ax.set_ylabel(r'cycle alignment $r$')
ax.set_title('Cross-architecture pre-study (SSM)')
ax.legend(fontsize=6.5)
panel_label(ax, 'b')
fig.tight_layout()
fig.savefig(f'{F}/fig11_E10_E11.png', bbox_inches='tight')
plt.close(fig)

print('figures done')
