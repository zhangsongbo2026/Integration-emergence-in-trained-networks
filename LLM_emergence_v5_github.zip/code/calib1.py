import json, time, numpy as np
from grok_core import train_run, jump_step

t0 = time.time()
tr = train_run(steps=20000, seed=0, probe_every=250)
print('wall', round(time.time() - t0, 1), 's')
st = np.array(tr['step']); va = np.array(tr['val_acc']); ta = np.array(tr['train_acc'])
psi = np.array(tr['psi1']); r = np.array(tr['r'])
print('final train/val:', ta[-1], va[-1])
print('val acc @ probes:', np.round(va, 2).tolist()[:40])
print('psi1:', np.round(psi, 1).tolist()[:40])
print('r:', np.round(r, 2).tolist()[:40])
jv = jump_step(va, st, 0.35, 0.85)
jp = jump_step(psi, st, np.percentile(psi[:8], 75) + 0.5 * (psi.max() - np.percentile(psi[:8], 75)), psi.max() * 0.6) if psi.max() > 0 else None
print('val jump step:', jv, 'psi jump step:', jp)
print('nloops trace:', tr['nloops'][:40])
json.dump({k: (v if k not in ('h1_diagrams', 'attn_graphs') else v) for k, v in tr.items()},
          open('calib_seed0.json', 'w'))
