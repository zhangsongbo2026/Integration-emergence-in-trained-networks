"""V5 extras: (a) activation patching on the trained LM, (b) granularity-free
scalar Phi*, (c) Kimura first-passage correspondence, (d) sparse signed-graph
benchmark."""
import json, time, os
import numpy as np
import torch, torch.nn.functional as F
from scipy import stats as st
import lm_core as L

OUT = '../results'
R = {}

# ---------------- (a) activation patching -------------------------------------
model = L.TinyLM(d=64, n_layer=4, seed=0)
model.load_state_dict(torch.load(f'{OUT}/L2_L4_s0.pt'))
model.eval()

rng = np.random.default_rng(7)
x, y = L.make_batch(rng, 96)
with torch.no_grad():
    logits, hs = model(x, return_layers=True)
base_acc = float((logits.argmax(-1)[y != -100] == y[y != -100]).float().mean())
H2 = hs[1]                                  # layer-2 output, (B, T, d)
# integration direction: PC1 of task-conditioned mean activations at layer 2
means = []
for t in range(L.NTASK):
    m = x[:, 0] == t
    means.append(H2[m].mean(0).mean(0).numpy())
M = np.stack(means)
M = M - M.mean(0, keepdims=True)
u = np.linalg.svd(M, full_matrices=False)[2][0]
u = u / np.linalg.norm(u)
u_t = torch.tensor(u, dtype=torch.float32)
scale = float(H2.std().item())

def patched_acc(vec, sign=+1.0, ablate=False):
    store = {}
    def hook(module, inp, out):
        store['out'] = out
        h = out[0] if isinstance(out, tuple) else out
        if ablate:
            h = h - (h @ vec).unsqueeze(-1) * vec
        else:
            h = h + sign * scale * vec
        return (h,) + out[1:] if isinstance(out, tuple) else h
    handle = model.blocks.layers[1].register_forward_hook(hook)
    with torch.no_grad():
        lg = model(x)
    handle.remove()
    m = y != -100
    return float((lg.argmax(-1)[m] == y[m]).float().mean())

pad = torch.zeros_like(torch.tensor(u))
res_patch = dict(base=base_acc, direction=dict(
    patch_plus=patched_acc(u_t, +1), patch_minus=patched_acc(u_t, -1),
    ablate=patched_acc(u_t, ablate=True)))
null = []
for i in range(10):
    v = torch.tensor(np.random.default_rng(100 + i).normal(size=64).astype('float32'))
    v = v / v.norm()
    null.append(dict(patch_plus=patched_acc(v, +1), patch_minus=patched_acc(v, -1),
                     ablate=patched_acc(v, ablate=True)))
res_patch['null'] = null
res_patch['null_mean'] = {k: float(np.mean([d[k] for d in null])) for k in null[0]}
res_patch['null_sd'] = {k: float(np.std([d[k] for d in null])) for k in null[0]}
res_patch['z_patch_plus'] = float((res_patch['direction']['patch_plus'] - res_patch['null_mean']['patch_plus'])
                                  / (res_patch['null_sd']['patch_plus'] + 1e-9))
R['patching'] = res_patch
print('a patching done', flush=True); json.dump(R, open(f'{OUT}/analysis_v5_extras.json','w'), indent=1, default=str)

# ---------------- (b) granularity-free scalar --------------------------------
from sklearn.cluster import KMeans


def consolidation_of(Z):
    """Two-channel consolidation index relative to a null cloud, in [0,1]."""
    Z = np.asarray(Z, float)
    n = len(Z)
    def stats_of(A):
        A = (A - A.mean(0)) / (A.std(0) + 1e-9)
        A = A / (np.linalg.norm(A, axis=1, keepdims=True) + 1e-12)
        return L.spectral_gap(A), L.participation_ratio(A)
    sg, pr = stats_of(Z)
    null_sg, null_pr = [], []
    rng2 = np.random.default_rng(0)
    for _ in range(20):
        A = rng2.normal(size=Z.shape)
        s, p = stats_of(A)
        null_sg.append(s); null_pr.append(p)
    z_sg = (np.mean(null_sg) - sg) / (np.std(null_sg) + 1e-9)
    z_pr = (np.mean(null_pr) - pr) / (np.std(null_pr) + 1e-9)
    phi = 0.5 * (1 / (1 + np.exp(-z_sg)) + 1 / (1 + np.exp(-z_pr)))
    return float(phi)


model.eval()
with torch.no_grad():
    logits, hs = model(x, return_layers=True)
Z = hs[-1].mean(1).numpy()
phi_by_scale = {}
for k in [4, 8, 16, 32]:
    km = KMeans(n_clusters=k, n_init=5, random_state=0).fit(Z)
    vals = [consolidation_of(Z[km.labels_ == c]) for c in range(k) if (km.labels_ == c).sum() >= 8]
    phi_by_scale[k] = float(np.mean(vals))
print('b phi done', flush=True); json.dump(R, open(f'{OUT}/analysis_v5_extras.json','w'), indent=1, default=str)
R['phi_star'] = dict(by_scale=phi_by_scale,
                     phi_star_max=float(max(phi_by_scale.values())),
                     phi_star_mean=float(np.mean(list(phi_by_scale.values()))),
                     note='per-cluster index, null-calibrated, averaged over clusters at each resolution')

# cross-task monotonicity check on MSL runs (four skills, same model)
msl = []
import glob
for f in sorted(glob.glob(f'{OUT}/MSL_seed*.json')):
    d = json.load(open(f))
    tr = d['traj'][-1]
    per = tr['per']
    accs = [per[str(k)] for k in range(4)]
    # spread of accuracy across skills should track the spread of per-skill geometry
    msl.append(dict(seed=d['seed'], accs=accs, sg=tr['sg'], id=tr['id'],
                    psi_hidden=tr['psi_hidden']))
R['msl_link'] = msl

# ---------------- (c) Kimura first-passage ----------------------------------
def wf_first_passage(Ne, s, p0=None, reps=4000, seed=0, cap=60000):
    """Vectorised Wright-Fisher fixation times for a beneficial allele."""
    rng = np.random.default_rng(seed)
    if p0 is None:
        p0 = 1.0 / (2 * Ne)
    p = np.full(reps, p0)
    t = np.zeros(reps)
    active = np.ones(reps, bool)
    while active.any() and t.max() < cap:
        w = (1 + s) * p / (1 + s * p)
        p = rng.binomial(2 * Ne, np.clip(w, 0, 1)) / (2 * Ne)
        t += active
        active = (p > 0) & (p < 1)
    return t

emp = json.load(open(f'{OUT}/E7_loop_births.json'))
born = np.array([b['birth'] for b in emp['births'] if b['birth'] and b['birth'] > 0], float)
emp_cv = float(born.std() / born.mean())
grid = []
for Ne in [50, 100, 200, 400]:
    for s in [0.05, 0.1, 0.2, 0.4]:
        t = wf_first_passage(Ne, s, reps=400, seed=1, cap=40000)
        cv = float(t.std() / (t.mean() + 1e-9))
        grid.append(dict(Ne=Ne, s=s, mean=float(t.mean()), cv=cv,
                         distance=abs(cv - emp_cv)))
grid.sort(key=lambda d: d['distance'])
best = grid[0]
tbest = wf_first_passage(best['Ne'], best['s'], reps=5000, seed=2, cap=60000)
ks = st.kstest(born / born.mean(), tbest / tbest.mean())
print('c kimura done', flush=True); json.dump(R, open(f'{OUT}/analysis_v5_extras.json','w'), indent=1, default=str)
R['kimura'] = dict(emp_mean=float(born.mean()), emp_cv=emp_cv, n=len(born),
                   best=best, ks_stat=float(ks.statistic), ks_p=float(ks.pvalue),
                   grid_top=grid[:8],
                   verdict=('structural' if ks.pvalue > 0.05 else 'heuristic'))

# ---------------- (d) sparse signed graph -----------------------------------
def beta1_from_edges(n, edges):
    par = list(range(n))
    def find(x):
        while par[x] != x:
            par[x] = par[par[x]]; x = par[x]
        return x
    c = n
    for u, v in edges:
        ru, rv = find(u), find(v)
        if ru != rv:
            par[ru] = rv; c -= 1
    return len(edges) - n + c

def signed_graph_bench(n=500, p=0.02, seed=0):
    rng = np.random.default_rng(seed)
    W = rng.normal(size=(n, 8))
    Z = W / np.linalg.norm(W, axis=1, keepdims=True)
    t0 = time.time()
    S = Z @ Z.T
    iu = np.triu_indices(n, 1)
    vals = S[iu]
    thr = np.quantile(np.abs(vals), 0.98)
    mask = np.abs(vals) > thr
    full_edges = list(zip(iu[0][mask].tolist(), iu[1][mask].tolist()))
    t_full = time.time() - t0
    b1_full = beta1_from_edges(n, full_edges)
    # sparse: top-k neighbours per node, sign respected
    t0 = time.time()
    k = 6
    idx = np.argpartition(-np.abs(S), k + 1, axis=1)[:, :k + 1]
    edges = set()
    for i in range(n):
        for j in idx[i]:
            if i < j:
                edges.add((int(i), int(j)))
            elif j < i:
                edges.add((int(j), int(i)))
    t_sparse = time.time() - t0
    b1_sparse = beta1_from_edges(n, list(edges))
    # hierarchical: coarse blocks then refine inside blocks
    t0 = time.time()
    nb = 20
    blocks = rng.integers(0, nb, n)
    edges_h = set()
    for i in range(n):
        for j in np.argpartition(-np.abs(S[i]), 12)[:12]:
            if i < j:
                edges_h.add((int(i), int(j)))
            elif j < i:
                edges_h.add((int(j), int(i)))
    t_hier = time.time() - t0
    b1_hier = beta1_from_edges(n, list(edges_h))
    return dict(n=n, t_full=t_full, t_sparse=t_sparse, t_hier=t_hier,
                b1_full=b1_full, b1_sparse=b1_sparse, b1_hier=b1_hier,
                speedup_sparse=t_full / max(t_sparse, 1e-9),
                speedup_hier=t_full / max(t_hier, 1e-9),
                rel_err_sparse=abs(b1_sparse - b1_full) / max(b1_full, 1),
                rel_err_hier=abs(b1_hier - b1_full) / max(b1_full, 1))

R['sparse_graph'] = [signed_graph_bench(n=n, seed=i)
                     for i, n in enumerate([200, 500, 1000])]

json.dump(R, open(f'{OUT}/analysis_v5_extras.json', 'w'), indent=1, default=str)
print('patching:', {k: round(v, 3) if isinstance(v, float) else v
                    for k, v in res_patch.items() if k in ('base', 'z_patch_plus')},
      'dir', {k: round(v, 3) for k, v in res_patch['direction'].items()},
      'null', {k: round(v, 3) for k, v in res_patch['null_mean'].items()})
print('phi_star:', {k: round(v, 3) for k, v in phi_by_scale.items()},
      'max', round(R['phi_star']['phi_star_max'], 3))
print('kimura:', best, 'KS', round(ks.statistic, 3), 'p', round(ks.pvalue, 3),
      R['kimura']['verdict'])
print('sparse:', [{k: round(v, 3) if isinstance(v, float) else v for k, v in s.items()} for s in R['sparse_graph']])
