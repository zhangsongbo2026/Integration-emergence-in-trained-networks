"""V3 consolidated analysis -> results/analysis_v3.json"""
import json, glob
import numpy as np
from scipy import stats as st

OUT = '../results'
R = {}

# ---------------------------------------------------------------- D2.1
def load(pat):
    out = []
    for f in sorted(glob.glob(f'{OUT}/{pat}')):
        try:
            out.append(json.load(open(f)))
        except Exception:
            print('skip corrupt:', f)
    return out

d21 = {a: load(f'D21b_{a}_seed*.json') for a in ['A0', 'A1', 'A2', 'A3']}
rng = np.random.default_rng(0)
def boot_ci(x, y, n=10000):
    d = np.array(x) - np.array(y)
    bs = [rng.choice(d, len(d), replace=True).mean() for _ in range(n)]
    return float(d.mean()), float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))
res = {}
for a, rs in d21.items():
    vals = [r['final_val'] for r in rs]
    taus = [r['tau'] for r in rs if r['tau']]
    fin = [r['traj'][-1] for r in rs]
    res[a] = dict(n=len(rs), val_mean=float(np.mean(vals)), val_sd=float(np.std(vals, ddof=1)),
                  val_list=vals, tau_median=float(np.median(taus)) if taus else None,
                  sg_final=float(np.mean([f['sg'] for f in fin])),
                  pr_final=float(np.mean([f['pr'] for f in fin])),
                  psi_final=float(np.mean([f['psi'] for f in fin])))
d1, lo1, hi1 = boot_ci(res['A1']['val_list'], res['A3']['val_list'])
d2, lo2, hi2 = boot_ci(res['A2']['val_list'], res['A3']['val_list'])
d0v, lo0, hi0 = boot_ci(res['A1']['val_list'], res['A0']['val_list'])
R['D21'] = dict(arms=res,
                A1_minus_A3=dict(delta=d1, ci=[lo1, hi1],
                                 verdict='support' if (d1 > 0.15 and lo1 > 0) else 'not supported'),
                A2_minus_A3=dict(delta=d2, ci=[lo2, hi2]),
                A1_minus_A0=dict(delta=d0v, ci=[lo0, hi0]))

# ---------------------------------------------------------------- D2.5 32-seed grid
e1 = load('E1_seed*.json')
xs = load('X_seed*.json')
finals = []
for d in e1:
    t = d['traj'][-1]
    finals.append(dict(seed=d['seed'], src='E1', val=t['val_acc'], psi=t['psi'],
                       sg=t['sg'], id=t['id'], r=t['r_logit'], n_feat=t['n_feat']))
for d in xs:
    t = d['traj'][-1]
    finals.append(dict(seed=d['seed'], src='X', val=t['val'], psi=t['psi'], sg=t['sg'],
                       id=t['id'], r=t['r_logit'], n_feat=None))
v = np.array([f['val'] for f in finals]); ps = np.array([f['psi'] for f in finals])
sgv = np.array([f['sg'] for f in finals]); idv = np.array([f['id'] for f in finals])
rv = np.array([f['r'] for f in finals])
# consolidation drop ratios for X runs (early vs final probe)
drops = []
for d in xs:
    t0, t1 = d['traj'][0], d['traj'][-1]
    drops.append(dict(seed=d['seed'], psi_drop=t0['psi'] / max(t1['psi'], 1e-9),
                      sg_drop=t0['sg'] / max(t1['sg'], 1e-9),
                      id_drop=t0['id'] / max(t1['id'], 1e-9)))
# hierarchical normal model on mean final val (grid HDI, weakly informative)
mu_grid = np.linspace(0.5, 1.0, 2001)
post = st.norm.pdf(mu_grid, v.mean(), v.std(ddof=1) / np.sqrt(len(v)))
post = post / post.sum()
cdf = np.cumsum(post)
hdi = (mu_grid[np.searchsorted(cdf, 0.025)], mu_grid[np.searchsorted(cdf, 0.975)])
# power analysis for detecting delta in final val (two-sample, n per arm)
sd_est = float(np.std(v, ddof=1))
def power_n(n, delta, sd, alpha=0.05, sims=4000, rng=np.random.default_rng(1)):
    hits = 0
    for _ in range(sims):
        a = rng.normal(0, sd, n); b = rng.normal(delta, sd, n)
        p = st.ttest_ind(a, b, equal_var=False).pvalue
        hits += p < alpha
    return hits / sims
power_curve = {f'{n}': float(power_n(n, 0.15, sd_est)) for n in [4, 8, 16, 32, 64]}
R['D25'] = dict(n_seeds=len(finals), sd_final_val=sd_est,
                val_mean=float(v.mean()), val_ci95=[float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5))],
                bayes_hdi_mean_val=[float(hdi[0]), float(hdi[1])],
                rho_psi_val=float(st.spearmanr(ps, v).statistic),
                rho_sg_val=float(st.spearmanr(sgv, v).statistic),
                rho_id_val=float(st.spearmanr(idv, v).statistic),
                rho_r_val=float(st.spearmanr(rv, v).statistic),
                median_psi_drop=float(np.median([d['psi_drop'] for d in drops])),
                median_sg_drop=float(np.median([d['sg_drop'] for d in drops])),
                median_id_drop=float(np.median([d['id_drop'] for d in drops])),
                power_for_delta015=power_curve,
                final_states=finals)

# ---------------------------------------------------------------- D2.3 cross-architecture
arch = {}
for name in ['retnet', 'rwkv', 'ssm']:
    ds = load(f'ARCH_{name}_seed*.json')
    vals = [d['traj'][-1]['val'] for d in ds]
    sgs = [d['traj'][-1]['sg'] for d in ds]
    rr = [max(t['r_logit'] for t in d['traj']) for d in ds]
    rf = [d['traj'][-1]['r_logit'] for d in ds]
    taus = [d['tau'] for d in ds if d['tau']]
    sg_drop = [d['traj'][0]['sg'] / max(d['traj'][-1]['sg'], 1e-9) for d in ds]
    arch[name] = dict(n=len(ds), val_mean=float(np.mean(vals)), val_min=float(np.min(vals)),
                      tau_median=float(np.median(taus)) if taus else None,
                      sg_drop_median=float(np.median(sg_drop)),
                      r_max_mean=float(np.mean(rr)), r_final_mean=float(np.mean(rf)),
                      frac_lock=float(np.mean([x > 0.1 for x in rr])))
R['D23'] = dict(architectures=arch,
                attention_note='attention+MLP head: 2 independent runs (this grid, E8) failed to reach the 0.9 criterion within 20k-60k steps under the same protocol')

# ---------------------------------------------------------------- D2.2 MSL (L2 proxy)
msl = load('MSL_seed*.json')
ms = {}
for d in msl:
    onsets = {}
    for sid in range(4):
        first = None
        for t in d['traj']:
            if t['per'].get(str(sid), t['per'].get(sid)) is not None and t['per'][str(sid)] >= 0.5:
                first = t['step']; break
        onsets[sid] = first
    ms[d['seed']] = dict(onsets=onsets, final_per=d['traj'][-1]['per'],
                         sg_early=d['traj'][0]['sg'], sg_final=d['traj'][-1]['sg'])
R['D22'] = dict(seeds=ms, skill_names=['add', 'sub', 'copy', 'negate'])

# ---------------------------------------------------------------- D4.1 MET
met = load('MET_seed*.json')
def onset(traj, key, thr=0.5):
    for t in traj:
        if t[key] >= thr:
            return t['step']
    return None
def mid(traj, key):
    vals = [t[key] for t in traj]
    lo, hi = min(vals), max(vals)
    thr = lo + 0.5 * (hi - lo)
    for t in traj:
        if t[key] >= thr:
            return t['step']
    return None
met_res = []
for d in met:
    tr = d['traj']
    met_res.append(dict(seed=d['seed'],
                        onset_exact=onset(tr, 'acc_exact'),
                        onset_m0=onset(tr, 'acc_m0'),
                        onset_m1=onset(tr, 'acc_m1'),
                        onset_cont=onset(tr, 'cont'),
                        mid_sg=mid(tr, 'sg')))
R['D41'] = dict(seeds=met_res)

# ---------------------------------------------------------------- D4.2 CIR
cir = load('CIR_seed*.json')
cir_res = []
for d in cir:
    tr = d['traj']
    shares = [t['norm_share'] for t in tr]
    final_share = shares[-1]
    form, sg_mid, val_mid = None, None, None
    for t in tr:
        if form is None and t['norm_share'] > 0.8 * final_share:
            form = t['step']
    vv = [t['val'] for t in tr]
    thr = min(vv) + 0.5 * (max(vv) - min(vv))
    for t in tr:
        if val_mid is None and t['val'] >= thr:
            val_mid = t['step']
    cir_res.append(dict(seed=d['seed'], formation=form, val_mid=val_mid,
                        base_acc=d.get('base_acc'),
                        critical_units=(d.get('critical_units') or [])[:10],
                        crit_sensitivity=d.get('crit_sensitivity'),
                        norm_share_final=final_share))
R['D42'] = dict(seeds=cir_res)

# ---------------------------------------------------------------- D4.3 W scaling
wres = {}
for w in [50, 100, 200, 400]:
    ds = load(f'W{w}_seed*.json')
    vals = [d['traj'][-1]['val'] for d in ds]
    sgs = [d['traj'][-1]['sg'] for d in ds]
    ids = [d['traj'][-1]['id'] for d in ds]
    # onset = first probe with val>=0.5
    on = []
    for d in ds:
        for t in d['traj']:
            if t['val'] >= 0.5:
                on.append(t['step']); break
    wres[w] = dict(n=len(ds), val_mean=float(np.mean(vals)), sg_final=float(np.mean(sgs)),
                   id_final=float(np.mean(ids)),
                   onset_mean=float(np.mean(on)) if on else None)
R['D43'] = dict(widths=wres)

# ---------------------------------------------------------------- D5.3 early-stop guidance
es = []
for d in xs:
    tr = d['traj']
    steps = [t['step'] for t in tr]
    sg = [t['sg'] for t in tr]
    val = [t['val'] for t in tr]
    lo, hi = min(sg), max(sg)
    thr = lo + 0.5 * (hi - lo)
    idx = next((i for i, s in enumerate(sg) if s <= thr), len(tr) - 1)
    es.append(dict(seed=d['seed'], stop_step=steps[idx], stop_val=val[idx],
                   end_step=steps[-1], end_val=val[-1],
                   saved_frac=1 - steps[idx] / steps[-1]))
R['D53'] = dict(cases=es,
                mean_saved=float(np.mean([e['saved_frac'] for e in es])),
                mean_gap=float(np.mean([e['end_val'] - e['stop_val'] for e in es])),
                max_gap=float(np.max([e['end_val'] - e['stop_val'] for e in es])))

# ---------------------------------------------------------------- D5.4 ALIGN
al = load('ALIGN_seed*.json')
al_rows = []
for d in al:
    for r in d['rows']:
        al_rows.append(dict(seed=d['seed'], **r))
dmg = np.array([r['damage'] for r in al_rows])
sg_abs = np.array([r['sg_after'] - r['sg_before'] for r in al_rows])
id_abs = np.array([r['id_after'] - r['id_before'] for r in al_rows])
R['D54'] = dict(rows=al_rows,
                rho_damage_sg_delta=float(st.spearmanr(dmg, sg_abs).statistic),
                rho_damage_id_delta=float(st.spearmanr(dmg, id_abs).statistic),
                damage_by_f={str(f): float(np.mean([r['damage'] for r in al_rows if r['f'] == f]))
                             for f in sorted({r['f'] for r in al_rows})},
                sg_delta_by_f={str(f): float(np.mean([r['sg_after'] - r['sg_before'] for r in al_rows if r['f'] == f]))
                               for f in sorted({r['f'] for r in al_rows})})

# ---------------------------------------------------------------- D5.1 AUDIT
au = load('AUDIT_seed*.json')
rows = []
for d in au:
    for r in d['rows']:
        rows.append(dict(seed=d['seed'], **r))
# audit rule: collapse if sg-return exceeds half of the pre-edit gap OR rebound fails
rule = []
for r in rows:
    sg_rel = abs(r['sg_rel'])
    pred_collapse = (not r['rebound'])
    rule.append(dict(eps=r['eps'], persist=r['persist'], rebound=r['rebound'],
                     sg_rel=sg_rel, id_rel=abs(r['id_rel']), pred=pred_collapse,
                     truth=not r['rebound']))
R['D51'] = dict(n=len(rows),
                persist_by_eps={str(e): float(np.mean([r['persist'] for r in rows if r['eps'] == e]))
                                for e in sorted({r['eps'] for r in rows})},
                rebound_by_eps={str(e): float(np.mean([r['rebound'] for r in rows if r['eps'] == e]))
                                for e in sorted({r['eps'] for r in rows})},
                sg_rel_by_eps={str(e): float(np.mean([abs(r['sg_rel']) for r in rows if r['eps'] == e]))
                               for e in sorted({r['eps'] for r in rows})},
                rows=rule)

# ---------------------------------------------------------------- D3.2 registry
reg = load('REG_seed*.json')
timing = reg[0]['timing'] if reg else {}
rows = []
for d in reg:
    for t in d['traj']:
        rows.append(t)
# post-hoc CKA to final profile per seed
metrics = ['sg', 'id_twonn', 'pr', 'stable_rank', 'eff_rank', 'pca95', 'feature_rank',
           'knn_consistency', 'silhouette', 'jac_rank']
psi = np.array([r['psi'] for r in rows]); val = np.array([r['val'] for r in rows])
registry = {}
for mname in metrics + ['psi']:
    x = np.array([r[mname] for r in rows], float)
    registry[mname] = dict(t_s=float(timing.get(mname, np.nan)),
                           rho_psi=float(st.spearmanr(x, psi).statistic),
                           rho_val=float(st.spearmanr(x, val).statistic))
# verdicts against the registered rule (|rho|>=0.9 and >=10x faster than psi)
t_psi = registry['psi']['t_s']
for mname, rec in registry.items():
    if mname == 'psi':
        rec['verdict'] = 'reference'; continue
    fast = (t_psi / rec['t_s']) >= 10 if rec['t_s'] and rec['t_s'] > 0 else False
    rpv = abs(rec['rho_psi'])
    rec['speedup_vs_psi'] = float(t_psi / rec['t_s']) if rec['t_s'] and rec['t_s'] > 0 else None
    rec['verdict'] = ('approved' if rpv >= 0.9 and fast else
                      'provisional' if rpv >= 0.7 else 'rejected')
R['D32'] = dict(n_checkpoints=len(rows), n_seeds=len(reg), registry=registry)
# cka post-hoc per seed
cka = {}
for d in reg:
    profs = [np.array(t['profile']) for t in d['traj']]
    fin = profs[-1]
    def lc(A, B):
        A = A - A.mean(0, keepdims=True); B = B - B.mean(0, keepdims=True)
        return float(((A.T @ B) ** 2).sum() / (np.linalg.norm(A.T @ A) * np.linalg.norm(B.T @ B)))
    cka[d['seed']] = [lc(P, fin) for P in profs]
cka_all = np.concatenate([np.array(v) for v in cka.values()])
R['D32']['cka_to_final'] = dict(rho_psi=float(st.spearmanr(cka_all, psi).statistic),
                                rho_val=float(st.spearmanr(cka_all, val).statistic))

json.dump(R, open(f'{OUT}/analysis_v3.json', 'w'), indent=1, default=str)
print('D21 verdict:', R['D21']['A1_minus_A3'])
print('D25:', {k: R['D25'][k] for k in ['n_seeds', 'val_mean', 'rho_psi_val', 'rho_sg_val', 'median_psi_drop', 'median_sg_drop', 'power_for_delta015']})
print('D23:', json.dumps(R['D23']['architectures']))
print('D32 registry:', {k: (round(v['rho_psi'], 3), v['verdict']) for k, v in R['D32']['registry'].items()})
print('D53:', R['D53']['mean_saved'], R['D53']['mean_gap'], R['D53']['max_gap'])
print('D51:', R['D51']['persist_by_eps'], R['D51']['rebound_by_eps'])
print('D54:', R['D54']['rho_damage_sg_delta'], R['D54']['damage_by_f'])
print('D41:', R['D41'])
print('D42:', R['D42'])
print('D43:', R['D43'])
print('D22:', R['D22'])
