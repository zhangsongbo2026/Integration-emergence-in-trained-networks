"""E2: Arrhenius scaling of grokking delay tau vs learning rate (T_eff).
Usage: python run_E2.py   (grid defined inside; early stop at val>=0.9)
"""
import json, os, time, gc
import numpy as np, torch, torch.nn.functional as F
from grok_core import make_data
from mlp_core import MLPModel

torch.set_num_threads(1)
p = 29
OUT = '../results'
os.makedirs(OUT, exist_ok=True)

LRS = [5e-4, 1e-3, 2e-3, 4e-3]
SEEDS = [0, 1, 2, 3]
CAP = {5e-4: 150000, 1e-3: 100000, 2e-3: 60000, 4e-3: 40000}

def run(lr, seed):
    m = MLPModel(p=p, seed=seed)
    Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
    opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=2.0)
    steps = CAP[lr]
    tau = None; hit = 0
    t0 = time.time()
    for step in range(steps + 1):
        if step % 200 == 0:
            with torch.no_grad():
                lv, _ = m(Xva); v = (lv.argmax(-1) == Yva).float().mean().item()
                lt, _ = m(Xtr); tr = (lt.argmax(-1) == Ytr).float().mean().item()
            if tau is None and tr >= 0.995 and v >= 0.5:
                tau = step
                print(f'lr {lr} seed {seed}: tau={tau} (t={time.time()-t0:.0f}s)', flush=True)
            if v >= 0.9:
                hit += 1
                if hit >= 5:
                    break
            else:
                hit = 0
            if tau is not None and (v >= 0.7 or step - tau > 3000):
                break
        if step == steps:
            break
        opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
    res = dict(lr=lr, seed=seed, tau=tau, final_val=v, final_train=tr,
               steps_run=step, wall=time.time() - t0)
    json.dump(res, open(f'{OUT}/E2_lr{lr}_seed{seed}.json', 'w'))
    gc.collect()
    return res

if __name__ == '__main__':
    import sys
    for lr in LRS:
        for seed in SEEDS:
            f = f'{OUT}/E2_lr{lr}_seed{seed}.json'
            if os.path.exists(f):
                continue
            r = run(lr, seed)
            print('DONE', r, flush=True)
