import time, numpy as np, torch, torch.nn.functional as F
from grok_core import AttnOnlyModel, make_data

def quick(p=29, lr=1e-3, wd=1.0, frac=0.5, steps=30000, seed=0):
    m = AttnOnlyModel(p=p, seed=seed)
    Xtr, Ytr, Xva, Yva = make_data(p, frac, seed)
    opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=wd)
    va_trace = []
    for step in range(steps + 1):
        if step % 1000 == 0:
            with torch.no_grad():
                lv, _ = m(Xva); va_trace.append((step, (lv.argmax(-1) == Yva).float().mean().item()))
        if step == steps: break
        opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
    return va_trace

t0 = time.time()
r1 = quick(lr=3e-3, wd=1.0, steps=30000)
print('lr=3e-3 wd=1:', [(s, round(v, 2)) for s, v in r1 if v > 0.3 or s % 5000 == 0], round(time.time()-t0, 1), 's')
t0 = time.time()
r2 = quick(lr=1e-3, wd=2.0, steps=30000)
print('lr=1e-3 wd=2:', [(s, round(v, 2)) for s, v in r2 if v > 0.3 or s % 5000 == 0], round(time.time()-t0, 1), 's')
