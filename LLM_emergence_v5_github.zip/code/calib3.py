import json, time, numpy as np, torch, torch.nn.functional as F
from grok_core import make_data
from mlp_core import MLPModel, probe

p, lr, wd, steps, seed = 29, 1e-3, 2.0, 60000, 0
m = MLPModel(p=p, seed=seed)
Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=wd)
traj, dgm_keep = [], {}
t0 = time.time()
for step in range(steps + 1):
    if step % 1000 == 0 or step == steps:
        with torch.no_grad():
            lv, _ = m(Xva); v = (lv.argmax(-1) == Yva).float().mean().item()
            lt, _ = m(Xtr); tr = (lt.argmax(-1) == Ytr).float().mean().item()
        pv, dgm_c, dgm_p = probe(m, Xva, Xva.numpy(), Yva, p, seed=seed)
        pv.update(step=step, train_acc=tr, val_acc=v)
        traj.append(pv)
        if step in (10000, 20000, 23000, 26000, 40000, 60000):
            dgm_keep[step] = [[float(a), float(b)] for a, b in dgm_c[:40]]
        print(f"st {step} val {v:.2f} psi {pv['psi']:.2f} null {pv['psi_null']:.2f} "
              f"net {pv['psi_net']:.2f} r {pv['r']:.2f} conc2 {pv['conc2']:.2f} id {pv['id']:.1f}", flush=True)
    if step == steps:
        break
    opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
print('wall', round(time.time() - t0, 1))
json.dump(dict(traj=traj, dgms=dgm_keep), open('calib_mlp2_seed0.json', 'w'))
