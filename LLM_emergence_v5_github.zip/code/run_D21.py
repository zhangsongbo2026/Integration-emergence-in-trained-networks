"""D2.1 主协议 v2.0：三臂因果干预（拓扑固化诱导 vs 碎片保持 vs 消融对照）.

Arms:
  A1 consolidation-induction : auxiliary class-consistency loss pulling each
     prompt's logits toward its class-mean profile (promotes output-geometry
     consolidation: sg down, ID down, psi1 down).
  A2 fragmentation-preserving : the exact negative of A1 (equal L2 norm),
     pushing within-class prompts apart.
  A3 ablation control         : the same auxiliary pressure computed against a
     label-permuted class-mean (equal norm), isolating direction from magnitude.

Primary outcome: final validation accuracy difference Delta = A1 - A3 with
95% CI; secondary: generalisation onset tau, and the consolidation statistics
(sg, ID, psi1) to verify the intervention moved its target.

Usage: python run_D21.py <arm> <seed>
"""
import json, os, sys, time, gc
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from grok_core import make_data
from mlp_core import MLPModel, cloud_prep, two_nn_id, spectral_gap, h1_diagram

torch.set_num_threads(1)
p = 29
OUT = '../results'
os.makedirs(OUT, exist_ok=True)
LAM = 0.1          # preregistered auxiliary weight (relative to CE)


def class_profiles(logits, labels, p):
    """Mean logit profile per class (detached targets)."""
    prof = torch.zeros(p, logits.shape[1])
    prof = logits.new_zeros(p, logits.shape[1])
    for c in range(p):
        m = labels == c
        if m.any():
            prof[c] = logits[m].mean(0)
    return prof.detach()


def aux_loss(logits, labels, prof):
    """Class-consistency: pull each prompt's logits toward its class profile."""
    target = prof[labels]
    return ((logits - target) ** 2).mean()


def run(arm, seed, steps=40000):
    m = MLPModel(p=p, seed=seed)
    Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
    opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=2.0)
    rng = np.random.default_rng(seed)
    traj, tau, v_final = [], None, 0.0
    t0 = time.time()
    for step in range(steps + 1):
        if step % 2000 == 0 or step == steps:
            m.eval()
            with torch.no_grad():
                lv, H = m(Xva)
                v = (lv.argmax(-1) == Yva).float().mean().item()
                lt, _ = m(Xtr)
                tr = (lt.argmax(-1) == Ytr).float().mean().item()
                Lc = cloud_prep(lv, max_points=300, seed=0)
                dgm = h1_diagram(Lc)
                psi = float((dgm[:, 1] - dgm[:, 0]).sum()) if len(dgm) else 0.0
                met = dict(step=step, val=v, train=tr, psi=psi,
                           id=two_nn_id(Lc), sg=spectral_gap(Lc))
            m.train()
            traj.append(met)
            if tau is None and tr >= 0.995 and v >= 0.5:
                tau = step
            print(f'{arm} seed {seed} st {step} val {v:.3f} sg {met["sg"]:.3f} '
                  f'psi {psi:.1f} id {met["id"]:.1f}', flush=True)
            if v >= 0.9 or (tau is not None and step - tau > 8000):
                v_final = v
                break
        if step == steps:
            v_final = v
            break
        lg, H = m(Xtr)
        ce = F.cross_entropy(lg, Ytr)
        if arm == 'A3':
            perm = torch.tensor(rng.permutation(Ytr.numpy()))
            prof = class_profiles(lg.detach(), perm, p)
            a = aux_loss(lg, Ytr, prof)
        else:
            prof = class_profiles(lg.detach(), Ytr, p)
            a = aux_loss(lg, Ytr, prof)
            if arm == 'A2':
                a = -a
        loss = ce + LAM * a
        opt.zero_grad(); loss.backward(); opt.step()
    rec = dict(arm=arm, seed=seed, tau=tau, final_val=v_final, steps_run=step,
               wall=time.time() - t0, traj=traj)
    json.dump(rec, open(f'{OUT}/D21_{arm}_seed{seed}.json', 'w'))
    gc.collect()
    return rec


if __name__ == '__main__':
    if sys.argv[1] == 'all':
        for arm in ['A1', 'A2', 'A3']:
            for seed in range(8):
                f = f'{OUT}/D21_{arm}_seed{seed}.json'
                if not os.path.exists(f):
                    run(arm, seed)
    else:
        run(sys.argv[1], int(sys.argv[2]))
