"""V3b refinements: robust onset clocks, audit-rule validation, early-stop
plateau rule, registry details."""
import json, glob
import numpy as np
from scipy import stats as st

OUT = '../results'
R = json.load(open(f'{OUT}/analysis_v3.json'))


def load(pat):
    out = []
    for f in sorted(glob.glob(f'{OUT}/{pat}')):
        try:
            out.append(json.load(open(f)))
        except Exception:
            pass
    return out


# ---------------- cross-architecture robust consolidation reporting
arch2 = {}
for name in ['retnet', 'rwkv', 'ssm']:
    ds = load(f'ARCH_{name}_seed*.json')
    sg0 = np.array([d['traj'][0]['sg'] for d in ds])
    sg1 = np.array([d['traj'][-1]['sg'] for d in ds])
    v1 = np.array([d['traj'][-1]['val'] for d in ds])
    arch2[name] = dict(n=len(ds),
                       sg_early_median=float(np.median(sg0)),
                       sg_final_median=float(np.median(sg1)),
                       frac_consolidated=float(np.mean(sg1 < sg0)),
                       val_mean=float(v1.mean()), val_min=float(v1.min()))
R['D23']['robust'] = arch2

# ---------------- D4.1: sg-based onset (decline to 50% of initial)
met = load('MET_seed*.json')
def onset(traj, key, thr=0.5):
    for t in traj:
        if t[key] >= thr:
            return t['step']
    return None
rows = []
for d in met:
    tr = d['traj']
    sg0 = tr[0]['sg']
    sg_onset = next((t['step'] for t in tr if t['sg'] <= 0.5 * sg0), None)
    rows.append(dict(seed=d['seed'],
                     onset_exact=onset(tr, 'acc_exact'),
                     onset_m0=onset(tr, 'acc_m0'),
                     onset_m1=onset(tr, 'acc_m1'),
                     onset_cont=onset(tr, 'cont'),
                     sg_onset=sg_onset,
                     final_exact=tr[-1]['acc_exact'], final_m1=tr[-1]['acc_m1'],
                     final_cont=tr[-1]['cont']))
cat = {}
for k in ['onset_exact', 'onset_m0', 'onset_m1', 'onset_cont', 'sg_onset']:
    vals = [r[k] for r in rows if r[k] is not None]
    cat[k] = float(np.mean(vals)) if vals else None
spreads = []
for r in rows:
    o = [r[k] for k in ['onset_exact', 'onset_m0', 'onset_m1', 'onset_cont'] if r[k]]
    spreads.append(max(o) - min(o))
R['D41b'] = dict(rows=rows, mean_onsets=cat,
                 metric_onset_spread_mean=float(np.mean(spreads)),
                 metric_onset_spread_max=float(np.max(spreads)),
                 final_state_spread=dict(
                     exact_max_minus_min=float(max(r['final_exact'] for r in rows) - min(r['final_exact'] for r in rows)),
                     cont_max_minus_min=float(max(r['final_cont'] for r in rows) - min(r['final_cont'] for r in rows))))

# ---------------- D5.1 audit rule validation (sg-return predicts unrecoverability)
au = load('AUDIT_seed*.json')
rows = []
for d in au:
    for r in d['rows']:
        rows.append(dict(seed=d['seed'], eps=r['eps'], persist=bool(r['persist']),
                         rebound=bool(r['rebound']), sg_rel=abs(r['sg_rel']),
                         id_rel=abs(r['id_rel'])))
y = np.array([not r['rebound'] for r in rows])           # truth: unrecoverable
best = None
scan = []
for thr in np.linspace(0, 3.0, 61):
    pred = np.array([r['sg_rel'] > thr for r in rows])
    tp = int(((pred == 1) & (y == 1)).sum()); tn = int(((pred == 0) & (y == 0)).sum())
    fp = int(((pred == 1) & (y == 0)).sum()); fn = int(((pred == 0) & (y == 1)).sum())
    bal = 0.5 * (tp / max(tp + fn, 1) + tn / max(tn + fp, 1))
    scan.append(dict(thr=float(thr), bal_acc=float(bal), tp=tp, tn=tn, fp=fp, fn=fn))
    if best is None or bal > best['bal_acc']:
        best = scan[-1]
# also: does sg-return alone separate eps<=0.5 (recoverable) from >=1 (unrecoverable)?
g1 = [r['sg_rel'] for r in rows if r['eps'] <= 0.5]
g2 = [r['sg_rel'] for r in rows if r['eps'] >= 2.0]
mw = st.mannwhitneyu(g1, g2)
R['D51b'] = dict(n=len(rows), best_rule=best, threshold_scan=scan[:10],
                 sg_rel_recoverable_mean=float(np.mean(g1)),
                 sg_rel_unrecoverable_mean=float(np.mean(g2)),
                 mannwhitney_p=float(mw.pvalue),
                 base_rate_unrecoverable=float(y.mean()))

# ---------------- D5.3 early-stop: plateau rule (sg < 20% of initial)
xs = load('X_seed*.json')
cases = []
for d in xs:
    tr = d['traj']; sg0 = tr[0]['sg']
    steps = [t['step'] for t in tr]; sg = [t['sg'] for t in tr]; val = [t['val'] for t in tr]
    idx = next((i for i, s in enumerate(sg) if s <= 0.2 * sg0), len(tr) - 1)
    cases.append(dict(seed=d['seed'], stop_step=steps[idx], stop_val=val[idx],
                      end_step=steps[-1], end_val=val[-1],
                      saved_frac=1 - steps[idx] / steps[-1]))
R['D53b'] = dict(cases=cases,
                 mean_saved=float(np.mean([c['saved_frac'] for c in cases])),
                 mean_gap=float(np.mean([c['end_val'] - c['stop_val'] for c in cases])),
                 max_gap=float(np.max([c['end_val'] - c['stop_val'] for c in cases])),
                 frac_gap_over_005=float(np.mean([(c['end_val'] - c['stop_val']) > 0.05 for c in cases])))

# ---------------- registry details incl. CKA and speedups
reg = load('REG_seed*.json')
timing = reg[0]['timing']
profs = {}
rows = []
for d in reg:
    t = [x for x in d['traj']]
    fin = np.array(t[-1]['profile'])
    def lc(A, B):
        A = A - A.mean(0, keepdims=True); B = B - B.mean(0, keepdims=True)
        return float(((A.T @ B) ** 2).sum() / (np.linalg.norm(A.T @ A) * np.linalg.norm(B.T @ B)))
    for x in t:
        c = lc(np.array(x['profile']), fin)
        rows.append(dict(seed=d['seed'], step=x['step'], val=x['val'], psi=x['psi'], cka=c))
psi = np.array([r['psi'] for r in rows]); val = np.array([r['val'] for r in rows])
cka = np.array([r['cka'] for r in rows])
R['D32b'] = dict(cka_rho_psi=float(st.spearmanr(cka, psi).statistic),
                 cka_rho_val=float(st.spearmanr(cka, val).statistic),
                 timing=timing,
                 speedup_sg=float(timing['psi'] / timing['sg']),
                 speedup_pr=float(timing['psi'] / timing['pr']),
                 speedup_eff=float(timing['psi'] / timing['eff_rank']),
                 speedup_id=float(timing['psi'] / timing['id_twonn']))
# add cka to the registry table (verdict: correlation only, no cost model)
R['D32']['registry']['cka_to_final'] = dict(
    t_s=None, rho_psi=R['D32b']['cka_rho_psi'], rho_val=R['D32b']['cka_rho_val'],
    verdict='provisional' if abs(R['D32b']['cka_rho_psi']) >= 0.7 else 'rejected')

json.dump(R, open(f'{OUT}/analysis_v3.json', 'w'), indent=1, default=str)
print('D23 robust:', json.dumps(R['D23']['robust']))
print('D41b:', json.dumps(R['D41b']['mean_onsets']), 'spread', R['D41b']['metric_onset_spread_mean'])
print('D51b:', json.dumps(R['D51b'])[:400])
print('D53b:', R['D53b']['mean_saved'], R['D53b']['mean_gap'], R['D53b']['max_gap'], R['D53b']['frac_gap_over_005'])
print('D32b:', {k: round(v, 3) for k, v in R['D32b'].items() if isinstance(v, float)})
