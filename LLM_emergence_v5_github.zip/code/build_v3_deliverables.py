"""Build V3 deliverables: per-figure CSVs, toolkit packages with tests,
protocol/change-log/reproducibility documents, roadmap response map."""
import csv, json, os, glob

PAPER = '../paper'
RES = '../results'
PKG = '../pkg/v3'
os.makedirs(f'{PKG}/density_audit/density_audit', exist_ok=True)
os.makedirs(f'{PKG}/density_audit/tests', exist_ok=True)
os.makedirs(f'{PKG}/emergence_monitor/emergence_monitor', exist_ok=True)
os.makedirs(f'{PKG}/emergence_monitor/tests', exist_ok=True)
os.makedirs(f'{PKG}/figure_data', exist_ok=True)
os.makedirs(f'{PKG}/docs', exist_ok=True)
os.makedirs(f'{PKG}/protocols', exist_ok=True)

A3 = json.load(open(f'{RES}/analysis_v3.json'))
A2 = json.load(open(f'{RES}/analysis_summary.json'))


def load(pat):
    out = []
    for f in sorted(glob.glob(f'{RES}/{pat}')):
        try:
            out.append(json.load(open(f)))
        except Exception:
            pass
    return out


# ---------------------------------------------------------------- figure CSVs
def wcsv(name, rows, header):
    with open(f'{PKG}/figure_data/{name}.csv', 'w', newline='') as fh:
        w = csv.writer(fh); w.writerow(header); w.writerows(rows)


wcsv('fig01_E1_trajectories', [[t['step'], t['train_acc'], t['val_acc'], t['r_logit'], t['psi'],
                                t['id'], t['sg']] for t in load('E1_seed0.json')[0]['traj']],
     ['step', 'train_acc', 'val_acc', 'r_logit', 'psi1', 'id', 'sg'])
wcsv('fig02_E1_across_seeds', [[f['seed'], f['val'], f['psi'], f['id'], f['r']] for f in A3['D25']['final_states']],
     ['seed', 'final_val', 'final_psi1', 'final_id', 'final_r'])
wcsv('fig03_E2_arrhenius', [[a['lr'], a['tau_mean'], a['tau_sd'], a['n']] for a in A2['E2']['per_lr']],
     ['lr', 'tau_mean', 'tau_sd', 'n'])
wcsv('fig12_D21_intervention', [[a] + [A3['D21']['arms'][a][k] for k in ['val_mean', 'val_sd', 'tau_median', 'sg_final', 'pr_final', 'psi_final']]
                                for a in ['A0', 'A1', 'A2', 'A3']],
     ['arm', 'val_mean', 'val_sd', 'tau_median', 'sg_final', 'pr_final', 'psi_final'])
wcsv('fig13_D25_grid32', [[f['seed'], f['src'], f['val'], f['psi'], f['sg'], f['id'], f['r']]
                          for f in A3['D25']['final_states']],
     ['seed', 'source', 'final_val', 'final_psi1', 'final_sg', 'final_id', 'final_r'])
arch_rows = []
for n in ['retnet', 'rwkv', 'ssm']:
    for d in load(f'ARCH_{n}_seed*.json'):
        arch_rows.append([n, d['seed'], d['traj'][0]['sg'], d['traj'][-1]['sg'],
                          d['traj'][-1]['val'], d['tau']])
wcsv('fig14_D23_architecture', arch_rows, ['family', 'seed', 'sg_early', 'sg_final', 'val', 'tau'])
reg = A3['D32']['registry']
wcsv('fig15_D32_registry', [[k, v['rho_psi'], v.get('speedup_vs_psi'), v['verdict']] for k, v in reg.items()],
     ['metric', 'rho_with_psi', 'speedup_vs_psi', 'verdict'])
wcsv('fig16_D41_D54_D51', [[r['seed'], r['onset_exact'], r['onset_m1'], r['onset_cont'], r['sg_onset']]
                           for r in A3['D41b']['rows']], ['seed', 'onset_exact', 'onset_m1', 'onset_cont', 'sg_onset'])
wcsv('fig17_D53_D22_D43', [[c['seed'], c['stop_step'], c['stop_val'], c['end_step'], c['end_val']]
                           for c in A3['D53b']['cases']], ['seed', 'stop_step', 'stop_val', 'end_step', 'end_val'])
wcsv('fig18_concept', [['memorisation', 'fragmented output geometry; psi1 high; gap high; ID high; capability low'],
                       ['transition', 'circuits assemble; capability rises; metric-fragile onset'],
                       ['consolidated', 'smooth low-dim manifold; psi1 low; gap low; ID low; capability high'],
                       ['causal', 'A1-A3 = 0.277 [0.197,0.374]; A2 below control']], ['stage', 'description'])
wcsv('fig19_audit_flowchart', [[1, 'train to consolidation; record baseline geometry'],
                               [2, 'apply edit'],
                               [3, '400-step light fine-tune on clean data'],
                               [4, 'read outcome: recovered or collapsed']], ['step', 'action'])

# ---------------------------------------------------------------- density_audit
open(f'{PKG}/density_audit/density_audit/__init__.py', 'w').write(
    'from .audit import cycle_rank, condition, identity_check, inflation_demo\n')
open(f'{PKG}/density_audit/density_audit/audit.py', 'w').write('''"""density_audit: cycle-rank identity and density-conditioned scaling audit."""
import numpy as np


def cycle_rank(n_nodes, edges):
    """Exact beta1 = m - n + c by union-find."""
    par = list(range(n_nodes))
    def find(x):
        while par[x] != x:
            par[x] = par[par[x]]; x = par[x]
        return x
    c = n_nodes
    for u, v in edges:
        ru, rv = find(u), find(v)
        if ru != rv:
            par[ru] = rv; c -= 1
    return len(edges) - n_nodes + c


def identity_check(n_nodes, edges):
    """beta1 versus n(kbar/2 - 1) + c; returns (beta1, formula, error)."""
    b1 = cycle_rank(n_nodes, edges)
    m = len(edges)
    kbar = 2.0 * m / n_nodes
    comps = n_nodes
    par = list(range(n_nodes))
    def find(x):
        while par[x] != x:
            par[x] = par[par[x]]; x = par[x]
        return x
    for u, v in edges:
        ru, rv = find(u), find(v)
        if ru != rv:
            par[ru] = rv; comps -= 1
    formula = n_nodes * (kbar / 2.0 - 1.0) + comps
    return b1, formula, abs(b1 - formula)


def condition(ns, betas, kbars):
    """Density-conditioned regression log beta1 = a + b log n + s log kbar."""
    y = np.log10(np.asarray(betas, float) + 1.0)
    X = np.column_stack([np.ones(len(ns)), np.log10(ns), np.log10(kbars)])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    pred = X @ beta
    r2 = 1 - ((y - pred) ** 2).sum() / ((y - y.mean()) ** 2).sum()
    return dict(intercept=float(beta[0]), b_log_n=float(beta[1]),
                b_log_kbar=float(beta[2]), r2=float(r2))


def inflation_demo(alpha=0.3, n_list=(100, 200, 500, 1000, 2000), reps=3, seed=7):
    """Reproduce the paper's inflation: naive b = 1 + alpha, conditioned b ~ 1."""
    rng = np.random.default_rng(seed)
    ns, betas, kbars = [], [], []
    for n in n_list:
        for _ in range(reps):
            kbar = max(2.5, 4.0 * (n / 100.0) ** alpha)
            p = kbar / (n - 1)
            edges = [(i, j) for i in range(n) for j in range(i + 1, n) if rng.random() < p]
            b1 = cycle_rank(n, edges)
            ns.append(n); betas.append(b1); kbars.append(2 * len(edges) / n)
    y = np.log10(np.array(betas, float) + 1.0)
    xn = np.log10(np.array(ns, float))
    naive = np.polyfit(xn, y, 1)[0]
    cond = condition(ns, betas, kbars)
    return dict(alpha=alpha, b_naive=float(naive), **cond)
''')
open(f'{PKG}/density_audit/tests/test_audit.py', 'w').write('''import numpy as np
from density_audit import cycle_rank, identity_check, condition, inflation_demo


def test_cycle_rank_known_graphs():
    # triangle: n=3, m=3, c=1 -> beta1 = 1
    assert cycle_rank(3, [(0, 1), (1, 2), (0, 2)]) == 1
    # tree: beta1 = 0
    assert cycle_rank(4, [(0, 1), (1, 2), (2, 3)]) == 0
    # two disjoint cycles
    assert cycle_rank(6, [(0, 1), (1, 2), (2, 0), (3, 4), (4, 5), (5, 3)]) == 2


def test_identity_exact():
    rng = np.random.default_rng(0)
    n = 120
    edges = [(i, j) for i in range(n) for j in range(i + 1, n) if rng.random() < 0.06]
    b1, formula, err = identity_check(n, edges)
    assert err < 1e-9 and b1 == formula


def test_inflation_and_recovery():
    out = inflation_demo(alpha=0.3, n_list=(100, 200, 400), reps=2)
    assert out['b_naive'] > 1.2
    assert abs(out['b_log_n'] - 1.0) < 0.25
''')
open(f'{PKG}/density_audit/density_audit/cli.py', 'w').write('''import argparse
from .audit import inflation_demo

def main():
    ap = argparse.ArgumentParser(description='density-conditioned cycle-rank audit')
    ap.add_argument('--alpha', type=float, default=0.3)
    a = ap.parse_args()
    print(inflation_demo(alpha=a.alpha))

if __name__ == '__main__':
    main()
''')

# ---------------------------------------------------------------- emergence_monitor
open(f'{PKG}/emergence_monitor/emergence_monitor/__init__.py', 'w').write(
    'from .monitor import spectral_gap, participation_ratio, consolidation_onset, Monitor\n')
open(f'{PKG}/emergence_monitor/emergence_monitor/monitor.py', 'w').write('''"""emergence_monitor: checkpoint-level consolidation measurement."""
import numpy as np


def _standardise(Z):
    Z = np.asarray(Z, float)
    Z = (Z - Z.mean(0, keepdims=True)) / (Z.std(0, keepdims=True) + 1e-9)
    return Z / (np.linalg.norm(Z, axis=1, keepdims=True) + 1e-12)


def spectral_gap(X, k=10):
    """Normalised Laplacian eigengap of the kNN cosine-similarity graph."""
    Z = _standardise(X)
    S = np.clip(Z @ Z.T, 0, 1); np.fill_diagonal(S, 0)
    W = np.zeros_like(S)
    idx = np.argpartition(-S, k, axis=1)[:, :k]
    for i, js in enumerate(idx):
        W[i, js] = S[i, js]
        W[js, i] = np.maximum(W[js, i], S[i, js])
    deg = W.sum(1) + 1e-12
    L = np.eye(len(W)) - (1 / np.sqrt(deg))[:, None] * W * (1 / np.sqrt(deg))[None, :]
    ev = np.sort(np.linalg.eigvalsh(L))
    return float(ev[1] - ev[0])


def participation_ratio(X):
    Z = np.asarray(X, float)
    Z = Z - Z.mean(0, keepdims=True)
    s = np.linalg.svd(Z, compute_uv=False)
    return float((s.sum() ** 2) / (s ** 2).sum())


def consolidation_onset(gaps, steps, frac=0.2):
    """First step at which the gap falls below frac x its initial value."""
    g0 = gaps[0]
    for s, g in zip(steps, gaps):
        if g <= frac * g0:
            return int(s)
    return None


class Monitor:
    """Minimal training callback shim: call .step(activations) each probe."""

    def __init__(self, frac=0.2):
        self.frac = frac
        self.history = []

    def step(self, step, activations):
        g = spectral_gap(activations)
        pr = participation_ratio(activations)
        self.history.append(dict(step=step, sg=g, pr=pr))
        return self.history[-1]

    def onset(self):
        if not self.history:
            return None
        gaps = [h['sg'] for h in self.history]
        steps = [h['step'] for h in self.history]
        return consolidation_onset(gaps, steps, self.frac)

    def dashboard_html(self, path):
        rows = ''.join(f"<tr><td>{h['step']}</td><td>{h['sg']:.4f}</td>"
                       f"<td>{h['pr']:.1f}</td></tr>" for h in self.history)
        open(path, 'w').write(
            "<html><head><meta charset='utf-8'><title>emergence monitor</title></head>"
            "<body><h3>Consolidation monitor</h3><table border='1'>"
            "<tr><th>step</th><th>spectral gap</th><th>participation ratio</th></tr>"
            f"{rows}</table></body></html>")
''')
open(f'{PKG}/emergence_monitor/tests/test_monitor.py', 'w').write('''import numpy as np
from emergence_monitor import spectral_gap, participation_ratio, consolidation_onset, Monitor


def test_gap_orders_random_vs_consolidated():
    rng = np.random.default_rng(0)
    fragmented = rng.normal(size=(200, 30)) * np.array([1.0] * 10 + [0.05] * 20)
    consolidated = rng.normal(size=(200, 30)) * np.array([1.0] * 2 + [0.01] * 28)
    assert spectral_gap(fragmented) > spectral_gap(consolidated)
    assert participation_ratio(fragmented) > participation_ratio(consolidated)


def test_onset_and_monitor():
    gaps = [0.2, 0.15, 0.05, 0.01]
    steps = [0, 1000, 2000, 3000]
    assert consolidation_onset(gaps, steps, 0.2) == 2000
    m = Monitor()
    X = np.random.default_rng(1).normal(size=(50, 8))
    m.step(0, X); m.step(1000, X * 0.1)
    assert len(m.history) == 2 and m.onset() in (0, 1000)
''')
open(f'{PKG}/emergence_monitor/emergence_monitor/cli.py', 'w').write('''import argparse, json
from .monitor import Monitor

def main():
    ap = argparse.ArgumentParser(description='consolidation monitor over recorded activations (npy)')
    ap.add_argument('npy', help='array file: probes x samples x dims')
    ap.add_argument('--steps', type=int, default=1000)
    a = ap.parse_args()
    import numpy as np
    X = np.load(a.npy)
    m = Monitor()
    for i, probe in enumerate(X):
        m.step(i * a.steps, probe)
    print(json.dumps({'onset': m.onset(), 'history': m.history[-3:]}))

if __name__ == '__main__':
    main()
''')

# checkpoint suite pipeline (released, not executed here)
open(f'{PKG}/checkpoint_suite_pipeline.py', 'w').write('''"""Continuous-tier pipeline (released, NOT executed in this study).

For each public checkpoint of a suite (e.g. Pythia 70M-1B, OLMo-1B):
  1. sample activations on a fixed prompt corpus,
  2. compute the calibrated surrogates (spectral gap, participation ratio,
     effective rank), Psi1 if affordable, and the density-conditioned audit,
  3. run the composition-null stationarity test,
  4. align the trajectory with training loss and downstream accuracy.

Requires: transformers, datasets, torch; ~1-2 GB per 70M checkpoint.
"""
import json, numpy as np

def surrogate_metrics(activations):
    from emergence_monitor import spectral_gap, participation_ratio
    return dict(sg=spectral_gap(activations), pr=participation_ratio(activations))

def composition_null(barcode_miner, batch_a, batch_b):
    """Compare matched-set drift against the same-snapshot cross-batch null."""
    from persim import wasserstein
    return dict(cross_batch=wasserstein(barcode_miner(batch_a), barcode_miner(batch_b)))

def run_suite(model_names, corpus, out_json='suite_results.json'):
    """Reference implementation; requires network and GPU access."""
    from transformers import AutoModel, AutoTokenizer
    import torch
    results = {}
    for name in model_names:
        tok = AutoTokenizer.from_pretrained(name)
        model = AutoModel.from_pretrained(name, output_hidden_states=True)
        model.eval()
        with torch.no_grad():
            enc = tok(corpus, return_tensors='pt', truncation=True)
            hs = model(**enc).hidden_states[-1].mean(1).numpy()
        results[name] = surrogate_metrics(hs)
    json.dump(results, open(out_json, 'w'), indent=1)
    return results

if __name__ == '__main__':
    print(__doc__)
''')

print('packages written')
