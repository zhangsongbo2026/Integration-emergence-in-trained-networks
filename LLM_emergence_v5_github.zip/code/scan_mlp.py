"""Power-et-al-style MLP grokking model: concat(emb_a, emb_b) -> MLP -> p classes."""
import time, sys, numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from grok_core import make_data

class MLPModel(nn.Module):
    def __init__(self, p=29, d=128, dh=100, seed=0):
        super().__init__()
        torch.manual_seed(seed)
        self.p = p
        self.ea = nn.Embedding(p, d)
        self.eb = nn.Embedding(p, d)
        self.fc1 = nn.Linear(2 * d, dh)
        self.fc2 = nn.Linear(dh, p)

    def forward(self, tokens):
        x = torch.cat([self.ea(tokens[:, 0]), self.eb(tokens[:, 1])], dim=1)
        h = F.relu(self.fc1(x))
        logits = self.fc2(h)
        return logits, h          # h: (B, dh) activation cloud for PH

if __name__ == '__main__':
    lr = float(sys.argv[1]); wd = float(sys.argv[2]); steps = int(sys.argv[3])
    seed = int(sys.argv[4]) if len(sys.argv) > 4 else 0
    p = int(sys.argv[5]) if len(sys.argv) > 5 else 29
    m = MLPModel(p=p, seed=seed)
    Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
    opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=wd)
    t0 = time.time(); first_grok = None
    for step in range(steps + 1):
        if step % 500 == 0 or step == steps:
            with torch.no_grad():
                lv, _ = m(Xva); v = (lv.argmax(-1) == Yva).float().mean().item()
                lt, _ = m(Xtr); tr = (lt.argmax(-1) == Ytr).float().mean().item()
            if v > 0.8 and first_grok is None: first_grok = step
            print(f'lr={lr} wd={wd} p={p} step={step} train={tr:.3f} val={v:.3f} t={time.time()-t0:.0f}s', flush=True)
        if step == steps: break
        opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
    print('RESULT mlp', lr, wd, p, seed, 'grok_step', first_grok, flush=True)
