"""verify_numbers: cross-check every quantitative claim in the paper against
analysis_summary.json and raw result records."""
import json, re, glob

paper = open('../paper/Llm_emergence_v2.md').read()
S = json.load(open('../results/analysis_summary.json'))
checks = []

def check(name, claim_in_paper, computed, ok=None):
    if ok is None:
        ok = claim_in_paper in paper
    checks.append((name, claim_in_paper, computed, 'PASS' if ok else 'FAIL'))

# E1
st = S['E1_stats']
check('rho(psi,val)=-0.994', '-0.994', round(st['spearman_psi_val'], 3),
      abs(st['spearman_psi_val'] + 0.994) < 5e-4 and '-0.994' in paper)
check('rho(id,val)=-0.850', '-0.850', round(st['spearman_id_val'], 3),
      abs(st['spearman_id_val'] + 0.850) < 5e-4 and '-0.850' in paper)
check('rho(r,val)=0.216', '0.216', round(st['spearman_r_val'], 3),
      abs(st['spearman_r_val'] - 0.216) < 5e-4 and '0.216' in paper)
check('psi drop 1.47', '1.47', round(st['median_psi_drop'], 2),
      abs(st['median_psi_drop'] - 1.47) < 5e-3 and '1.47' in paper)
check('sg drop 6.0', '6.0-fold', round(st['median_sg_drop'], 1),
      abs(st['median_sg_drop'] - 6.0) < 0.05 and '6.0' in paper)
check('id drop 1.48', '1.48', round(st['median_id_drop'], 2),
      abs(st['median_id_drop'] - 1.48) < 5e-3 and '1.48' in paper)
check('lock r median 5000', '5,000 steps', st['median_lock_r_val'],
      st['median_lock_r_val'] == 5000 and '5,000 steps' in paper)
check('lock psi median 10000', '10,000 steps', st['median_lock_psi_val'],
      st['median_lock_psi_val'] == 10000 and '10,000 steps' in paper)
check('seed0 r 0.00->0.39', '0.00', None, 'rises from $0.00$ to $0.39$' in paper.replace('\\$',''))

# E2
arr = S['E2']['arrhenius']
check('arr R2 0.978', '0.978', round(arr['R2'], 3), abs(arr['R2'] - 0.978) < 5e-4 and '0.978' in paper)
check('arr slope 0.96', '0.96', round(arr['slope'], 2), abs(arr['slope'] - 0.96) < 5e-3 and 'beta = 0.96' in paper)
taus = {a['lr']: a['tau_mean'] for a in S['E2']['per_lr']}
check('tau 18600', '18,600', taus[5e-4], taus[5e-4] == 18600 and '18,600' in paper)
check('tau 2750', '2,750', taus[4e-3], taus[4e-3] == 2750 and '2,750' in paper)
check('gamma 0.96', 'gamma = 0.96', round(-S['E2']['powerlaw']['exponent'], 2),
      abs(S['E2']['powerlaw']['exponent'] + 0.96) < 5e-3 and 'gamma = 0.96' in paper.replace('$', ''))

# E3
e3s = S['E3_stats']
check('recovery 0.927', '0.927', round(e3s['mean_rec_val_eps05'], 3),
      abs(e3s['mean_rec_val_eps05'] - 0.927) < 5e-4 and '0.927' in paper)
check('recovery 0.922', '0.922', round(e3s['mean_rec_val_eps20'], 3),
      abs(e3s['mean_rec_val_eps20'] - 0.922) < 5e-4 and '0.922' in paper)
d0 = json.load(open('../results/E3_seed0.json'))['inversion']
check('r_inv 0.004->0.435', '0.435', round(d0[-1]['r_inv'], 3),
      abs(d0[-1]['r_inv'] - 0.435) < 5e-3 and '0.435' in paper)
check('r_old 0.364', '0.364', round(d0[0]['r_old'], 3),
      abs(d0[0]['r_old'] - 0.364) < 5e-3 and '0.364' in paper)
check('old val 0.95->0.04', '0.95 to 0.04', None,
      '0.95 to 0.04' in paper and abs(d0[0]['val_old'] - 0.952) < 5e-3)

# E4
e4 = S['E4']
check('persist 0.02@0.25', '0.02', round(e4['persist_mean'][0], 2),
      abs(e4['persist_mean'][0] - 0.02) < 5e-3 and '0.02' in paper)
check('persist 0.94@1.0', '0.94', round(e4['persist_mean'][2], 2),
      abs(e4['persist_mean'][2] - 0.94) < 5e-3 and '0.94' in paper)
check('rebound 0.98', '0.98', round(e4['rebound_mean'][0], 2),
      abs(e4['rebound_mean'][0] - 0.98) < 5e-3 and '0.98' in paper)
check('rebound 0.04@2.0', '0.04', round(e4['rebound_mean'][3], 2),
      abs(e4['rebound_mean'][3] - 0.04) < 5e-3 and '0.04' in paper)

# E5
e5 = S['E5']
check('trunc 7,767', '7,767', round(e5['mean_trunc']),
      round(e5['mean_trunc']) == 7767 and '7,767' in paper)
check('full 8,067', '8,067', round(e5['mean_full']),
      round(e5['mean_full']) == 8067 and '8,067' in paper)
check('wilcoxon 0.84', '0.84', round(e5['wilcoxon_p'], 2),
      abs(e5['wilcoxon_p'] - 0.84) < 5e-3 and '0.84' in paper)
check('2 of 6 full faster', 'two of six', e5['frac_full_faster'],
      abs(e5['frac_full_faster'] - 1 / 3) < 1e-9 and 'two of six' in paper)

# E6
e6 = S['E6']
check('naive b 1.43', '1.43', round(e6['regression_naive']['b'], 2),
      abs(e6['regression_naive']['b'] - 1.43) < 5e-3 and '1.43' in paper)
check('cond b 0.997', '0.997', round(e6['regression_conditioned']['b_n'], 3),
      abs(e6['regression_conditioned']['b_n'] - 0.997) < 5e-4 and '0.997' in paper)
per_alpha = {d['alpha']: d for d in e6['per_alpha']}
check('alpha=0 naive 1.01', '1.01', round(per_alpha[0.0]['b_naive'], 2),
      abs(per_alpha[0.0]['b_naive'] - 1.01) < 5e-3)
check('alpha=0.3 naive 1.46', '1.46', round(per_alpha[0.3]['b_naive'], 2),
      abs(per_alpha[0.3]['b_naive'] - 1.46) < 5e-3 and '1.46' in paper)
check('alpha=0.6 naive 1.81', '1.81', round(per_alpha[0.6]['b_naive'], 2),
      abs(per_alpha[0.6]['b_naive'] - 1.81) < 5e-3 and '1.81' in paper)
real = {r['name']: r for r in e6['real']}
check('karate beta1 45', '45', real['karate_club']['beta1'],
      real['karate_club']['beta1'] == 45 and '45' in paper)
check('lesmis beta1 178', '178', real['les_miserables']['beta1'],
      real['les_miserables']['beta1'] == 178 and '178' in paper)

# E7
e7 = S['E7']
check('births mean 8078', '8,078', round(e7['mean_birth']),
      round(e7['mean_birth']) == 8078 and '8,078' in paper)
check('CV 0.40', '0.40', round(e7['cv'], 2),
      abs(e7['cv'] - 0.40) < 5e-3 and '0.40' in paper)
check('n births 232', '232', e7['n'], e7['n'] == 232 and '232' in paper)
check('lognormal rejected', '10^{-11}', None,
      e7['lognormal']['p'] < 1e-10 and '10^{-11}' in paper)

# E8
e8 = S['E8']
cp, ct = e8['cross_prompt_w'], e8['cross_time_w']
check('cross-prompt 2.8-11.8', '2.8 to 11.8', (round(min(cp), 1), round(max(cp), 1)),
      abs(min(cp) - 2.8) < 0.1 and abs(max(cp) - 11.8) < 0.1 and '2.8 to 11.8' in paper)
check('cross-time 2.9-6.2', '2.9 to 6.2', (round(min(ct), 1), round(max(ct), 1)),
      abs(min(ct) - 2.9) < 0.1 and abs(max(ct) - 6.2) < 0.1 and '2.9 to 6.2' in paper)
check('repeat exact zero', 'distance zero', e8['repeat_w'][0], e8['repeat_w'][0] == 0.0)

# E9
e9 = S['E9']
check('SG surrogate 0.965', '0.965', round(e9['rho_psi_sg'], 3),
      abs(e9['rho_psi_sg'] - 0.965) < 5e-4 and '0.965' in paper)
check('ID provisional 0.881', '0.881', round(e9['rho_psi_id'], 3),
      abs(e9['rho_psi_id'] - 0.881) < 5e-4 and '0.881' in paper)
check('r_hidden rejected 0.349', '0.349', round(e9['rho_rh_val'], 3),
      abs(e9['rho_rh_val'] - 0.349) < 5e-4 and '0.349' in paper)
check('13x faster', '13 times', e9['time_ph_s'] / e9['time_surrogate_s'],
      12 < e9['time_ph_s'] / e9['time_surrogate_s'] < 14 and '13 times' in paper)
rd = [v['rel_diff'] for v in e9['approx_pipeline']['variants']]
check('pipeline errors 1.0/22-24%/3.0%', '22-24%', None,
      abs(rd[0] - 0.65) < 5e-3 and 0.22 < rd[1] < 0.24 and abs(rd[3] - 0.030) < 5e-3 and '22-24%' in paper)

# E10
e10 = S['E10']
q = {float(k): v['quality_mean'] for k, v in e10.items()}
check('Q(0)=0.823', '0.823', round(q[0.0], 3), abs(q[0.0] - 0.823) < 5e-4)
check('Q(0.2)=0.784', '0.784', round(q[0.2], 3), abs(q[0.2] - 0.784) < 5e-4)
check('Q(0.4)=0.882', '0.882', round(q[0.4], 3), abs(q[0.4] - 0.882) < 5e-4)

# E11
e11 = S['E11']
taus = [e['tau'] for e in e11]; rr = [e['final_r'] for e in e11]
check('SSM tau 8000-10000', '8,000 to 10,000', taus,
      min(taus) == 8000 and max(taus) == 10000 and ('8,000 to 10,000' in paper or '8{,}000' in paper))
check('SSM r 0.16-0.27', '0.16-0.27', [round(min(rr), 2), round(max(e['max_r'] for e in e11), 2)],
      abs(min(rr) - 0.16) < 5e-3 and abs(max(e['max_r'] for e in e11) - 0.27) < 5e-3 and '0.16-0.27' in paper)

n_fail = sum(1 for c in checks if c[3] == 'FAIL')
print(f'verify_numbers: {len(checks) - n_fail}/{len(checks)} PASS')
for name, claim, comp, status in checks:
    if status == 'FAIL':
        print('FAIL:', name, claim, comp)
json.dump(dict(n=len(checks), n_fail=n_fail, checks=checks),
          open('../results/verify_numbers_report.json', 'w'), indent=1)
