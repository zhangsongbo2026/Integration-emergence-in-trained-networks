"""D2.1 v2.0 redesign: label-free geometry interventions on output-cloud
participation ratio (PR), a differentiable effective-dimension proxy.

arms: A0 none | A1 minimise PR (consolidation induction) |
      A2 maximise PR (fragmentation preservation) |
      A3 norm-matched random-projection control
Usage: python run_D21b.py <arm> <seed> [lam] [steps]
"""
import json, os, sys, time, gc
import numpy as np, torch, torch.nn.functional as F
from grok_core import make_data
from mlp_core import MLPModel, cloud_prep, two_nn_id, spectral_gap, h1_diagram

torch.set_num_threads(1)
p = 29
OUT = '../results'


def participation_ratio(Z):
    """PR = (sum lambda)^2 / sum lambda^2 of centred activations; scale-free."""
    Zc = Z - Z.mean(0, keepdim=True)
    s = torch.linalg.svdvals(Zc)
    return (s.sum() ** 2) / (s ** 2).sum()


def run(arm, seed, lam=0.05, steps=40000):
    m = MLPModel(p=p, seed=seed)
    Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
    opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=2.0)
    g = torch.Generator().manual_seed(seed)
    idx = torch.randperm(p, generator=g)[:10]   # fixed random 10-dim marginal
    traj, tau, v_final = [], None, 0.0
    t0 = time.time()
    for step in range(steps + 1):
        if step % 2000 == 0 or step == steps:
            m.eval()
            with torch.no_grad():
                lv, H = m(Xva)
                v = (lv.argmax(-1) == Yva).float().mean().item()
                lt, _ = m(Xtr)
                tr = (lt.argmax(-1) == Ytr).float().mean().item()
                Lc = cloud_prep(lv, max_points=300, seed=0)
                dgm = h1_diagram(Lc)
                psi = float((dgm[:, 1] - dgm[:, 0]).sum()) if len(dgm) else 0.0
                met = dict(step=step, val=v, train=tr, psi=psi,
                           pr=float(participation_ratio(lv).item()),
                           id=two_nn_id(Lc), sg=spectral_gap(Lc))
            m.train()
            traj.append(met)
            json.dump(dict(arm=arm, seed=seed, lam=lam, tau=tau,
                           final_val=v, steps_run=step, traj=traj),
                      open(f'{OUT}/D21b_{arm}_seed{seed}.json', 'w'))
            if tau is None and tr >= 0.995 and v >= 0.5:
                tau = step
            print(f'{arm} s{seed} st {step} val {v:.3f} sg {met["sg"]:.3f} '
                  f'pr {met["pr"]:.1f} psi {psi:.1f}', flush=True)
            if v >= 0.9 or (tau is not None and step - tau > 8000):
                v_final = v
                break
        if step == steps:
            v_final = v
            break
        lg, _ = m(Xtr)
        ce = F.cross_entropy(lg, Ytr)
        if arm == 'A0':
            loss = ce
        else:
            Z = lg[:, idx] if arm == 'A3' else lg
            pr = participation_ratio(Z)
            a = pr / p                                # scale-free
            if arm == 'A1':
                loss = ce + lam * a
            elif arm == 'A2':
                loss = ce - lam * a
            else:                                     # A3: same magnitude, random subspace
                loss = ce + lam * a
        opt.zero_grad(); loss.backward(); opt.step()
    rec = dict(arm=arm, seed=seed, lam=lam, tau=tau, final_val=v_final,
               steps_run=step, wall=time.time() - t0, traj=traj)
    tag = f'D21b_{arm}_seed{seed}'
    json.dump(rec, open(f'{OUT}/{tag}.json', 'w'))
    gc.collect()
    return rec


if __name__ == '__main__':
    arm = sys.argv[1]; seed = int(sys.argv[2])
    lam = float(sys.argv[3]) if len(sys.argv) > 3 else 0.05
    steps = int(sys.argv[4]) if len(sys.argv) > 4 else 40000
    run(arm, seed, lam, steps)
