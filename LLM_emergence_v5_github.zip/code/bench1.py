import time, numpy as np, torch, torch.nn.functional as F
from grok_core import AttnOnlyModel, make_data

t0 = time.time()
m = AttnOnlyModel()
Xtr, Ytr, Xva, Yva = make_data()
opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=1.0)
t0 = time.time()
for i in range(300):
    opt.zero_grad(); logits, _ = m(Xtr)
    loss = F.cross_entropy(logits, Ytr); loss.backward(); opt.step()
dt = time.time() - t0
print('train steps/sec:', round(300/dt, 1))
with torch.no_grad():
    lt, _ = m(Xtr); print('train acc', (lt.argmax(-1) == Ytr).float().mean().item())
    lv, _ = m(Xva); print('val acc', (lv.argmax(-1) == Yva).float().mean().item())

from ripser import ripser
with torch.no_grad():
    _, H = m(Xva)
Hc = H[:300, -1, :].numpy()
t0 = time.time()
D = 1.0 - (Hc @ Hc.T)
dgms = ripser(np.clip((D + D.T)/2, 0, 2), maxdim=1, distance_matrix=True)['dgms']
print('ripser time', round(time.time()-t0, 2), 'h1 features', len(dgms[1]))
