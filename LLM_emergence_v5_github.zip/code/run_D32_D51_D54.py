"""D3.2 surrogate registry calibration (family REG);
D5.1 edit reversibility audit (audit);
D5.4 alignment-proxy fine-tuning (align).
Usage: python run_D32_D51_D54.py reg <seed>
       python run_D32_D51_D54.py audit <seed>
       python run_D32_D51_D54.py align <seed>
"""
import json, os, sys, time, gc
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F
from grok_core import make_data
from mlp_core import MLPModel, cloud_prep, h1_diagram, two_nn_id, spectral_gap

torch.set_num_threads(1)
p = 29
OUT = '../results'
os.makedirs(OUT, exist_ok=True)


# ---------------------------------------------------------------- metrics
def participation_ratio(Z):
    Zc = Z - Z.mean(0, keepdims=True)
    s = torch.linalg.svdvals(Zc)
    return float((s.sum() ** 2) / (s ** 2).sum())


def stable_rank(Z):
    s = torch.linalg.svdvals(Z - Z.mean(0, keepdims=True))
    return float((s ** 2).sum() / (s.max() ** 2))


def effective_rank(Z):
    s = torch.linalg.svdvals(Z - Z.mean(0, keepdims=True))
    s = s / s.sum()
    return float(torch.exp(-(s * torch.log(s + 1e-12)).sum()))


def pca95_dim(Z):
    X = Z - Z.mean(0, keepdims=True)
    s = torch.linalg.svdvals(X) ** 2
    c = torch.cumsum(s, 0) / s.sum()
    return float((c < 0.95).sum().item() + 1)


def feature_rank(H, cls, p):
    from mlp_core import class_means
    M = class_means(H, cls, p)
    s = np.linalg.svd(M - M.mean(0, keepdims=True), compute_uv=False)
    return int((s > 1e-6 * s[0]).sum())


def knn_consistency(Z, cls, k=10):
    Zn = Z / (Z.norm(dim=1, keepdim=True) + 1e-9)
    S = Zn @ Zn.T
    S.fill_diagonal_(-2)
    idx = torch.topk(S, k, dim=1).indices
    agree = (cls[idx] == cls[:, None]).float().mean()
    return float(agree)


def silhouette(Z, cls, p):
    Zn = Z / (Z.norm(dim=1, keepdim=True) + 1e-9)
    D = 1 - Zn @ Zn.T
    sil = []
    for c in range(p):
        m = cls == c
        if m.sum() < 2:
            continue
        a = D[m][:, m].sum(1) / (m.sum() - 1)
        b = torch.stack([D[m][:, cls == o].mean(1) for o in range(p) if o != c], 1).min(1).values
        sil.append(((b - a) / torch.maximum(a, b)).mean())
    return float(torch.stack(sil).mean()) if sil else 0.0


def jacobian_rank(m, tokens, p, k=64):
    """Rank of the output Jacobian wrt the concatenated embeddings."""
    ea = m.ea(tokens[:, 0]).clone().requires_grad_(True)
    eb = m.eb(tokens[:, 1]).clone().requires_grad_(True)
    x = torch.cat([ea, eb], 1)
    h = F.relu(m.fc1(x)); lg = m.fc2(h)
    rows = []
    for c in range(p):
        g = torch.autograd.grad(lg[:, c].sum(), [ea, eb], retain_graph=True)
        rows.append(torch.cat([g[0], g[1]], 1).mean(0))
    J = torch.stack(rows)
    s = torch.linalg.svdvals(J)
    k_eff = int((s > 1e-3 * s[0]).sum())
    return k_eff


def linear_cka(A, B):
    A = A - A.mean(0, keepdims=True); B = B - B.mean(0, keepdims=True)
    num = (A.T @ B).pow(2).sum()
    den = (A.T @ A).norm() * (B.T @ B).norm()
    return float((num / den).item())


def all_metrics(m, Xva, Yva, cls, S, final_profile=None, timing=None):
    m.eval()
    with torch.no_grad():
        lv, H = m(Xva)
    out = {}
    def timed(name, fn):
        t0 = time.time(); v = fn(); dt = time.time() - t0
        out[name] = v
        if timing is not None:
            timing[name] = timing.get(name, 0.0) + dt
    timed('sg', lambda: spectral_gap(cloud_prep(lv, max_points=300, seed=0)))
    timed('id_twonn', lambda: two_nn_id(cloud_prep(lv, max_points=300, seed=0)))
    timed('pr', lambda: participation_ratio(lv))
    timed('stable_rank', lambda: stable_rank(lv))
    timed('eff_rank', lambda: effective_rank(lv))
    timed('pca95', lambda: pca95_dim(lv))
    timed('feature_rank', lambda: feature_rank(H, cls, p))
    timed('knn_consistency', lambda: knn_consistency(lv, cls))
    timed('silhouette', lambda: silhouette(lv, cls, p))
    timed('jac_rank', lambda: jacobian_rank(m, Xva[:64], p))
    Lc = cloud_prep(lv, max_points=300, seed=0)
    t0 = time.time(); dgm = h1_diagram(Lc); out['psi'] = float((dgm[:, 1] - dgm[:, 0]).sum()) if len(dgm) else 0.0
    if timing is not None:
        timing['psi'] = timing.get('psi', 0.0) + (time.time() - t0)
    # class profile for post-hoc CKA-to-final
    prof = []
    for c in range(p):
        mm = Yva == c
        prof.append(lv[mm].mean(0) if mm.any() else torch.zeros(p))
    out['profile'] = torch.stack(prof).numpy().tolist()
    if final_profile is not None:
        out['cka_to_final'] = linear_cka(torch.tensor(out['profile']),
                                         torch.tensor(final_profile))
    m.train()
    return out


# ---------------------------------------------------------------- REG family
def fam_REG(seed, steps=60000, every=5000):
    m = MLPModel(p=p, seed=seed)
    Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
    S = ((Xva[:, 0] + Xva[:, 1]) % p).numpy().astype(float)
    cls = Yva
    opt = torch.optim.AdamW(m.parameters(), lr=1e-3, weight_decay=2.0)
    timing, traj = {}, []
    final_profile = None
    for step in range(steps + 1):
        if step % every == 0 or step == steps:
            with torch.no_grad():
                lv, _ = m(Xva)
                v = (lv.argmax(-1) == Yva).float().mean().item()
            met = all_metrics(m, Xva, Yva, cls, S, final_profile, timing)
            met.update(step=step, val=v)
            traj.append(met)
            tmp = f'{OUT}/REG_seed{seed}.json.tmp'
            json.dump(dict(seed=seed, traj=traj, timing=timing), open(tmp, 'w'))
            os.replace(tmp, f'{OUT}/REG_seed{seed}.json')
            print(f'REG s{seed} st {step} val {v:.3f} psi {met["psi"]:.1f} '
                  f'sg {met["sg"]:.3f} fr {met["feature_rank"]}', flush=True)
        if step == steps:
            break
        opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
    gc.collect()


# ---------------------------------------------------------------- D5.1 audit
def audit(seed):
    m = MLPModel(p=p, seed=seed)
    m.load_state_dict(torch.load(f'{OUT}/X_weights_seed{seed}.pt'))
    Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
    def topo():
        with torch.no_grad():
            lv, H = m(Xva)
        return (spectral_gap(cloud_prep(lv, max_points=300, seed=0)),
                two_nn_id(cloud_prep(lv, max_points=300, seed=0)))
    sg0, id0 = topo()
    with torch.no_grad():
        lv, H = m(Xva)
    correct = (lv.argmax(-1) == Yva).nonzero().flatten()
    rng = np.random.default_rng(seed)
    sel = rng.choice(correct.numpy(), 8, replace=False)
    W0 = m.fc2.weight.detach().clone(); b0 = m.fc2.bias.detach().clone()
    rows = []
    for eps in [0.5, 1.0, 2.0, 4.0]:
        for idx in sel:
            idx = int(idx)
            true_c = int(Yva[idx]); tgt = int((true_c + 1 + rng.integers(0, p - 2)) % p)
            with torch.no_grad():
                _, h = m(Xva[idx:idx + 1])
            u = h[0] / (h[0].norm() + 1e-8)
            with torch.no_grad():
                m.fc2.weight[tgt] += eps * u; m.fc2.bias[tgt] += eps
                Lp, _ = m(Xva[idx:idx + 1])
                persist = int(Lp.argmax(-1)) == tgt
                sg1, id1 = topo()
            opt = torch.optim.AdamW(m.parameters(), lr=1e-4, weight_decay=2.0)
            for _ in range(400):
                opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
            with torch.no_grad():
                Lr, _ = m(Xva[idx:idx + 1])
                rebound = int(Lr.argmax(-1)) == true_c
            rows.append(dict(eps=eps, persist=bool(persist), rebound=bool(rebound),
                             sg_rel=(sg1 - sg0) / max(sg0, 1e-9),
                             id_rel=(id1 - id0) / max(id0, 1e-9)))
            with torch.no_grad():
                m.fc2.weight.copy_(W0); m.fc2.bias.copy_(b0)
        print(f'audit s{seed} eps {eps} done', flush=True)
        json.dump(dict(seed=seed, sg0=sg0, id0=id0, rows=rows),
                  open(f'{OUT}/AUDIT_seed{seed}.json', 'w'))
    gc.collect()


# ---------------------------------------------------------------- D5.4 align
def align(seed):
    m = MLPModel(p=p, seed=seed)
    m.load_state_dict(torch.load(f'{OUT}/X_weights_seed{seed}.pt'))
    Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
    def topo():
        with torch.no_grad():
            lv, _ = m(Xva)
        return (spectral_gap(cloud_prep(lv, max_points=300, seed=0)),
                two_nn_id(cloud_prep(lv, max_points=300, seed=0)),
                float((lv.argmax(-1) == Yva).float().mean().item()))
    sg0, id0, acc0 = topo()
    rng = np.random.default_rng(seed)
    W0 = {k: v.clone() for k, v in m.state_dict().items()}
    out = []
    for f in [0.02, 0.05, 0.10, 0.20]:
        m.load_state_dict(W0)
        n_flip = int(f * len(Xtr))
        fl = rng.choice(len(Xtr), n_flip, replace=False)
        Yflip = Ytr.clone(); Yflip[torch.tensor(fl)] = (Yflip[torch.tensor(fl)] + 1) % p
        opt = torch.optim.AdamW(m.parameters(), lr=1e-4, weight_decay=2.0)
        for _ in range(500):
            opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Yflip).backward(); opt.step()
        sg1, id1, acc1 = topo()
        rec = dict(f=f, acc_before=acc0, acc_after=acc1, damage=acc0 - acc1,
                   sg_before=sg0, sg_after=sg1, sg_rel=(sg1 - sg0) / max(sg0, 1e-9),
                   id_before=id0, id_after=id1, id_rel=(id1 - id0) / max(id0, 1e-9))
        out.append(rec)
        print(f'align s{seed} f {f} damage {rec["damage"]:.3f} sg_rel {rec["sg_rel"]:.2f}', flush=True)
        json.dump(dict(seed=seed, rows=out), open(f'{OUT}/ALIGN_seed{seed}.json', 'w'))
    gc.collect()


if __name__ == '__main__':
    mode, seed = sys.argv[1], int(sys.argv[2])
    if mode == 'reg':
        fam_REG(seed)
    elif mode == 'audit':
        audit(seed)
    elif mode == 'align':
        align(seed)
