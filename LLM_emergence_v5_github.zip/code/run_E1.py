"""E1: main grokking grid — full trajectories of the locked metric suite.
Usage: python run_E1.py seed0 seed1 ... (each seed ~2.5 min)
"""
import json, os, sys, time, gc
import numpy as np, torch, torch.nn.functional as F
from grok_core import make_data
from mlp_core import MLPModel, cloud_prep, h1_diagram, two_nn_id, spectral_gap

torch.set_num_threads(4)
p, lr, wd, steps = 29, 1e-3, 2.0, 60000
OUT = '../results'
os.makedirs(OUT, exist_ok=True)


def metrics_for(m, Xva, S, cls):
    m.eval()
    with torch.no_grad():
        L, H = m(Xva)
    Lv = L.numpy()
    # psi1 on logit cloud
    Lc = cloud_prep(L, max_points=300, seed=0)
    t_ph = time.time()
    dgm = h1_diagram(Lc)
    t_ph = time.time() - t_ph
    pers = dgm[:, 1] - dgm[:, 0] if len(dgm) else np.array([0.0])
    # cycle alignment r (logit and hidden)
    def cyc(Z):
        Z = Z - Z.mean(0, keepdims=True)
        rng = np.random.default_rng(0)
        n = len(Z)
        i = rng.integers(0, n, 20000); j = rng.integers(0, n, 20000)
        k = i != j; i, j = i[k], j[k]
        Zn = Z / (np.linalg.norm(Z, axis=1, keepdims=True) + 1e-12)
        A = (Zn[i] * Zn[j]).sum(1)
        d = np.abs(S[i] - S[j]); d = np.minimum(d, p - d)
        B = np.cos(2 * np.pi * d / p)
        return float(np.corrcoef(A, B)[0, 1])
    Hn = H.numpy()
    Hc = cloud_prep(H, max_points=300, seed=0)
    t_id = time.time()
    idv = two_nn_id(Lc); sgv = spectral_gap(Lc)
    t_id = time.time() - t_id
    # class profile matrix (p x p): mean logit over prompts of class s
    P = np.stack([Lv[cls == s].mean(0) if (cls == s).any() else np.zeros(p)
                  for s in range(p)])
    out = dict(psi=float(pers.sum()), psi_top3=float(np.sort(pers)[-3:].sum()),
               n_feat=int(len(pers)), r_logit=cyc(Lv), r_hidden=cyc(Hn),
               id=idv, sg=sgv, sparsity=float((np.abs(Hn) < 1e-3).mean()),
               t_ph=t_ph, t_id=t_id, profile=P.tolist())
    m.train()
    return out


def run_seed(seed):
    m = MLPModel(p=p, seed=seed)
    Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
    S = ((Xva[:, 0] + Xva[:, 1]) % p).numpy().astype(float)
    cls = Yva.numpy()
    opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=wd)
    traj = []
    t0 = time.time()
    for step in range(steps + 1):
        if step % 2000 == 0 or step == steps:
            with torch.no_grad():
                lv, _ = m(Xva); v = (lv.argmax(-1) == Yva).float().mean().item()
                lt, _ = m(Xtr); tr = (lt.argmax(-1) == Ytr).float().mean().item()
            met = metrics_for(m, Xva, S, cls)
            met.update(step=step, train_acc=tr, val_acc=v)
            traj.append(met)
            print(f'seed {seed} st {step} val {v:.2f} r {met["r_logit"]:.3f} '
                  f'psi {met["psi"]:.1f} id {met["id"]:.1f} sg {met["sg"]:.3f}', flush=True)
        if step == steps:
            break
        opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
    # save final weights for E3/E4 reuse
    torch.save(m.state_dict(), f'{OUT}/E1_weights_seed{seed}.pt')
    json.dump(dict(seed=seed, traj=traj, wall=time.time() - t0,
                   cfg=dict(p=p, lr=lr, wd=wd, steps=steps, d=128, dh=100)),
              open(f'{OUT}/E1_seed{seed}.json', 'w'))
    gc.collect()


if __name__ == '__main__':
    for s in sys.argv[1:]:
        run_seed(int(s))
