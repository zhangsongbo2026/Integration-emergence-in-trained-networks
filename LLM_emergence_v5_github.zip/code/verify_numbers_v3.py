"""verify_numbers_v3: cross-check every quantitative claim in the V3 paper
against the released analysis records."""
import json, re

paper = open('../paper/Llm_emergence_v3.md').read()
A3 = json.load(open('../results/analysis_v3.json'))
A2 = json.load(open('../results/analysis_summary.json'))
checks = []


def chk(name, claim, ok):
    checks.append((name, claim, 'PASS' if ok else 'FAIL'))


def inpaper(s):
    return s in paper


# ---------------- V3: causal intervention
d = A3['D21']['A1_minus_A3']
chk('D2.1 delta 0.277', 'A1-A3', abs(d['delta'] - 0.277) < 5e-3 and inpaper('0.277'))
chk('D2.1 CI low 0.197', '0.197', abs(d['ci'][0] - 0.197) < 5e-3 and inpaper('0.197'))
chk('D2.1 CI high 0.374', '0.374', abs(d['ci'][1] - 0.374) < 5e-3 and inpaper('0.374'))
for arm, val in [('A0', 0.822), ('A1', 0.942), ('A2', 0.671), ('A3', 0.665)]:
    m = A3['D21']['arms'][arm]['val_mean']
    chk(f'D2.1 {arm} mean {val}', f'{val}', abs(m - val) < 2e-3 and inpaper(f'{val}'))

# ---------------- V3: 32-seed grid
g = A3['D25']
chk('D2.5 n=32', '32 seeds', g['n_seeds'] == 32)
chk('D2.5 mean val 0.929', '0.929', abs(g['val_mean'] - 0.929) < 2e-3 and inpaper('0.929'))
chk('D2.5 rho psi -0.936', '-0.936', abs(g['rho_psi_val'] + 0.936) < 2e-3 and inpaper('-0.936'))
chk('D2.5 rho sg -0.911', '-0.911', abs(g['rho_sg_val'] + 0.911) < 2e-3 and inpaper('-0.911'))
chk('D2.5 rho id -0.855', '-0.855', abs(g['rho_id_val'] + 0.855) < 2e-3 and inpaper('-0.855'))
chk('D2.5 psi collapse 1.95', '1.95', abs(g['median_psi_drop'] - 1.95) < 1e-2 and inpaper('1.95'))
chk('D2.5 sg collapse 8.2', '8.2', abs(g['median_sg_drop'] - 8.2) < 0.05 and inpaper('8.2'))
pc = g['power_for_delta015']
chk('D2.5 power n8 0.93', '0.93', abs(pc['8'] - 0.93) < 1e-2 and inpaper('0.93'))
chk('D2.5 power n4 0.56', '0.56', abs(pc['4'] - 0.56) < 1e-2 and inpaper('0.56'))
chk('D2.5 HDI low 0.905', '0.905', abs(g['bayes_hdi_mean_val'][0] - 0.905) < 5e-3 and inpaper('0.905'))

# ---------------- V3: cross-architecture
a = A3['D23']['robust']
chk('D2.3 rwkv 0.987', '0.987', abs(a['rwkv']['val_mean'] - 0.987) < 2e-3 and inpaper('0.987'))
chk('D2.3 ssm 0.932', '0.932', abs(a['ssm']['val_mean'] - 0.932) < 2e-3 and inpaper('0.932'))
chk('D2.3 retnet 0.919', '0.919', abs(a['retnet']['val_mean'] - 0.919) < 2e-3 and inpaper('0.919'))
chk('D2.3 rwkv gap 0.129->0.009', '0.129', abs(a['rwkv']['sg_early_median'] - 0.129) < 2e-3
    and abs(a['rwkv']['sg_final_median'] - 0.009) < 2e-3 and inpaper('0.129 to 0.009'))
chk('D2.3 ssm gap 0.150->0.028', '0.150', abs(a['ssm']['sg_early_median'] - 0.150) < 2e-3
    and abs(a['ssm']['sg_final_median'] - 0.028) < 2e-3 and inpaper('0.150 to 0.028'))
chk('D2.3 min 0.900', '0.900', abs(min(a[k]['val_min'] for k in a) - 0.900) < 2e-3)

# ---------------- V3: MSL
ms = A3['D22']['seeds']
chk('D2.2 onsets 2000 easy', '2,000',
    ms['0']['onsets']['2'] == 2000 and ms['0']['onsets']['3'] == 2000 and inpaper('2,000'))
chk('D2.2 hard final 0.40', '0.40',
    abs(ms['0']['final_per']['0'] - 0.40) < 0.02 and inpaper('0.40'))
chk('D2.2 final sg 0.208', '0.208', abs(ms['0']['sg_final'] - 0.208) < 5e-3 and inpaper('0.208'))

# ---------------- V3: metric definitions
m4 = A3['D41b']
chk('D4.1 onset exact 14250', '14,250', abs(m4['mean_onsets']['onset_exact'] - 14250) < 1
    and inpaper('14,250'))
chk('D4.1 onset m1 18250', '18,250', abs(m4['mean_onsets']['onset_m1'] - 18250) < 1
    and inpaper('18,250'))
chk('D4.1 spread 4000', '4,000', abs(m4['metric_onset_spread_mean'] - 4000) < 1 and inpaper('4,000'))
chk('D4.1 sg onset 29500', '29,500', abs(m4['mean_onsets']['sg_onset'] - 29500) < 1 and inpaper('29,500'))
chk('D4.1 terminal stability (0.05/0.09)', '0.05 and 0.09',
    inpaper('0.05 and 0.09'))

# ---------------- V3: ordering (E7 + CIR)
chk('D4.2 births mean 8078', '8,078', abs(A2['E7']['mean_birth'] - 8078) < 1 and inpaper('8,078'))
cir = [c for c in A3['D42']['seeds'] if c['base_acc']]
chk('D4.2 critical sensitivity 0.20', '0.20',
    cir and abs(cir[0]['crit_sensitivity'] - 0.2019) < 5e-3 and inpaper('0.20'))

# ---------------- V3: registry
reg = A3['D32']['registry']
chk('D3.2 sg 0.966', '0.966', abs(reg['sg']['rho_psi'] - 0.966) < 2e-3 and inpaper('0.966'))
chk('D3.2 pr 0.948', '0.948', abs(reg['pr']['rho_psi'] - 0.948) < 2e-3 and inpaper('0.948'))
chk('D3.2 eff rank 0.940', '0.940', abs(reg['eff_rank']['rho_psi'] - 0.940) < 2e-3 and inpaper('0.940'))
chk('D3.2 pca95 0.911', '0.911', abs(reg['pca95']['rho_psi'] - 0.911) < 2e-3 and inpaper('0.911'))
chk('D3.2 id 0.908', '0.908', abs(reg['id_twonn']['rho_psi'] - 0.908) < 2e-3 and inpaper('0.908'))
chk('D3.2 stable rank 0.822', '0.822', abs(reg['stable_rank']['rho_psi'] - 0.822) < 2e-3 and inpaper('0.822'))
chk('D3.2 knn -0.762', '-0.762', abs(reg['knn_consistency']['rho_psi'] + 0.762) < 2e-3 and inpaper('-0.762'))
chk('D3.2 cka -0.497/0.862', '-0.497',
    abs(A3['D32b']['cka_rho_psi'] + 0.497) < 2e-3 and abs(A3['D32b']['cka_rho_val'] - 0.862) < 2e-3
    and inpaper('-0.497') and inpaper('0.862'))
chk('D3.2 speedup sg 25x', '25', abs(A3['D32b']['speedup_sg'] - 24.87) < 0.02 and inpaper('25'))
chk('D3.2 speedup pr 572x', '572', abs(A3['D32b']['speedup_pr'] - 572.3) < 0.5 and inpaper('572'))
chk('D3.2 speedup eff 911x', '911', abs(A3['D32b']['speedup_eff'] - 911.0) < 0.5 and inpaper('911'))
chk('D3.2 checkpoints 67', '67', A3['D32']['n_checkpoints'] == 67 and inpaper('67 matched checkpoints'))

# ---------------- V3: audit and alignment
au = A3['D51']
chk('D5.1 persist 0.25', '0.25', abs(au['persist_by_eps']['0.5'] - 0.25) < 2e-2 and inpaper('0.25'))
chk('D5.1 rebound 0.53', '0.53', abs(au['rebound_by_eps']['1.0'] - 0.53) < 2e-2 and inpaper('0.53'))
chk('D5.1 rule 0.71', '0.71', abs(A3['D51b']['best_rule']['bal_acc'] - 0.708) < 5e-3 and inpaper('0.71'))
al = A3['D54']['damage_by_f']
chk('D5.4 damage 0.054', '0.054', abs(al['0.02'] - 0.054) < 2e-3 and inpaper('0.054'))
chk('D5.4 damage 0.235', '0.235', abs(al['0.2'] - 0.235) < 2e-3 and inpaper('0.235'))
chk('D5.4 rho -0.17', '-0.17', abs(A3['D54']['rho_damage_sg_delta'] + 0.17) < 5e-3 and inpaper('-0.17'))

# ---------------- V3: early stop
es = A3['D53b']
chk('D5.3 saved 34%', '34%', abs(es['mean_saved'] - 0.34) < 0.02 and inpaper('34%'))
chk('D5.3 gap 0.016', '0.016', abs(es['mean_gap'] - 0.016) < 2e-3 and inpaper('0.016'))
chk('D5.3 worst 0.095', '0.095', abs(es['max_gap'] - 0.095) < 5e-3 and inpaper('0.095'))

# ---------------- V2 legacy claims still in the V3 text
st = A2['E1_stats']
chk('V2 rho psi val -0.994 (V2 sections)', '-0.994', inpaper('-0.994'))
chk('V2 arrhenius R2 0.978', '0.978', inpaper('0.978'))
chk('V2 density 1.43/0.997', '1.43', inpaper('1.43') and inpaper('0.997'))
chk('V2 E5 p=0.84', '0.84', inpaper('0.84'))
chk('V2 audit eps window', '0.5, 2.0', inpaper('[0.5, 2.0]'))

# ---------------- structure checks
chk('54 references', '54 refs', len(re.findall(r'^\[\d+\] ', paper, re.M)) == 54)
figs = re.findall(r'\]\((figures/fig[^)]+)\)', paper)
chk('19 figures embedded', '19 figs', len(figs) == 19)
chk('new figures 12-19 present', 'fig12-19',
    all(f'fig{n}_' in paper for n in range(12, 20)))
chk('display math blocks present', 'display math', paper.count('$$') >= 8)

n_fail = sum(1 for c in checks if c[2] == 'FAIL')
print(f'verify_numbers_v3: {len(checks) - n_fail}/{len(checks)} PASS')
for name, claim, status in checks:
    if status == 'FAIL':
        print('FAIL:', name, '|', claim)
json.dump(dict(n=len(checks), n_fail=n_fail, checks=checks),
          open('../results/verify_numbers_v3_report.json', 'w'), indent=1)
