"""Check: is the grokked MLP solution Fourier? R^2 of task-mode regression."""
import numpy as np, torch, torch.nn.functional as F, json
from grok_core import make_data
from mlp_core import MLPModel

p, lr, wd, steps, seed = 29, 1e-3, 2.0, 60000, 0
m = MLPModel(p=p, seed=seed)
Xtr, Ytr, Xva, Yva = make_data(p, 0.5, seed)
opt = torch.optim.AdamW(m.parameters(), lr=lr, weight_decay=wd)

def design(p):
    """Fourier task-mode design: cos/sin(w_k(a+b-c)) and cos/sin(w_k(a-b))."""
    a, b, c = np.meshgrid(np.arange(p), np.arange(p), np.arange(p), indexing='ij')
    a, b, c = a.ravel(), b.ravel(), c.ravel()
    cols = [np.ones_like(a, dtype=float)]
    for k in range(1, p):
        w = 2 * np.pi * k / p
        u = w * (a + b - c); v = w * (a - b)
        cols += [np.cos(u), np.sin(u), np.cos(v), np.sin(v)]
    return np.stack(cols, 1), (a, b, c)

D, (a, b, c) = design(p)
idx = {(int(x), int(y)): i for i, (x, y) in enumerate(zip(a, b))}

def r_four():
    m.eval()
    with torch.no_grad():
        L, _ = m(Xva)                    # (n_val, p)
    L = L.numpy()
    rows = [idx[(int(x), int(y))] for x, y in Xva.numpy()]
    y = L.reshape(-1)
    Dm = np.repeat(D[rows], p, axis=0)   # each val row -> p output classes
    # ridge regression R^2
    Dm = Dm / np.linalg.norm(Dm, axis=0, keepdims=True).clip(1e-9)
    beta, *_ = np.linalg.lstsq(Dm, y, rcond=None)
    pred = Dm @ beta
    ss = 1 - ((y - pred) ** 2).sum() / ((y - y.mean()) ** 2).sum()
    return float(ss)

traj = []
for step in range(steps + 1):
    if step % 2000 == 0 or step == steps:
        with torch.no_grad():
            lv, _ = m(Xva); v = (lv.argmax(-1) == Yva).float().mean().item()
        r = r_four()
        traj.append(dict(step=step, val=v, r_four=r))
        print(f'st {step} val {v:.2f} R2_fourier {r:.3f}', flush=True)
    if step == steps:
        break
    opt.zero_grad(); lg, _ = m(Xtr); F.cross_entropy(lg, Ytr).backward(); opt.step()
json.dump(traj, open('calib_mlp5_seed0.json', 'w'))
