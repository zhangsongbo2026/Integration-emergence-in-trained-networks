"""V3 figures (12 new panels/figures)."""
import json, glob
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# --- vector export: every PNG also written as PDF ---
import matplotlib.figure as _mf
_orig_savefig = _mf.Figure.savefig
def _savefig_both(self, fname, **kw):
    _orig_savefig(self, fname, **kw)
    s = str(fname)
    if s.endswith('.png'):
        _orig_savefig(self, s[:-4] + '.pdf', **kw)
_mf.Figure.savefig = _savefig_both

from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

C = ['#0072B2', '#D55E00', '#009E73', '#CC79A7', '#E69F00', '#56B4E9', '#333333']
plt.rcParams.update({'font.size': 7.5, 'axes.titlesize': 8, 'axes.labelsize': 7.5,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'figure.dpi': 300, 'savefig.dpi': 300, 'legend.frameon': False,
                     'xtick.labelsize': 7, 'ytick.labelsize': 7, 'lines.linewidth': 1.2})
F = '../figures'
R = json.load(open('../results/analysis_v3.json'))


def load(pat):
    out = []
    for f in sorted(glob.glob(f'../results/{pat}')):
        try:
            out.append(json.load(open(f)))
        except Exception:
            pass
    return out


def panel_label(ax, s):
    ax.text(-0.14, 1.06, s, transform=ax.transAxes, fontsize=10, fontweight='bold', va='top')


# ---------------- Fig 12: causal intervention
fig, axes = plt.subplots(1, 2, figsize=(6.8, 2.6))
ax = axes[0]
arms = ['A0', 'A1', 'A2', 'A3']
labels = ['baseline\n(A0)', 'consolidation\ninduction (A1)', 'fragmentation\npreserved (A2)', 'random-marginal\ncontrol (A3)']
vals = [R['D21']['arms'][a]['val_list'] for a in arms]
for i, (a, v) in enumerate(zip(arms, vals)):
    ax.scatter(np.full(len(v), i) + np.random.default_rng(i).normal(0, 0.06, len(v)), v,
               color=C[i], s=16, alpha=0.85)
    ax.plot([i - 0.25, i + 0.25], [np.mean(v)] * 2, color=C[i], lw=2)
ax.set_xticks(range(4)); ax.set_xticklabels(labels, fontsize=6.2)
ax.set_ylabel('final validation accuracy')
d = R['D21']['A1_minus_A3']
ax.set_title(rf"$\Delta(A1-A3) = {d['delta']:.3f}$  CI [{d['ci'][0]:.3f}, {d['ci'][1]:.3f}]")
panel_label(ax, 'a')
ax = axes[1]
for a, col in zip(arms, [C[6], C[0], C[1], C[4]]):
    ds = load(f'D21b_{a}_seed*.json')
    n = min(len(dd['traj']) for dd in ds)
    st_ = np.mean([[t['sg'] for t in dd['traj'][:n]] for dd in ds], axis=0)
    ax.plot(range(len(st_)), st_, color=col, label=a)
ax.set_xlabel('probe index (every 2000 steps)')
ax.set_ylabel('mean spectral gap')
ax.legend(fontsize=6.5)
ax.set_title('Interventions move the geometry target')
panel_label(ax, 'b')
fig.tight_layout(); fig.savefig(f'{F}/fig12_D21_intervention.png', bbox_inches='tight'); plt.close(fig)

# ---------------- Fig 13: 32-seed grid
fin = R['D25']['final_states']
v = np.array([f['val'] for f in fin]); ps = np.array([f['psi'] for f in fin])
sg = np.array([f['sg'] for f in fin]); rr = np.array([f['r'] for f in fin])
fig, axes = plt.subplots(1, 3, figsize=(6.8, 2.3))
ax = axes[0]
ax.scatter(v, ps, color=C[0], s=15)
ax.set_xlabel('final val accuracy'); ax.set_ylabel(r'final $\Psi_1$')
ax.set_title(rf"$\rho={R['D25']['rho_psi_val']:.2f}$ (n=32)")
panel_label(ax, 'a')
ax = axes[1]
ax.scatter(v, sg, color=C[2], s=15)
ax.set_xlabel('final val accuracy'); ax.set_ylabel('final spectral gap')
ax.set_title(rf"$\rho={R['D25']['rho_sg_val']:.2f}$")
panel_label(ax, 'b')
ax = axes[2]
pc = R['D25']['power_for_delta015']
ns = [int(k) for k in pc]
ax.plot(ns, [pc[str(n)] for n in ns], 'o-', color=C[3])
ax.axhline(0.8, color=C[6], ls=':', lw=1)
ax.set_xscale('log'); ax.set_xlabel('seeds per arm'); ax.set_ylabel('power ($\\Delta$=0.15)')
ax.set_title('Power analysis (32-seed grid)')
panel_label(ax, 'c')
fig.tight_layout(); fig.savefig(f'{F}/fig13_D25_grid32.png', bbox_inches='tight'); plt.close(fig)

# ---------------- Fig 14: cross-architecture
fig, ax = plt.subplots(figsize=(3.6, 2.6))
names = ['retnet', 'rwkv', 'ssm']
for i, n in enumerate(names):
    ds = load(f'ARCH_{n}_seed*.json')
    s0 = [d['traj'][0]['sg'] for d in ds]; s1 = [d['traj'][-1]['sg'] for d in ds]
    for a, b in zip(s0, s1):
        ax.plot([i - 0.2, i + 0.2], [a, b], color=C[i], alpha=0.6, lw=1)
    ax.scatter([i] * len(s1), s1, color=C[i], s=14, zorder=3)
ax.set_xticks(range(3)); ax.set_xticklabels([f'{n}\n(n=8)' for n in names])
ax.set_ylabel('spectral gap (early $\\to$ final)')
ax.set_title('Cross-architecture consolidation')
panel_label(ax, '')
fig.tight_layout(); fig.savefig(f'{F}/fig14_D23_architecture.png', bbox_inches='tight'); plt.close(fig)

# ---------------- Fig 15: surrogate registry
reg = R['D32']['registry']
items = [(k, v) for k, v in reg.items() if k != 'psi' and v['rho_psi'] == v['rho_psi']]
items.sort(key=lambda x: abs(x[1]['rho_psi']), reverse=True)
fig, axes = plt.subplots(1, 2, figsize=(6.8, 2.5))
ax = axes[0]
names = [k for k, _ in items]; rhos = [abs(v['rho_psi']) for _, v in items]
cols = [C[2] if v['verdict'] == 'approved' else (C[4] if v['verdict'] == 'provisional' else C[6]) for _, v in items]
ax.barh(range(len(names)), rhos, color=cols)
ax.axvline(0.9, color=C[0], ls=':'); ax.axvline(0.7, color=C[6], ls=':')
ax.set_yticks(range(len(names))); ax.set_yticklabels(names, fontsize=6.5)
ax.invert_yaxis(); ax.set_xlabel(r'$|\rho|$ with $\Psi_1$ (66 checkpoints)')
ax.set_title('Surrogate registry')
panel_label(ax, 'a')
ax = axes[1]
sp = [(k, v['speedup_vs_psi']) for k, v in items if v.get('speedup_vs_psi')]
sp.sort(key=lambda x: x[1], reverse=True)
ax.barh(range(len(sp)), [s for _, s in sp], color=C[5])
ax.set_yticks(range(len(sp))); ax.set_yticklabels([k for k, _ in sp], fontsize=6.5)
ax.invert_yaxis(); ax.set_xscale('log')
ax.axvline(10, color=C[6], ls=':')
ax.set_xlabel(r'speed-up vs $\Psi_1$ (log)')
ax.set_title('Computational cost')
panel_label(ax, 'b')
fig.tight_layout(); fig.savefig(f'{F}/fig15_D32_registry.png', bbox_inches='tight'); plt.close(fig)

# ---------------- Fig 16: metric definitions (mirage) + alignment + audit
fig, axes = plt.subplots(1, 3, figsize=(6.8, 2.4))
ax = axes[0]
met = load('MET_seed*.json')
for d in met:
    tr = d['traj']
    st_ = [t['step'] for t in tr]
    ax.plot(st_, [t['acc_exact'] for t in tr], color=C[0], alpha=0.8)
    ax.plot(st_, [t['acc_m1'] for t in tr], color=C[1], alpha=0.8)
    ax.plot(st_, [t['cont'] for t in tr], color=C[2], alpha=0.8)
ax.set_xlabel('step'); ax.set_ylabel('capability')
ax.set_title('Metric definitions (trace)')
panel_label(ax, 'a')
ax = axes[1]
al = R['D54']['damage_by_f']
fs = sorted(float(k) for k in al)
ax.plot(fs, [al[str(f)] for f in fs], 'o-', color=C[3])
ax.set_xlabel('flipped label fraction')
ax.set_ylabel('behavioural damage')
ax.set_title('Alignment proxy (D5.4)')
panel_label(ax, 'b')
ax = axes[2]
scan = R['D51b']['threshold_scan']
ax.plot([s['thr'] for s in scan], [s['bal_acc'] for s in scan], color=C[4])
ax.axhline(0.8, color=C[6], ls=':')
ax.set_xlabel(r'spectral-gap-return threshold')
ax.set_ylabel('balanced accuracy')
ax.set_title('Audit proxy (weak: 0.71)')
panel_label(ax, 'c')
fig.tight_layout(); fig.savefig(f'{F}/fig16_D41_D54_D51.png', bbox_inches='tight'); plt.close(fig)

# ---------------- Fig 17: early-stop + MSL + width
fig, axes = plt.subplots(1, 3, figsize=(6.8, 2.4))
ax = axes[0]
cs = R['D53b']['cases']
ax.scatter([c['saved_frac'] for c in cs], [c['end_val'] - c['stop_val'] for c in cs], color=C[0], s=16)
ax.axhline(0.05, color=C[1], ls=':', lw=1)
ax.set_xlabel('fraction of budget saved'); ax.set_ylabel('accuracy gap at stop')
ax.set_title(rf"Topology early stop (saves {R['D53b']['mean_saved']:.0%})")
panel_label(ax, 'a')
ax = axes[1]
msl = load('MSL_seed*.json')
for d in msl:
    tr = d['traj']
    for sid, col in zip([0, 1, 2, 3], [C[0], C[1], C[2], C[5]]):
        ax.plot([t['step'] for t in tr], [t['per'][str(sid)] for t in tr], color=col, alpha=0.8)
ax.set_xlabel('step'); ax.set_ylabel('per-skill accuracy')
ax.set_title('Multi-skill onsets (L2 proxy)')
panel_label(ax, 'b')
ax = axes[2]
wd = R['D43']['widths']
ws = sorted(int(k) for k in wd)
ax.plot(ws, [wd[str(w)]['onset_mean'] for w in ws], 'o-', color=C[3], label='onset')
ax.set_xscale('log'); ax.set_xlabel('hidden width'); ax.set_ylabel('mean onset step')
ax.set_title('Width scaling (n=3, provisional)')
panel_label(ax, 'c')
fig.tight_layout(); fig.savefig(f'{F}/fig17_D53_D22_D43.png', bbox_inches='tight'); plt.close(fig)

# ---------------- Fig 18: conceptual schematic (dedicated canvas)
fig, ax = plt.subplots(figsize=(6.8, 3.2))
ax.axis('off')
boxes = [
    (0.02, 0.62, 'Memorisation phase\nfragmented output geometry\n$\\Psi_1$ high, gap high, ID high\ncapability low',
     '#FDE9D9'),
    (0.36, 0.62, 'Transition window\ncapability rises first\n(metrically fragile onset)',
     '#E7F2FB'),
    (0.70, 0.62, 'Consolidated phase\nsmooth low-dim manifold\n$\\Psi_1$ low, gap low, ID low\ncapability high',
     '#E1F2E4'),
]
for x, y, txt, col in boxes:
    ax.add_patch(FancyBboxPatch((x, y - 0.22), 0.28, 0.44, boxstyle='round,pad=0.02',
                                linewidth=0.8, edgecolor='#555555', facecolor=col))
    ax.text(x + 0.14, y, txt, ha='center', va='center', fontsize=6.8)
for x0, x1 in [(0.30, 0.36), (0.64, 0.70)]:
    ax.add_patch(FancyArrowPatch((x0, 0.62), (x1, 0.62), arrowstyle='-|>',
                                 mutation_scale=9, color='#333333'))
ax.text(0.5, 0.26, 'Causal test (D2.1): forcing consolidation (A1) raises capability '
                   r'($\Delta=0.277$, CI [0.197, 0.374]);\npreserving fragmentation (A2) '
                   'lowers it ($\\Delta<0$); matched random-marginal pressure (A3) does neither.',
        ha='center', fontsize=7)
ax.text(0.5, 0.05, 'Natural ordering (D4.1): capability onset precedes consolidation completion; '
                   'consolidation is a completed-transition marker,\nand a causal lever when forced.',
        ha='center', fontsize=7, style='italic')
ax.set_xlim(0, 1); ax.set_ylim(0, 1)
fig.savefig(f'{F}/fig18_concept_consolidation.png', bbox_inches='tight'); plt.close(fig)

# ---------------- Fig 19: audit decision flowchart
fig, ax = plt.subplots(figsize=(5.6, 3.0))
ax.axis('off')
steps = [
    (0.5, 0.90, 'Train to consolidation; record baseline\n$\\Psi_1$/$s_g$, ID'),
    (0.5, 0.66, 'Apply the edit (rank-one / ROME-family)'),
    (0.5, 0.42, 'Probe 400-step light fine-tune on clean data'),
    (0.5, 0.18, 'Outcome: edited fact returns ($\\to$ recoverable) or persists ($\\to$ collapsed)'),
]
for x, y, txt in steps:
    ax.add_patch(FancyBboxPatch((x - 0.30, y - 0.075), 0.60, 0.15, boxstyle='round,pad=0.01',
                                linewidth=0.8, edgecolor='#555555', facecolor='#F2F7FB'))
    ax.text(x, y, txt, ha='center', va='center', fontsize=6.8)
for y0, y1 in [(0.825, 0.735), (0.585, 0.495), (0.345, 0.255)]:
    ax.add_patch(FancyArrowPatch((0.5, y0), (0.5, y1), arrowstyle='-|>', mutation_scale=9, color='#333333'))
ax.text(0.5, 0.02, 'Cheap topological proxy rejected: $s_g$-return reaches only 0.71 balanced accuracy;\n'
                   'direct rebound probing is the validated criterion (D5.1).',
        ha='center', fontsize=6.8, color=C[1])
ax.set_xlim(0, 1); ax.set_ylim(0, 1)
fig.savefig(f'{F}/fig19_audit_flowchart.png', bbox_inches='tight'); plt.close(fig)

print('V3 figures done')
