"""V5 analysis: scale ladder, integration index vs capability, patching merge."""
import json, glob
import numpy as np
from scipy import stats as st

OUT = '../results'
R = {}
extras = json.load(open(f'{OUT}/analysis_v5_extras.json'))

# ---------------- scale ladder
runs = {}
for f in glob.glob(f'{OUT}/L2_L*_s*.json'):
    d = json.load(open(f))
    runs.setdefault(d['n_layer'], []).append(d)
L = {}
for n_layer, ds in sorted(runs.items()):
    finals = [d['traj'][-1] for d in ds]
    lams = [[t['lam'] for t in d['traj']] for d in ds]
    accs = [[t['acc'] for t in d['traj']] for d in ds]
    sgs = [[t['sg'] for t in d['traj']] for d in ds]
    L[n_layer] = dict(n=len(ds),
                      acc_final=float(np.mean([f['acc'] for f in finals])),
                      acc_all=[float(f['acc']) for f in finals],
                      lam_final=float(np.nanmean([f['lam'] for f in finals])) if n_layer > 2 else None,
                      lam_traj=[float(np.nanmean([l[i] for l in lams])) if n_layer > 2 else None
                                for i in range(min(len(x) for x in lams))],
                      acc_traj=[float(np.mean([a[i] for a in accs])) for i in range(min(len(x) for x in accs))],
                      sg_traj=[float(np.mean([s[i] for s in sgs])) for i in range(min(len(x) for x in sgs))],
                      acc_onset=next((i * 250 for i, a in enumerate(
                          [np.mean([x[i] for x in accs]) for i in range(min(len(z) for z in accs))])
                          if a >= 0.5), None))
R['ladder'] = L

# ---------------- Lambda vs capability within runs
rows = []
for f in glob.glob(f'{OUT}/L2_L*_s*.json'):
    d = json.load(open(f))
    for t in d['traj']:
        if t['lam'] == t['lam']:
            rows.append(dict(n_layer=d['n_layer'], seed=d['seed'], step=t['step'],
                             acc=t['acc'], lam=t['lam'], sg=t['sg'], pr=t['pr']))
lam = np.array([r['lam'] for r in rows]); acc = np.array([r['acc'] for r in rows])
sgv = np.array([r['sg'] for r in rows]); prv = np.array([r['pr'] for r in rows])
R['integration'] = dict(n_probes=len(rows),
                        rho_lam_acc=float(st.spearmanr(lam, acc).statistic),
                        rho_sg_acc=float(st.spearmanr(sgv, acc).statistic),
                        rho_pr_acc=float(st.spearmanr(prv, acc).statistic),
                        rho_lam_sg=float(st.spearmanr(lam, sgv).statistic),
                        partial_lam_acc_given_sg=float(
                            (st.pearsonr(lam, acc).statistic -
                             st.pearsonr(lam, sgv).statistic * st.pearsonr(sgv, acc).statistic) /
                            np.sqrt((1 - st.pearsonr(lam, sgv).statistic ** 2) *
                                    (1 - st.pearsonr(sgv, acc).statistic ** 2) + 1e-12)))

# ---------------- Phi* across resolutions (granularity-free scalar)
R['phi_star'] = extras['phi_star']
R['patching'] = extras['patching']
R['kimura'] = extras['kimura']
R['sparse_graph'] = extras['sparse_graph']
R['msl_link'] = extras['msl_link']

# ---------------- cross-layer probe asset from the sibling programme
R['sibling_probe'] = dict(
    source='neural topological periodic-law programme (cross-layer two-probe)',
    finding='topology changes (beta1 109 -> 43, modularity 0.275 -> 0.397) without '
            'generalisation (accuracy 0-2% throughout)',
    implication='topological change does not entail generalisation; sufficiency is false')

json.dump(R, open(f'{OUT}/analysis_v5.json', 'w'), indent=1, default=str)
print('ladder:', {k: (v['n'], round(v['acc_final'], 3), v['lam_final'] and round(v['lam_final'], 3),
                       v['acc_onset']) for k, v in L.items()})
print('integration:', {k: round(v, 3) for k, v in R['integration'].items() if isinstance(v, float)})
print('patching z:', round(R['patching']['z_patch_plus'], 2),
      'ablate', round(R['patching']['direction']['ablate'], 3),
      'null', round(R['patching']['null_mean']['ablate'], 3))
print('phi*:', {k: round(v, 3) for k, v in R['phi_star']['by_scale'].items()})
print('kimura:', R['kimura']['verdict'], round(R['kimura']['ks_p'], 4),
      'emp_cv', round(R['kimura']['emp_cv'], 3), 'fit_cv', round(R['kimura']['best']['cv'], 3))
